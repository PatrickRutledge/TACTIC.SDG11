# Copyright IBM Corp. 2023, 2025

"""
wxflows CLI
"""
import argparse
import logging
import logging.config
import os
import sys
from typing import Dict, List, Union

from dotenv import find_dotenv, load_dotenv
from rich.console import ConsoleRenderable
from rich.markup import escape

from .__about__ import __version__
from ._cli_admin import check_older, cmd_login, cmd_whoami
from ._cli_clidata import ExtensionsArguments
from ._cli_do import _WATZENTOML, cmd_deploy, cmd_graph, cmd_setup
from ._cli_do_data import cmd_data, cmd_data_annotate
from ._cli_do_eval import cmd_eval_collect, cmd_eval_ragas
from ._cli_do_init import (
    BFFImportAction,
    DocumentStoreArguments,
    cmd_define_import_or_extension,
    cmd_define_tool,
    cmd_init,
)
from ._cli_do_version import cmd_version
from ._cli_sdk import cmd_sdk_execute, cmd_sdk_tools_list, cmd_sdk_tools_trial
from .cli_error import CLIError
from .configuration import TOMLConfiguration
from .console import console
from .flows import setup_execute_flow_args

CLI_NAME = "wxflows"


def _init_logger() -> List[str]:
    """
    Use the same env var to enable debug logging in wxflows CLI as the one
     that's already used by StepZen CLI

     Example: DEBUG="stepzen:*,watzen" watzen init
    """
    debug_file = os.environ.get("WXFLOWS_DEBUG_LOGFILE", "")
    watzenScopes = [
        component
        for component in map(
            lambda s: s.strip(),
            os.environ.get("DEBUG", "").lower().split(","),
        )
        if component in ["*", "graphql", "http", "gql", "wxflows"]
        or component.startswith("wxflows.")
    ]
    if debug_file and not watzenScopes:
        watzenScopes = ["wxflows"]

    if watzenScopes:
        logger = logging.getLogger("wxflows")
        logger.debug(f"scope: {','.join(watzenScopes)}")
        logging.basicConfig(
            filename=debug_file,
            level=logging.WARNING,
            format="wxflows:%(levelname)s +%(relativeCreated)dms %(message)s",
        )
        logger.setLevel(logging.DEBUG)

        if "gql" in watzenScopes:
            logging.getLogger("gql").setLevel(logging.DEBUG)
            logging.getLogger("gql.client").setLevel(logging.DEBUG)
            logging.getLogger("gql.transport.requests").setLevel(logging.DEBUG)
            logging.getLogger("gql.transport.httpx").setLevel(logging.DEBUG)
            logger.debug("Logging GQL")

        if "http" in watzenScopes:
            logging.getLogger("httpx").setLevel(logging.DEBUG)
            logging.getLogger("httpcore").setLevel(logging.DEBUG)
            logger.debug("Logging HTTP")
    return watzenScopes


def _common_arguments(parser: argparse.ArgumentParser):
    parser.add_argument("--wxflows-configuration", default=_WATZENTOML, help=argparse.SUPPRESS)
    parser.add_argument(
        "--configuration-file",
        default=_WATZENTOML,
        help="watsonx Flows Engine configuration",
        dest="watzen_configuration",
    )
    parser.add_argument("--dotenv-path", help="location of the .env file")


def _common_deploy_graph(parser: argparse.ArgumentParser):
    _common_arguments(parser)
    parser.add_argument("--flow-file", help="flow definition file", action="append")
    # for internal and possibly external use, override the pattern files with files from this directory
    parser.add_argument(
        "--pattern-source-directory",
        help=argparse.SUPPRESS,
        dest="source_directory",
    )
    # for internal and possibly external use, override the core with files from this directory
    # use the less descriptive name because pattern isn't defined.
    parser.add_argument(
        "--source-directory",
        help=argparse.SUPPRESS,
        dest="source_directory",
    )

    # for internal use, add this directory into the schema as a subdirectory
    parser.add_argument(
        "--user-extension-directory",
        "-U",
        help=argparse.SUPPRESS,
        action="append",
        dest="user_extension_directories",
    )
    parser.add_argument("--flow", action="append", help=argparse.SUPPRESS)
    parser.add_argument("--stepzen-configuration-file", help=argparse.SUPPRESS)

    parser.add_argument(
        "--output-schema-directory",
        default=None,
        metavar="schema directory",
        dest="working_directory",
        help="directory with complete schema",
    )

    parser.add_argument(
        "--schema-actual-config-yaml",
        dest="working_directory_unsafe_dump_final_config_yaml",
        action="store_true",
        help=argparse.SUPPRESS,
    )


def _setup_collection(parser: argparse.ArgumentParser):
    parser.set_defaults(command="collection")
    subparsers = parser.add_subparsers(help="sub-command help", required=True, dest="subcommand")
    parser_cmd = subparsers.add_parser(
        "deploy",
        help="deploy",
    )
    # collection deploy requires flows deploy
    _common_deploy_graph(parser_cmd)
    parser.set_defaults(collection_name=None)
    parser_cmd.add_argument("--collection-mode", choices=["append", "replace", "drop"])
    # alias for collection-mode "wxflows collection deploy --mode <>"
    parser_cmd.add_argument(
        "--mode",
        dest="collection_mode",
        choices=["append", "replace", "drop"],
        help=argparse.SUPPRESS,
    )
    # hidden collection-name command
    parser_cmd.add_argument("--name", dest="collection_name", help=argparse.SUPPRESS)
    parser_cmd.add_argument("--collection-name", dest="collection_name", help=argparse.SUPPRESS)


def _setup_graph(parser: argparse.ArgumentParser):
    parser.set_defaults(command="flows")
    subparsers = parser.add_subparsers(help="sub-command help", required=True, dest="subcommand")
    dparser = subparsers.add_parser("deploy", help="deploy flows core")
    _common_deploy_graph(dparser)


def _common_data_arguments(parser: argparse.ArgumentParser):
    """
    _common_data_directory_argument is the argument exposed in both data and init commands
    """

    # remove defaults so we can know what arguments the user has given
    # important for init
    # important to override init in the data command later
    parser.add_argument("--data-directory", help="folder with data files")
    parser.add_argument("--data-type", choices=["md", "auto", "html"])
    parser.add_argument("--chunk-size", type=int)
    parser.add_argument("--chunk-overlap", type=int)
    parser.add_argument(
        "--flow-file",
        help="flow definition files to include automatically",
        action="append",
    )

    parser.add_argument(
        "--compute-embeddings",
        action="store_true",
        default=False,
        help="compute embeddings",
    )
    # source columnname will emit a column with url_columnname with values of filename
    parser.add_argument("--url-column-name", help=argparse.SUPPRESS)


class DataArguments:
    """
    trivial abstraction around arguments.
    use dicts for simplicity but separate into typed values for safety
    """

    def __init__(self, args: argparse.Namespace):
        self.data = {}
        if args.data_directory:
            self.data["data_directory"] = args.data_directory
        if args.data_type:
            self.data["data_type"] = args.data_type
        if args.chunk_size:
            self.data["chunk_size"] = args.chunk_size
        if args.chunk_overlap:
            self.data["chunk_overlap"] = args.chunk_overlap
        if args.compute_embeddings:
            self.data["compute_embeddings"] = args.compute_embeddings
        if args.url_column_name:
            self.data["url_column"] = args.url_column_name
        pass

    def get_data(self) -> Dict[str, Union[str, int]]:
        return self.data


def _parser_add_argument_embedding(parser: argparse.ArgumentParser):
    # we should get a list of the models and preload choices perhaps
    # but this requires knowing the ai_engine beforehand!
    parser.add_argument(
        "--embedding-model",
        "--embedding",
        metavar="MODEL",
        help="embedding model, defaults to mini (all-MiniLM-L6-v2)",
    )
    pass


def _setup_init_endpoint_extends(
    parser: argparse.ArgumentParser,
    subparser_mode: bool = False,
    extensions_only: bool = False,
):
    import_tag = "import-"
    if subparser_mode:
        import_tag = ""
    parser.add_argument(
        f"--{import_tag}name",
        dest="name",
        action=BFFImportAction,
        help="short name to identify the import",
    )

    # extensions don't have url or openapi
    if not extensions_only:
        parser.add_argument(
            f"--{import_tag}url",
            dest="import_url",
            action=BFFImportAction,
            help="GraphQL API URL",
        )
        parser.add_argument(
            f"--{import_tag}openapi-schema",
            dest="import_openapi_schema",
            action=BFFImportAction,
            help="OpenAPI Specification",
        )
        parser.add_argument(
            f"--{import_tag}prefix",
            dest="import_prefix",
            action=BFFImportAction,
            help="Prefix for GraphQL and OpenAPI specification",
        )
    parser.add_argument(
        f"--{import_tag}directory",
        dest="import_directory",
        action=BFFImportAction,
        help="User Extension Directory path",
    )
    parser.add_argument(
        f"--{import_tag}package",
        dest="import_package",
        action=BFFImportAction,
        help="Packaged user extension",
    )

    parser.add_argument(
        f"--{import_tag}apikey-envname",
        dest="import_apikey_envname",
        action=BFFImportAction,
    )
    parser.add_argument(
        f"--{import_tag}tool-name", dest="import_tool_name", action=BFFImportAction
    )
    parser.add_argument(
        f"--{import_tag}tool-description",
        dest="import_tool_description",
        action=BFFImportAction,
    )
    parser.add_argument(
        f"--{import_tag}tool-fields",
        dest="import_tool_fields",
        action=BFFImportAction,
        help="fields matching regular expression, default: .* when prefix supplied",
    )
    if os.environ.get("WXFLOWS_EXP") == "tools":
        parser.add_argument(
            f"--{import_tag}tool-root-types",
            dest="import_tool_root_types",
            action=BFFImportAction,
            help="root type matching regular expression, default Query",
        )


def _setup_init(parser: argparse.ArgumentParser):
    parser.set_defaults(command="init")

    # mask these, but leave the code for now.
    parser.add_argument("--name", "-N", help=argparse.SUPPRESS, default="YOUR NAME")
    parser.add_argument("--email", "-E", help=argparse.SUPPRESS, default="EMAIL")

    # possibly use this to drive usage models but for now, let it fade into the background.
    # rename as needed
    parser.add_argument("--pattern", choices=["aicore"], default="aicore", help=argparse.SUPPRESS)
    parser.add_argument(
        "--no-pattern",
        help=argparse.SUPPRESS,
        dest="pattern",
        action="store_const",
        const="null",
    )
    parser.add_argument("--endpoint-name", default=None, help="endpoint name")

    # hide this from view for now.
    parser.add_argument("--preexisting-endpoint", default="", help=argparse.SUPPRESS)
    # mask this for now.
    parser.add_argument("--document-store", help=argparse.SUPPRESS)
    parser.add_argument("--ai-engine", help="AI Engine", choices=["watsonx.ai"])
    parser.add_argument("--document-store-data-file", help=argparse.SUPPRESS)

    _parser_add_argument_embedding(parser)

    _common_data_arguments(parser)
    parser.add_argument(
        "--collection-name", "-C", help="collection name", default="", required=False
    )

    # configuration file can be used to specify a stepzen config.yaml
    parser.add_argument("--stepzen-configuration-file", help=argparse.SUPPRESS)
    # initial will emit the template config.yaml from the pattern
    parser.add_argument(
        "--initial-stepzen-configuration-file",
        help=argparse.SUPPRESS,
        action="store_true",
        dest="initial_configuration_file",
    )
    parser.add_argument(
        "--interactive",
        dest="interactive",
        action="store_true",
        default=False,
        help="interactive prompting",
    )
    _setup_init_endpoint_extends(parser)

    # finally
    parser.add_argument("files", help="TSV files to process", nargs="*")


def _setup_tool(parser: argparse.ArgumentParser):
    parser.set_defaults(command="graphql-tool")
    _common_arguments(parser)
    parser.add_argument("endpoint_url")
    parser.add_argument(
        "--endpoint-prefix",
        dest="import_prefix",
        help="prefix for GraphQL endpoint isolation, default is upper(tool_name)_",
    )
    parser.add_argument("tool_name")
    parser.add_argument("tool_description")


def _setup_endpoint_extend(parser: argparse.ArgumentParser):
    parser.set_defaults(command="endpoint")
    _common_arguments(parser)
    subparsers = parser.add_subparsers(
        help="add endpoint imports or extensions", required=True, dest="subcommand"
    )
    parser_cmd = subparsers.add_parser(
        "import",
        help="import",
    )
    _setup_init_endpoint_extends(parser_cmd, subparser_mode=True)

    parser_cmd = subparsers.add_parser(
        "extension",
        help="extension",
    )
    _setup_init_endpoint_extends(parser_cmd, subparser_mode=True, extensions_only=True)


def _setup_login(parser: argparse.ArgumentParser):
    parser.set_defaults(command="login")
    parser.add_argument("--environment", "-e", help="Environment name")
    parser.add_argument("--account", "-a", help=argparse.SUPPRESS, dest="environment")
    parser.add_argument("--adminkey", "-k", help="Admin key")
    parser.add_argument(
        "--introspection",
        help="Override the default StepZen introspection service URL for all stepzen import commands.",
    )
    parser.add_argument(
        "domain",
        metavar="DOMAIN",
        help="Domain of the StepZen service to login to (e.g. stepzen.acme.com)",
        default="",
        nargs="?",
    )
    parser.add_argument("--configuration", "--config", help=argparse.SUPPRESS)
    parser.add_argument("--code", help="alternate login: use code from wxflows dashboard to login")


def _setup_version(parser: argparse.ArgumentParser):
    parser.set_defaults(command="version")
    parser.description = "Show the version number and runtime details"


def _setup_tools(parser: argparse.ArgumentParser):
    _common_arguments(parser)
    parser.set_defaults(command="tools")
    subparsers = parser.add_subparsers(help="sub-command help", required=True, dest="subcommand")

    dparser = subparsers.add_parser("list", help="list tools")
    dparser.add_argument("--output", help="output json to file")
    dparser.add_argument(
        "--json", action="store_const", const="json", help="display output as JSON"
    )

    dparser = subparsers.add_parser("try", help="try tools using a LLM chat")

    dparser.add_argument(
        "message",
        help="user message to send to the LLM.   A good test is: What tools do you have available?",
        nargs="+",
    )

    dparser.add_argument("--tool-choice", help="select a specific tool (wxflows tools list)")
    # hide this option
    dparser.add_argument("--system-prompt", help=argparse.SUPPRESS)
    dparser.add_argument("--temperature", type=float)
    # ibm/granite-34b-code-instruct seems to work for jsonata
    # meta-llama/llama-3-1-70b-instruct is probably safer choice though?
    # see https://dataplatform.cloud.ibm.com/docs/content/wsj/analyze-data/fm-api-chat.html?context=wx for choices
    dparser.add_argument(
        "--model-id", help="LLM model_id", default="ibm/granite-34b-code-instruct"
    )
    dparser.add_argument("--time-limit", type=int, help="LLM time limit in milliseconds")
    dparser.add_argument("--max-tokens", type=int, help="LLM maximum tokens")
    dparser.add_argument(
        "--tools-file",
        help="tools output from an 'wxflows tools list --output NAME' run",
    )
    dparser.add_argument(
        "--system-prompt-file",
        help="mustache template file, available variables are TOOLS_LIST, TOOLS, TOOLS_NAMES, TODAY, NOW.",
    )
    dparser.add_argument(
        "--previous-chat-history-file", help="prior chat history [see .chat_history]"
    )
    dparser.add_argument("--output", help="output chat LLM json to file (addition)")
    dparser.add_argument(
        "--jsonl-output",
        action="store_const",
        dest="json",
        const=True,
        help="display llm inputs and output as jsonl",
    )
    dparser.add_argument(
        "--details",
        type=int,
        default=1,
        help="detail level, default shows basic information",
    )
    dparser.add_argument(
        "-t", "--trace", action="store_const", const=True, help="detailed call trace"
    )
    dparser.add_argument(
        "--execute",
        "-E",
        help="max number of times to execute LLM",
        type=int,
        default=3,
    )
    dparser.add_argument(
        "--with-dataid",
        action="store_const",
        dest="dataid",
        const=True,
        help="with-dataid - add a 'dataid' and presume renderData.\nUseful approach to ensure you only display data from the tool instead of LLM hallucinations. When enabled, each LLM tool execution result is automatically assigned a unique 'dataid'. Use this flag together with a custom system prompt that instructs the LLM to reference user data by 'dataid' instead of literally, and that you have a tool renderData that can turn 'dataid' into actual data.",
    )


def _setup_whoami(parser: argparse.ArgumentParser):
    parser.set_defaults(command="whoami")
    parser.add_argument("--prefix", dest="prefix", help="prefix for environment variables")
    action = parser.add_mutually_exclusive_group(required=False)
    parser.set_defaults(showkeys="default")
    _common_arguments(parser)
    action.add_argument(
        "--environment",
        dest="showkeys",
        action="store_const",
        const="environment",
        help="print only the environment",
    )
    action.add_argument(
        "--account",
        dest="showkeys",
        action="store_const",
        const="environment",
        help=argparse.SUPPRESS,
    )
    action.add_argument(
        "--adminkey",
        dest="showkeys",
        action="store_const",
        const="adminkey",
        help="print only the Admin key",
    )
    action.add_argument(
        "--apikey",
        dest="showkeys",
        action="store_const",
        const="apikey",
        help="print only the API key",
    )
    action.add_argument(
        "--domain",
        dest="showkeys",
        action="store_const",
        const="domain",
        help="print only the domain",
    )
    # this is a no-op and should be wither fixed or removed
    action.add_argument(
        "--showkeys",
        dest="showkeys",
        action="store_const",
        const="display",
        help=argparse.SUPPRESS,
    )
    action.add_argument(
        "--endpoint-url",
        dest="showkeys",
        action="store_const",
        const="endpoint-url",
        help="print only the endpoint URL",
    )
    action.add_argument(
        "--sdk-env",
        dest="showkeys",
        action="store_const",
        const="sdk-env",
        help="print all necessary environment variables for the SDK in the .env format",
    )
    action.add_argument(
        "--json",
        dest="showkeys",
        action="store_const",
        const="json",
        help=argparse.SUPPRESS,
    )


def _setup_deploy(parser: argparse.ArgumentParser):
    parser.set_defaults(command="deploy")
    _common_deploy_graph(parser)
    # disable these on `deploy`
    # parser.add_argument("--collection-mode", choices=["append", "replace", "skip"])
    # parser.add_argument("--no-upload", dest="collection_mode", action="store_const", const="skip")


def _setup_data(parser: argparse.ArgumentParser):
    parser.set_defaults(command="data")
    subparsers = parser.add_subparsers(
        help="sub-command help", required=True, dest="subcommand", metavar="{build}"
    )
    parser = subparsers.add_parser("build", help="build")
    _common_arguments(parser)
    _common_data_arguments(parser)
    parser.add_argument("--force", action="store_true", default=False)

    parser = subparsers.add_parser("annotate")
    parser.add_argument("--force", action="store_true", default=False)
    _parser_add_argument_embedding(parser)
    parser.add_argument(
        "--directive",
        choices=["convert-text", "combine-text"],
        help="combine-text will combine text and title as content, convert-text drops the title and text after the combine operation",
    )

    _common_arguments(parser)
    parser.add_argument("--output-file", "--output", required=True, help="output file")
    parser.add_argument("files", help="input files", nargs="+")


def _setup_request(parser: argparse.ArgumentParser):
    parser.set_defaults(command="request")
    _common_arguments(parser)
    setup_execute_flow_args(parser, flowname_required=True)


def _setup_eval(parser: argparse.ArgumentParser):
    parser.set_defaults(command="eval")
    subparsers = parser.add_subparsers(help="sub-command help", required=True, dest="subcommand")
    parser = subparsers.add_parser(
        "collect", help="collect", formatter_class=argparse.RawTextHelpFormatter
    )
    _common_arguments(parser)
    parser.add_argument(
        "--question-set",
        required=True,
        help="path to a CSV file with a 'question' and 'ground_truth' columns",
    )
    parser.add_argument(
        "--variations",
        help="path to a CSV file with variations."
        + " The following columns are supported:"
        + "\n - nRetrieved: number of documents to retrieve and include into "
        + "the prompt as context, e.g. 3, 5"
        + "\n - collection: [search engine]::[collection], e.g. GETTINGSTARTED::langnq"
        + "\n - model: [AI engine]::[model id], e.g. WATSONX::ibm/granite-3-8b-instruct"
        + "\n - parameters: JSON string with model parameters, "
        + 'e.g. {"max_new_tokens": 350}'
        + "\n - promptTemplate: prompt template string with placeholders, "
        + "e.g. Given {{context}} answer {{question}}"
        + "\n"
        + "\nA variation is made for each permutation of the column values",
    )
    parser.add_argument(
        "--output",
        required=False,
        help="path to an output CSV file to create. If --variations is set"
        + " then this path is treated as a directory.",
    )
    parser.add_argument(
        "--num-proc",
        default=10,
        help="number of processes to run in parallel",
        type=int,
    )
    parser.add_argument(
        "--limit",
        default=0,
        help="stop after processing the first N questions (default=0 means no limit)",
        type=int,
    )
    parser.add_argument("--flow-name", help="name of the flow to evaluate (e.g. ragAnswer)")

    parser = subparsers.add_parser("ragas", help="ragas")
    _common_arguments(parser)
    parser.add_argument(
        "--response-set",
        required=True,
        help="path to a CSV file with 'question', 'ground_truth', "
        + "'answer', 'contexts' columns (see eval collect)",
    )
    parser.add_argument("--output", required=True, help="path to an output CSV file to create")
    parser.add_argument(
        "--llm",
        metavar="LLM",
        default="ibm/granite-34b-code-instruct",
        help="LLM to evaluate the RAG pipeline answers (default=ibm/granite-34b-code-instruct). "
        + "Check the list of available models at "
        + "https://dataplatform.cloud.ibm.com/docs/content/wsj/analyze-data/fm-models.html?context=wx",
    )
    parser.add_argument(
        "--limit",
        default=0,
        help="stop after processing the first N responses (default=0 means no limit)",
        type=int,
    )


def check_embedding_model(model_name: str) -> str:
    # would like to  do a check based upon the AI Engine in effect
    # but that requires us to call an API (BAM, etc.) or know the
    # valid values (watsonx)
    return model_name


def main():
    load_dotenv(find_dotenv(usecwd=True))
    _init_logger()
    me = sys.argv[0]
    if not me:
        me = "flows"
    else:
        me = os.path.basename(me)
    parser = argparse.ArgumentParser(
        prog=me, description="CLI for watsonx Flows Engine development", epilog=""
    )
    # one or more feature flags
    parser.add_argument(
        "--feature-flag",
        "-F",
        dest="feature_flags",
        action="append",
        help=argparse.SUPPRESS,
    )
    parser.add_argument("--verbose", "-v", action="store_true", default=False, help="verbose")

    parser.add_argument("--version", action="version", version="%(prog)s " + __version__)

    subparsers = parser.add_subparsers(required=True)
    _setup_version(subparsers.add_parser("version", help="version"))
    _setup_init(subparsers.add_parser("init", help="initialize"))
    _setup_endpoint_extend(subparsers.add_parser("endpoint", help="define import or extension"))
    _setup_tool(subparsers.add_parser("graphql-tool", help="define a tool using defaults"))
    _setup_login(subparsers.add_parser("login", help="login"))
    _setup_whoami(subparsers.add_parser("whoami", help="whoami"))
    _setup_deploy(subparsers.add_parser("deploy", help="deploy"))
    _setup_collection(subparsers.add_parser("collection", help="collection"))
    _setup_graph(subparsers.add_parser("flows", help="flow or flows"))
    _setup_data(subparsers.add_parser("data", help="data builder"))
    _setup_eval(subparsers.add_parser("eval", help="RAG pipeline evaluation"))
    _setup_request(subparsers.add_parser("request", help="execute a flow"))
    _setup_tools(subparsers.add_parser("tools", help="list or execute a flow"))

    args = parser.parse_args()
    try:
        location = args.dotenv_path
        if not location:
            location = ""
    except AttributeError:
        # would allow pointing to a different
        # location for .env - todo: remove
        location = ""

    if args.command != "whoami":
        if args.command != "tools" or (hasattr(args, "json") and args.json is not True):
            check_older(me)
    try:
        clienv = cmd_setup(location, args.feature_flags, args.verbose, args.command)
        if args.command == "version":
            cmd_version()
        elif args.command == "init":
            bff_args = None
            if "bff_args" in args:
                bff_args = args.bff_args

            cmd_init(
                clienv,
                args.pattern,
                args.collection_name,
                args.files,
                args.name,
                args.email,
                args.interactive,
                args.stepzen_configuration_file,
                args.initial_configuration_file,
                check_embedding_model(args.embedding_model),
                DataArguments(args).get_data(),
                args.flow_file,
                args.endpoint_name,
                args.preexisting_endpoint,
                args.ai_engine,
                bff_args,
                DocumentStoreArguments(
                    args.document_store,
                    args.document_store_data_file,
                ),
            )
        elif args.command == "endpoint":
            cmd_define_import_or_extension(
                clienv,
                args.subcommand,
                args.watzen_configuration,
                TOMLConfiguration(args.watzen_configuration),
                args.bff_args,
            )
        elif args.command == "graphql_tool":
            cmd_define_tool(
                clienv,
                TOMLConfiguration(args.watzen_configuration),
                args.endpoint_url,
                args.import_prefix,
                args.tool_name,
                args.tool_description,
            )
        elif args.command == "login":
            cmd_login(
                clienv,
                args.environment,
                args.adminkey,
                args.domain,
                args.introspection,
                args.configuration,
                args.code,
            )
        elif args.command == "deploy":
            cmd_deploy(
                clienv,
                TOMLConfiguration(args.watzen_configuration),
                ExtensionsArguments(args),
                args.stepzen_configuration_file,
                None,  # collection name not available here
                args.flow,
                args.flow_file,
                args.working_directory,
                args.working_directory_unsafe_dump_final_config_yaml,
                "skip",  # deploy is flows only
            )
            pass
        elif args.command == "collection":
            cmd_deploy(
                clienv,
                TOMLConfiguration(args.watzen_configuration),
                ExtensionsArguments(args),
                args.stepzen_configuration_file,
                args.collection_name,
                args.flow,
                args.flow_file,
                args.working_directory,
                args.working_directory_unsafe_dump_final_config_yaml,
                args.collection_mode,
            )
        elif args.command == "flow" or args.command == "flows" or args.command == "graph":
            cmd_graph(
                clienv,
                args.subcommand,
                TOMLConfiguration(args.watzen_configuration),
                ExtensionsArguments(args),
                args.stepzen_configuration_file,
                args.flow,
                args.flow_file,
                args.working_directory,
                args.working_directory_unsafe_dump_final_config_yaml,
            )
        elif args.command == "data":
            if args.subcommand == "annotate":
                cmd_data_annotate(
                    console,
                    clienv,
                    TOMLConfiguration(args.watzen_configuration),
                    args.directive,
                    args.embedding_model,
                    args.files,
                    args.output_file,
                    args.force,
                )
            elif args.subcommand == "build":
                cmd_data(
                    console,
                    clienv,
                    TOMLConfiguration(args.watzen_configuration),
                    args.subcommand,
                    DataArguments(args).get_data(),
                    args.force,
                )
        elif args.command == "whoami":
            cmd_whoami(
                clienv,
                args.showkeys,
                args.prefix,
                args.wxflows_configuration,
            )
        elif args.command == "request":
            cmd_sdk_execute(
                clienv,
                TOMLConfiguration(args.watzen_configuration),
                args.flow_name,
                args.max_depth,
                args.data,
                args.var,
                args.var_file,
                args.query,
            )
        elif args.command == "tools":
            if args.subcommand == "list":
                cmd_sdk_tools_list(
                    clienv,
                    TOMLConfiguration(args.watzen_configuration),
                    args.output,
                    args.json,
                )
            elif args.subcommand == "try":
                cmd_sdk_tools_trial(
                    clienv,
                    TOMLConfiguration(args.watzen_configuration),
                    args.message,
                    model_id=args.model_id,
                    system_prompt=args.system_prompt,
                    temperature=args.temperature,
                    time_limit=args.time_limit,
                    max_tokens=args.max_tokens,
                    dump_json=args.json,
                    input_tools=args.tools_file,
                    input_prompt=args.system_prompt_file,
                    output_json=args.output,
                    tool_choice=args.tool_choice,
                    details=args.details,
                    execute=args.execute,
                    dataid=args.dataid,
                    stepzen_debug=args.trace,
                    chat_history_file=args.previous_chat_history_file,
                )
            else:
                raise CLIError(f"unknown command: {CLI_NAME} tools {args.subcommand}")
        elif args.command == "eval":
            if args.subcommand == "collect":
                cmd_eval_collect(
                    clienv,
                    args.subcommand,
                    TOMLConfiguration(args.watzen_configuration),
                    args.flow_name,
                    args.question_set,
                    args.output,
                    args.variations,
                    args.num_proc,
                    args.limit,
                )
            elif args.subcommand == "ragas":
                cmd_eval_ragas(
                    clienv,
                    args.subcommand,
                    args.response_set,
                    args.output,
                    args.llm,
                    args.limit,
                )
            else:
                raise CLIError(f"unknown command: {CLI_NAME} eval {args.subcommand}")
    except CLIError as e:
        console.print(
            "\n[red]Error[/red]:",
            (e.message if isinstance(e.message, ConsoleRenderable) else escape(e.message)),
        )
        sys.exit(e.code)


if __name__ == "__main__":
    main()
