# Copyright IBM Corp. 2023, 2025
import ast
import os
import sys
from typing import Any, List, Optional, cast

# ragas requires OPENAI_API_KEY to be defined at the import time - it creates
# the default instances of each metric, and they all by default use the OpenAI
# model and validate the key at the construction time.
#
# Later we replace the LLM used in the default metric instances with our
# WatsonX, so this is a workaround to get past the initial OpenAI API key
# validation.
if not os.getenv("OPENAI_API_KEY"):
    os.environ["OPENAI_API_KEY"] = "fake-key"


# from ibm_watson_machine_learning.foundation_models.utils.enums import DecodingMethods
from datasets import Dataset, load_dataset
from ibm_watson_machine_learning.metanames import (  # pyright: ignore[reportMissingImports]
    GenTextParamsMetaNames as GenParams,
)

# transitively includes ibm_watsonx_ai and ibm_watson_machine_learning
from langchain_community.llms import WatsonxLLM as _WatsonxLLM
from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.outputs import LLMResult
from pandas import DataFrame
from ragas import evaluate  # pyright: ignore[reportMissingImports]
from ragas.embeddings import HuggingfaceEmbeddings  # pyright: ignore[reportMissingImports]
from ragas.llms import LangchainLLMWrapper  # pyright: ignore[reportMissingImports]
from ragas.metrics import (  # pyright: ignore[reportMissingImports]
    answer_relevancy,
    context_precision,
    context_recall,
    faithfulness,
)
from ragas.run_config import RunConfig


class WatsonxLLM(_WatsonxLLM):
    temperature: float = 0
    """
    A workaround for interface incompatibility: Ragas expected all LLMs to
    have a `temperature` property whereas WatsonxLLM does not define it.
    """

    def _generate(
        self,
        prompts: List[str],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        stream: Optional[bool] = None,
        **kwargs: Any,
    ) -> LLMResult:
        """
        A workaround for interface incompatibility: Ragas expected the
        `token_usage` property of the LLM result be of a particular shape.
        WatsonX returns it in a slightly different shape.
        """
        result: LLMResult = super()._generate(prompts, stop, run_manager, stream, **kwargs)
        if not result.llm_output or "token_usage" not in result.llm_output:
            return result
        usage = result.llm_output["token_usage"]
        if not isinstance(usage, dict):
            return result
        result.llm_output["token_usage"] = {
            "prompt_tokens": usage["input_token_count"],
            "completion_tokens": usage["generated_token_count"],
            "total_tokens": usage["input_token_count"] + usage["generated_token_count"],
        }
        return result


# Function to convert string representation of a list to an actual list
def str_to_list(value):
    try:
        # Safely evaluate the string as a Python literal (list)
        return ast.literal_eval(value)
    except ValueError:
        # In case of error, return an empty list or some default value
        return []


def ragas(
    response_set: str,
    output: str,
    llm: str,
    limit: int = 0,
):
    """
    wxflows eval ragas \
        --response-set path/to/answers.csv \
        --output path/to/output.csv
    """

    if llm.startswith("ibm/"):
        if not os.getenv("WATSONX_APIKEY"):
            print(
                "WATSONX_APIKEY environment variable must be set to use the"
                + f" {llm} model. Get yours at https://cloud.ibm.com/iam/apikeys"
            )
            sys.exit(1)
        if not os.getenv("WATSONX_PROJECT_ID"):
            print(
                "WATSONX_PROJECT_ID environment variable must be set to use the"
                + f" {llm} model. Get yours at https://dataplatform.cloud.ibm.com/projects/?context=wx"
            )
            sys.exit(1)

        # do not use the default OpenAI-based embeddings
        # (requires `sentence-transformers` - would fail if it's not installed)
        answer_relevancy.embeddings = HuggingfaceEmbeddings()

        # use the Ragas LangchainLLM wrapper to create a RagasLLM instance
        watsonx_llm = LangchainLLMWrapper(
            langchain_llm=WatsonxLLM(
                model_id=llm,
                url="https://us-south.ml.cloud.ibm.com",
                project_id=os.getenv("WATSONX_PROJECT_ID"),
                params={
                    # Workaround for
                    # TypeError: Object of type DecodingMethods is not JSON serializable
                    # in ibm_watsonx_ai/foundation_models/inference/base_model_inference.py
                    #    self._send_inference_payload()
                    # --> remove the DECODING_METHOD parameter
                    # GenParams.DECODING_METHOD: DecodingMethods.GREEDY,
                    GenParams.MAX_NEW_TOKENS: 100,
                    GenParams.MIN_NEW_TOKENS: 1,
                    GenParams.STOP_SEQUENCES: ["<|endoftext|>"],
                    GenParams.TEMPERATURE: 0.2,
                    GenParams.TOP_K: 50,
                    GenParams.TOP_P: 1,
                },
            )
        )

        for metric in [answer_relevancy, context_precision, context_recall, faithfulness]:
            metric.llm = watsonx_llm
    elif llm.startswith("openai/"):
        if os.getenv("OPENAI_API_KEY") == "fake-key":
            print(f"OPENAI_API_KEY environment variable must be set to use the {llm} model.")
            sys.exit(1)
    else:
        print(f"Unknown LLM: {llm}")
        sys.exit(1)

    ds = cast(Dataset, load_dataset("csv", data_files=response_set, split="train"))

    if limit:
        ds = ds.select(range(limit))

    run_config = RunConfig()
    # maybe useful for debugging
    # run_config.thread_timeout = 9999999
    result = evaluate(
        dataset=ds.map(
            lambda row: {
                **row,
                "contexts": str_to_list(row["contexts"]),
                **(
                    {"ground_truths": str_to_list(row["ground_truths"])}
                    if "ground_truths" in row
                    else {}
                ),
            }
        ),
        metrics=[
            context_precision,
            faithfulness,
            answer_relevancy,
            context_recall,
        ],
        run_config=run_config,
    )

    print(result)

    pd = result.to_pandas()
    df = pd if isinstance(pd, DataFrame) else next(pd)
    df.to_csv(output, index=False)
