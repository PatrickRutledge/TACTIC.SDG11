# Copyright IBM Corp. 2024, 2025

import datetime
import json
import logging
import os
import sys
from shlex import quote
from typing import Optional

import httpx
from rich.text import Text

from ._cli_clidata import CLIData
from .cli_error import CLIError, CLIStepzenConfiguration
from .configuration import TOMLConfiguration
from .console import console
from .stepzen_services import StepzenLogin

debug_level = 0

logger = logging.getLogger("wxflows")


def get_credentials(credentials_location: Optional[str]) -> str:
    if not credentials_location:
        return ""
    if os.path.isfile(credentials_location):
        with open(credentials_location) as f:
            return f.read()

    with httpx.Client() as client:
        response = client.get(credentials_location)
        response.raise_for_status()
        data = response.text
        return data
    return ""


def api_cli_auth(code: str) -> str:
    """
    supports login via wxflows dashboard
    - sends POST with code
    - expect a response that contains stepzen-config.yaml
      - note: the response may actually be JSON but that's legal YAML
    """
    with httpx.Client() as client:
        headers = {"content-type": "application/json", "accept": "*/*"}
        data = {"code": code}
        url = os.environ.get(
            "WXFLOWS_DASHBOARD_URL", "https://wxflows.ibm.stepzen.com/api/cli/auth"
        )
        response = client.post(url=url, json=data, headers=headers)
        response.raise_for_status()
        # expect response to be writable to stepzen-config.yaml
        data = response.text
        return data
    return ""


def cmd_login(
    cli: CLIData,
    environment_arg: Optional[str],
    adminkey_arg: Optional[str],
    domain_arg: Optional[str],
    introspection_arg: Optional[str],
    credentials_location: Optional[str] = "",
    code: str = "",
):

    # probably should also put a mutual exclusion on this upstream
    if credentials_location and code:
        raise CLIError("You cannot specify both --code and --configuration")

    if code:
        try:
            credentials_force_update = api_cli_auth(code)
        except httpx.ConnectError as e:
            if "Name or service not known" in str(e):
                print(
                    "This feature is likely not yet implemented, please try again in a few days."
                )
                return CLIError("Please try again later")
            raise

        cli = CLIData.create("", [], credentials_force_update=credentials_force_update)
        print(f"Login to {cli.account} using code successful")
        return
    if credentials_location:
        logger.debug(f"Using credentials from {credentials_location}")
        credentials_force_update = get_credentials(credentials_location)
        cli = CLIData.create("", [], credentials_force_update=credentials_force_update)
        print(f"Login to {cli.account} using {credentials_location} successful")
        return

    if introspection_arg:
        # enough for now.
        if introspection_arg.startswith("http"):
            introspection = introspection_arg
        else:
            introspection = f"https://{introspection_arg}"
        logger.debug(f"Introspection {introspection}")
    else:
        introspection = ""

    # check to see if the configuration file exists, if not check if the user wants to refresh
    try:
        _ = cli.account
    except AttributeError:
        try:

            CLIData.overwrite_check()
        except CLIStepzenConfiguration:
            print("okay, will not overwrite existing login information")
            return

    skip_tls_verify = cli.is_feature("skip-tls-verify")
    try:
        _ = CLIData.login(
            environment_arg,
            domain_arg,
            adminkey_arg,
            introspection,
            skip_tls_verify,
        )
        if skip_tls_verify:
            print(
                "Note: you have bypassed TLS verification, meaning that you may be logged in to a server whose authenticity has not been verified."
            )
            print(
                "Use at your own risk, and be aware that you will need to pass -F=skip-tls-verify to each wxflows deploy command."
            )
    except Exception as e:
        raise CLIError(str(e))
    pass


def check_older(prog: str, force: bool = False):
    # don't do the check if we're running tests.
    # this feature is not currently tested
    # [Adding a test for this will end up be complicated due
    # to the numer of conditions and the pacakge is being deprecated ]
    if "pytest" in sys.modules:
        return
    cur_time = datetime.datetime.now()
    if cur_time > datetime.datetime.fromisoformat("2025-03-01"):
        console.print("[red]Development has moved to the node version of wxflows cli.[/red]")
        msg = Text(
            text=(
                "Installation instructions for the new node cli should be available at https://wxflows.ibm.stepzen.com/docs/installation or you can reach out to us on Discord "
                "(https://ibm.biz/wxflows-discord)."
            ),
            overflow="fold",
            no_wrap=False,
        )
        console.print(msg)


def cmd_whoami(
    cli: CLIData,
    whoami: Optional[str],
    prefix: Optional[str],
    wxflows_configuration: Optional[str],
):

    logger.debug(f"whoami {whoami}")
    try:
        _ = cli.account
    except Exception:
        logger.debug(f"whoami {whoami} - no CLIData")
        print("You are not logged in")
        return

    if whoami == "environment":
        print(f"{cli.account}")
    elif whoami == "adminkey":
        print(f"{cli.adminkey}")
    elif whoami == "apikey":
        print(f"{cli.apikey}")
    elif whoami == "domain":
        print(f"{cli.domain}")
    elif whoami == "endpoint-url":
        if not wxflows_configuration:
            wxflows_configuration = ""
        toml_data = TOMLConfiguration(wxflows_configuration)
        login = StepzenLogin(
            cli.account,
            cli.domain,
            cli.adminkey,
            service_instances=cli.service_instance,
            skip_tls_verify=cli.is_feature("skip-tls-verify"),
        )
        print(login.endpoint_uri(toml_data.endpoint_name()))

    elif whoami == "sdk-env":
        if not wxflows_configuration:
            wxflows_configuration = ""
        toml_data = TOMLConfiguration(wxflows_configuration)
        if not prefix:
            prefix = "WXFLOWS_"
        sdk_env = toml_data.pattern_env(prefix=prefix, minimal=True)
        if not sdk_env:
            logger.debug(f"whoami {whoami} - sdk_env is empty")
            sdk_env = {}
        login = StepzenLogin(
            cli.account,
            cli.domain,
            cli.adminkey,
            service_instances=cli.service_instance,
            skip_tls_verify=cli.is_feature("skip-tls-verify"),
        )
        endpoint = login.endpoint_uri(toml_data.endpoint_name())
        sdk_env.update(
            {
                f"{prefix}ENVIROMENT": f"{cli.account}",
                f"{prefix}ENDPOINT": f"{endpoint}",
                f"{prefix}APIKEY": f"{cli.apikey}",
            }
        )
        print(f"# Autogenerated {datetime.datetime.now().isoformat()}")
        collection_info = ""
        if toml_data.pattern_collection():
            collection_info = f" collection {toml_data.pattern_collection()}"
        print(f"# {cli.account} endpoint {toml_data.endpoint_name()}{collection_info}")
        for k in sorted(sdk_env):
            v = quote(sdk_env[k]) if sdk_env[k] else ""

            print(f"{k}={v}")
        print("# end autogenerated")

    elif whoami == "json":
        print(
            json.dumps(
                {
                    "domain": cli.domain,
                    "environment": cli.account,
                    "adminKey": cli.adminkey,
                    "apiKey": cli.apikey,
                }
            )
        )
    else:  # display or default fall through
        print()
        print(f"Domain: {cli.domain}")
        print(f"Environment: {cli.account}")

        def mask_key(s):
            parts = s.split("::")
            if len(parts) < 3:
                return len(s) * "*"
            if len(parts[2]) < 20:  # if too short, then we end up showing the key
                return "::".join([parts[0], parts[1], len(parts[2]) * "*"])
            return "::".join(
                [parts[0], parts[1], parts[2][0:2] + (len(parts[2]) - 4) * "*" + parts[2][-2:]]
            )

        print(f"Admin key: {mask_key(cli.adminkey)}")
        print(f"Api key: {mask_key(cli.apikey)}")
        check_older("wxflows", force=True)
