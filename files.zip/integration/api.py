from flask import Flask, request, jsonify
import json

app = Flask(__name__)

# Simulated storage for demonstration
USER_ANSWERS = []
VOICE_KB_PATH = "storage/viewpoints.json"
AUDIENCE_QUESTIONS = [
    "Is government funding the best way to achieve inclusion?",
    "Should internet access be free for all?",
    "How do we address rural connectivity challenges?"
]

@app.route("/submit_answers", methods=["POST"])
def submit_answers():
    data = request.json
    # data: { "user_id": "...", "answers": [...] }
    USER_ANSWERS.append(data)
    # TODO: vectorize and recluster voices asynchronously
    return jsonify({"success": True})

@app.route("/get_distilled_voices", methods=["GET"])
def get_distilled_voices():
    with open(VOICE_KB_PATH) as f:
        kb = json.load(f)
    return jsonify(kb["voices"])

@app.route("/get_audience_questions", methods=["GET"])
def get_audience_questions():
    return jsonify(AUDIENCE_QUESTIONS)

@app.route("/panelist_responses", methods=["POST"])
def panelist_responses():
    data = request.json
    # data: { "panelist_voice_ids": [...], "question": "..." }
    with open(VOICE_KB_PATH) as f:
        kb = json.load(f)
    responses = []
    for panelist_id in data["panelist_voice_ids"]:
        voice = next((v for v in kb["voices"] if v["id"] == panelist_id), None)
        if voice:
            resp = f"As a panelist representing '{voice['summary']}', I believe: " + "; ".join(voice["supporting_arguments"])
        else:
            resp = "No viewpoint assigned."
        responses.append(resp)
    return jsonify(responses)

@app.route("/save_transcript", methods=["POST"])
def save_transcript():
    data = request.json
    # data: { "user_id": "...", "transcript": "..." }
    # TODO: Save to database
    return jsonify({"success": True})

if __name__ == "__main__":
    app.run(debug=True)