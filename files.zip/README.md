# Digital Inclusion Forum - Multi-Agent Simulation

This project simulates a public forum on digital inclusion, where panelists and community members interact around distinct viewpoints ("voices") distilled from user input.

## How It Works

1. **Users arrive at the site and interact with an agent.**
2. **Agent asks questions to determine the user's viewpoint.**
3. **User viewpoint is recorded and clustered with others.**
4. **Distinct viewpoints ("voices") are distilled automatically (no fixed number of clusters).**
5. **Users can view all distilled voices and assign them to panelists.**
6. **Community member agents ask questions; panelists respond based on their assigned voice.**
7. **Multiple panelists can share a voice.**

## Key Files

- `storage/viewpoints.json` - Knowledge base of distilled voices
- `storage/voice_clustering.py` - Clustering logic to autoscale voices
- `agents/panelist.py` - Panelist agent logic
- `agents/community_member.py` - Community member agent logic
- `orchestration/session.py` - Orchestration/session manager
- `integration/api_stub.py` - API stubs for interaction

## Planning Reference

See [IBM Repo Issue #1: Project planning for public forum agent framework on Watsonx](https://github.com/PatrickRutledge/IBM/issues/1)

## Next Steps

- Build frontend UI for user interaction
- Implement clustering and API endpoints
- Connect to IBM Cloud and Watsonx for scaling and deployment

Feel free to expand, restructure, or add language-specific files as the project evolves.