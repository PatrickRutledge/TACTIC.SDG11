// API base url (adjust if needed)
const API_BASE = "http://localhost:5000";

const agentQuestions = [
  "What does digital inclusion mean to you?",
  "What is the biggest barrier to digital access?",
  "Should digital literacy be a public responsibility?"
];

let distilledViewpoints = [];
let audienceQuestions = [];
let transcript = [];
let userAnswers = [];
let panelistAssignments = [];
let currentStep = 0;
let panelistCount = 3;
let panelistViewpoints = [];

function renderStep() {
  const main = document.getElementById('main-view');
  main.innerHTML = '';
  switch (currentStep) {
    case 0:
      main.innerHTML = `<h2>Discover Your Perspective</h2>
        <div class="question-box">${agentQuestions[0]}</div>
        <input id="user-answer" placeholder="Type your answer here..." autofocus style="width:100%;margin-bottom:12px;">
        <button onclick="submitAnswer()">Next</button>`;
      break;
    case 1:
    case 2:
      main.innerHTML = `<h2>Discover Your Perspective</h2>
        <div class="question-box">${agentQuestions[currentStep]}</div>
        <input id="user-answer" placeholder="Type your answer here..." autofocus style="width:100%;margin-bottom:12px;">
        <button onclick="submitAnswer()">Next</button>`;
      break;
    case 3:
      main.innerHTML = `<h2>Assign Panelist Viewpoints</h2>
        <p>Assign a viewpoint to each panelist. Panelists can share viewpoints.</p>
        <div id="panelist-assigns"></div>
        <button onclick="assignPanelists()">Assign & Continue</button>`;
      fetch(`${API_BASE}/get_distilled_voices`)
        .then(res => res.json())
        .then(voices => {
          distilledViewpoints = voices;
          document.getElementById('panelist-assigns').innerHTML =
            Array(panelistCount).fill().map((_, i) => `
              <div class="panelist-assign">
                Panelist ${i+1}: 
                <select id="panelist-${i}">
                  ${distilledViewpoints.map(v => `<option value="${v.id}">${v.summary}</option>`).join('')}
                </select>
              </div>
            `).join('');
        });
      break;
    case 4:
      main.innerHTML = `<h2>Audience Questions</h2>
        <div id="audience-interaction"></div>
        <button onclick="showTranscript()">Finish & Show Transcript</button>`;
      fetch(`${API_BASE}/get_audience_questions`)
        .then(res => res.json())
        .then(qs => {
          audienceQuestions = qs;
          startAudienceQuestions();
        });
      break;
  }
}

function submitAnswer() {
  const answer = document.getElementById('user-answer').value.trim();
  if (!answer) return;
  userAnswers.push(answer);
  transcript.push(`User perspective Q${currentStep+1}: ${agentQuestions[currentStep]}\nA: ${answer}`);
  currentStep++;
  if (currentStep === agentQuestions.length) {
    // Submit answers to backend
    fetch(`${API_BASE}/submit_answers`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({user_id: "demo_user", answers: userAnswers})
    }).then(() => renderStep());
  } else {
    renderStep();
  }
}

function assignPanelists() {
  panelistViewpoints = [];
  for (let i = 0; i < panelistCount; i++) {
    const select = document.getElementById(`panelist-${i}`);
    panelistViewpoints.push(select.value);
    transcript.push(`Panelist ${i+1} assigned viewpoint: ${distilledViewpoints.find(v => v.id === select.value).summary}`);
  }
  currentStep++;
  renderStep();
}

// Audience interaction logic
let audienceQIndex = 0;
function startAudienceQuestions() {
  audienceQIndex = 0;
  renderAudienceQuestion();
}
function renderAudienceQuestion() {
  const box = document.getElementById('audience-interaction');
  if (audienceQIndex >= audienceQuestions.length) {
    box.innerHTML = `<p>No more questions.</p>`;
    return;
  }
  const q = audienceQuestions[audienceQIndex];
  box.innerHTML = `
    <div class="question-box">Audience asks: ${q}</div>
    <button onclick="showPanelistResponses()">See Panelist Responses</button>
    <button class="skip-btn" onclick="skipQuestion()">Skip Question</button>
    <div id="panelist-responses"></div>
  `;
}
function showPanelistResponses() {
  const q = audienceQuestions[audienceQIndex];
  transcript.push(`Audience Question: ${q}`);
  // Get panelist responses from backend
  fetch(`${API_BASE}/panelist_responses`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({panelist_voice_ids: panelistViewpoints, question: q})
  })
    .then(res => res.json())
    .then(responses => {
      const html = responses.map((resp, i) =>
        `<div class="response-box"><b>Panelist ${i+1}:</b><br>${resp}</div>`
      ).join('');
      document.getElementById('panelist-responses').innerHTML = html;
      transcript.push(responses.map((resp, i) => `Panelist ${i+1}: ${resp}`).join('\n'));
    });
}
function skipQuestion() {
  transcript.push(`Audience Question Skipped: ${audienceQuestions[audienceQIndex]}`);
  audienceQIndex++;
  renderAudienceQuestion();
}

function showTranscript() {
  document.getElementById('main-view').style.display = 'none';
  document.getElementById('transcript-view').style.display = '';
  document.getElementById('transcript').textContent = transcript.join('\n\n');
  // Optionally save transcript to backend
  fetch(`${API_BASE}/save_transcript`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({user_id: "demo_user", transcript: transcript.join('\n\n')})
  });
}

function restartSession() {
  transcript = [];
  userAnswers = [];
  panelistAssignments = [];
  currentStep = 0;
  panelistViewpoints = [];
  document.getElementById('main-view').style.display = '';
  document.getElementById('transcript-view').style.display = 'none';
  renderStep();
}

// Start the app
window.onload = renderStep;