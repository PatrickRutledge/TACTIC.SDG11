# This directory contains code for agent logic:
# - Panelist agents
# - Chairman agent
# - Community member agents

# Add your agent classes and persona logic here.