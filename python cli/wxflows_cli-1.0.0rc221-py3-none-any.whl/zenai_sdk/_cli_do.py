# Copyright IBM Corp. 2023, 2025

"""
stepzen.zenai operations
"""
import asyncio
import hashlib
import io
import json
import logging
import os
import shlex
import tempfile
import time
import uuid
import zipfile
from pathlib import Path, PosixPath
from typing import Any, Dict, List, Mapping, Optional, Tuple, Union
from urllib.parse import urlparse

import httpx
import tomlkit
import tomlkit.items
import yaml
from pydantic import ConfigDict, BaseModel

from ._cli_clidata import CLIData, ExtensionsArguments, _get_vup
from ._cli_do_loader import upload_and_process_local
from .cli_error import (
    CLIError,
    CLIStepzenConfiguration,
    CLIStepzenConfigurationLogin,
    CLIStepzenConfigurationLoginBad,
)
from .configuration import _WATZENTOML, TOMLConfiguration
from .console import console
from .flows import FlowFoundation, FlowsPublisher
from .stepzen_services import (
    IntrospectionMessage,
    IntrospectionServices,
    SchemaFileData,
    StepzenCli,
    StepzenConfig,
    StepzenConfigYaml,
    StepzenLogin,
)

debug_level = 0

logger = logging.getLogger("wxflows")


def cmd_setup(
    location: str,
    feature_flags: Optional[List[str]] = [],
    verbose: bool = False,
    command: str = "",
) -> CLIData:

    # defaults
    account = ""
    domain = ""
    password = ""

    for i in range(10):
        try:
            clidata = CLIData.create(
                location,
                feature_flags,
                verbose=verbose,
            )
            return clidata
        except CLIStepzenConfiguration as e:
            if str(e) != str(CLIStepzenConfigurationLogin) and str(e) != str(
                CLIStepzenConfigurationLoginBad
            ):
                raise
            if command in ["login", "whoami", "version"]:
                clidata = CLIData()  # invalid CLIData
                clidata.features_flags = feature_flags  # keep feature flags for the login command
                return clidata
            if command:
                raise

        try:
            _ = CLIData.login(
                account,
                domain,
                password,
                skip_tls_verify="skip-tls-verify" in (feature_flags or []),
            )
        except Exception as e:
            print("Please try again")
            logger.debug(f"login retry {e}")

    # retry a few times and then give up
    raise CLIError(
        f"Login failure on environment {account} in domain {domain} after repeated tries.   "
    )


def getspawnenv(
    cli: CLIData,
    toml_data: TOMLConfiguration,
) -> Dict[str, str]:
    # pass in current env to stepzen deploy
    env = os.environ.copy()
    # copy in our copy of values including overrides
    # may duplicate some STEPZEN_ values but we must get autoinjected ones.
    for k in cli.env_values:
        v = cli.env_values.get(k)
        if v is not None:  # if value is empty, then skip
            env[k] = v
    # for now, add in certain TOML values.
    pattern_env = toml_data.pattern_env()
    if not pattern_env:
        return env

    # could do pattern_env.update(env)
    logger.debug(f"Appending {len(pattern_env)} env vars from TOML")

    for k in pattern_env:
        if k not in env:
            env[k] = pattern_env[k]
    return env


def public_query_access_policy(public_queries: Optional[List[str]]):
    if not public_queries:
        return {}
    public_queries = [str(x) for x in public_queries]  # toml to str
    access_policy = {
        "policies": [
            {
                "type": "Query",
                "policyDefault": {"condition": False},
                "rules": [
                    {
                        "name": "allowed",
                        "fields": public_queries,
                        "condition": "true",
                    }
                ],
            }
        ]
    }
    logger.debug(f"Access policy: {json.dumps(access_policy)}")

    return access_policy


README_WD = """
This folder contains a dump of the schema and configuration file as:
- dump.schema.json - schema in deploy format
- dump.schema.yaml - included since it the content is more readable
- dump.config.yaml - configuration as deployed (with env substitutions)
  - only if --working-directory-unsafe-dump-final-config-yaml is specified as this is unsafe.
"""


def dump_for_deploy(
    endpoint_name: str,
    working_directory: Optional[str],
    want_config: Optional[bool],
    foundation: FlowFoundation,
):
    if not working_directory:
        return

    # use read/write owner only for all files
    def custom_opener(path, flags):
        return os.open(path, flags, mode=0o600)

    logger.debug(f"dump files to '{working_directory}'")
    real_wd = Path(working_directory)  # convert to absolute
    real_wd_abs = real_wd.absolute()  # convert to absolute
    if foundation.endpoint_schema:
        logger.debug(f"stepzen.config.json written with {endpoint_name}")
        with open(real_wd.joinpath("stepzen.config.json"), "w") as f:
            f.write(json.dumps({"endpoint": endpoint_name}, indent=4) + "\n")
        for item in foundation.endpoint_schema.schema_files().get("files", []):
            name = item.get("name")
            if not name:
                raise CLIError("internal consistency error: schema file is missing name")
            path = real_wd.joinpath(Path(name))
            # this should mask any .. references and ensure file does not
            # extend outside of the working_directory
            abspath = path.absolute()
            if not str(abspath).startswith(str(real_wd_abs)):
                raise CLIError(
                    f"illegal: {name} would extend beyond the directory {working_directory}"
                )
            os.makedirs(path.parent, 0o700, exist_ok=True)
            with open(path, "w", opener=custom_opener) as f:
                f.write(item.get("content", ""))

    def multiline(dumper, data):
        if "\n" in data:
            return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
        return dumper.represent_scalar("tag:yaml.org,2002:str", data)

    yaml.add_representer(str, multiline, Dumper=yaml.SafeDumper)

    if foundation.configuration_data:
        config_yaml = os.path.join(working_directory, "config.yaml")
        with open(config_yaml, "w", opener=custom_opener) as f:
            if want_config:
                # this is exactly what is used for deploy
                logger.debug(f"{config_yaml} written with secrets")
                yaml.safe_dump(foundation.configuration_data.get_configuration(), f)
            else:
                # will emit public_queries and identity
                # will not emit custom configuration values like:
                #  [wxflows.deployment.endpoint]
                #  configuration.name.key="value"
                # we should remove this feature since it's not published, unneeded and unsafe anyway?
                logger.debug(f"{config_yaml} written")
                yaml.safe_dump(foundation.configuration_data.data, f)


async def process_deployment(
    endpoint_deployment: Optional[Mapping[str, Any]], foundation: FlowFoundation
):
    """
    allow deployment (from config.yaml) to pas through
    """
    if not endpoint_deployment:
        return
    data = endpoint_deployment.get("identity", {})
    logger.debug(f"deployment.identity {data}")
    if not foundation.configuration_data:  # CLEAN
        foundation.configuration_data = StepzenConfig(None)
    foundation.configuration_data.set_value("deployment", {"identity": data})


def process_toml_configuration(
    endpoint_configuration: Optional[Mapping[str, Any]], foundation: FlowFoundation
):
    """
        configuration in the form:
    [wxflows.deployment.]
    configuration.joe.f="a"
    configuration.joe.y="a"
    where joe is the configuration name, are the named values.
    """
    if not endpoint_configuration:
        return
    for config_name, kv in endpoint_configuration.items():
        foundation.add_configuration(config_name, kv)
        logger.debug(f"configuration: adding {','.join([k for k in kv])} to {config_name}")

    pass


class LocalBaseModel(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)


class ExtensionInformation(LocalBaseModel):
    # information extracted from an extension
    schema_files: List[SchemaFileData]
    stepzen_config: Dict[str, Any] = {}
    config: Optional[Dict[str, Any]] = {}
    index: Optional[str] = None
    # overload SchemaFileData for now.
    flow_files: Optional[List[SchemaFileData]] = None
    data_hash: Optional[str] = None
    zip_info: Optional[List[Dict[str, Union[str, int]]]] = None

    # endpoint imports
    endpoint_imports: Dict[str, Any]

    def get_flow(self) -> List[str]:
        if not self.flow_files:
            return []
        data = []
        for afile in self.flow_files:
            data.append(afile.content)
        return data

    def get_flow_names(self) -> List[str]:
        if not self.flow_files:
            return []
        data = []
        for afile in self.flow_files:
            data.append(afile.name)
        return data


# make a version of this that just packs a zip file
def user_directory_package_zip(
    location: str,
    overlay: bool = False,
    remove_root: bool = False,
    subfolder: str = "",
) -> Tuple[io.BytesIO, str]:
    # use pydantic for return value vs. tuple of size 4
    stem = Path(location).stem

    mem = io.BytesIO()
    if not os.path.exists(location):
        raise CLIError(f"import directory: {location} is missing")
    digest = hashlib.sha256()
    trackdata = {"files": [], "location": location}
    with zipfile.ZipFile(mem, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for root, dir, files in os.walk(location, followlinks=True):
            if remove_root:
                dirname = Path(root).relative_to(location)  # truncate
            else:
                # use last element of location (stem)
                dirname = Path(stem).joinpath(Path(root).relative_to(location))
                dirname = Path(subfolder).joinpath(dirname)
            for item in files:
                ext = os.path.splitext(item)[1]
                ok = ext in [".fdl", ".graphql", ".yaml", ".json", ".md", ".txt"]
                if not ok:
                    continue
                name = Path(root).joinpath(item)
                if name.is_file():
                    # skip our internal metadata
                    data = name.read_text()
                    stats = name.stat()
                    trackdata["files"].append(
                        {
                            "name": name.as_posix(),
                            "stats": {
                                "size": stats.st_size,
                                "ctime": stats.st_ctime,
                                "mtime": stats.st_mtime,
                            },
                        }
                    )
                    digest.update(name.as_posix().encode("utf-8"))
                    digest.update(data.encode("utf-8"))
                    zf.writestr(dirname.joinpath(item).as_posix(), data)
    logger.debug(f"HASH {digest.hexdigest()}")
    hdig = digest.hexdigest()
    trackdata["hash"] = hdig
    if "WXFLOWS_TRACK_DIRECTORY" in os.environ:
        with open("METADATA.json", "w") as f:
            json.dump(trackdata, f)
    return mem, hdig


# make a version of this that just packs a zip file
def user_directory(
    location: str,
    overlay: bool = False,
    remove_root: bool = False,
    subfolder: str = "",
) -> Optional[ExtensionInformation]:
    # use pydantic for return value vs. tuple of size 4
    stem = Path(location).stem
    config: Optional[Dict[str, Any]] = None
    sfds: Optional[List[SchemaFileData]] = []
    flows_sfd: Optional[List[SchemaFileData]] = []

    if os.path.exists(os.path.join(location, "config.yaml")):
        with open(os.path.join(location, "config.yaml")) as f:
            config = yaml.safe_load(f)

    # return index if not overlay and file exists
    index: Optional[str] = None
    if not overlay:
        # note: this will only work with lowercase!
        # priority goes to latest atom.graphql model
        pindex: Optional[Path] = None
        if os.path.exists(os.path.join(location, "atom.graphql")):
            pindex = Path(stem).joinpath("atom.graphql")
        elif os.path.exists(os.path.join(location, "index.graphql")):
            pindex = Path(stem).joinpath("index.graphql")
        if pindex:
            if subfolder:
                pindex = Path(subfolder).joinpath(pindex)
            index = str(pindex)  # convert

    for root, dir, files in os.walk(location, followlinks=True):
        flows = [item for item in files if os.path.splitext(item)[1] == ".fdl"]
        graphql = [item for item in files if os.path.splitext(item)[1] == ".graphql"]
        if not graphql and not flows:
            continue
        if remove_root:
            dirname = Path(root).relative_to(location)  # truncate
        else:
            # use last element of location (stem)
            dirname = Path(stem).joinpath(Path(root).relative_to(location))
            dirname = Path(subfolder).joinpath(dirname)
        for item in graphql:
            name = Path(root).joinpath(item)
            if name.is_file():
                sfd = SchemaFileData(dirname.joinpath(item).as_posix(), name.read_text())
                sfds.append(sfd)
        for item in flows:
            name = Path(root).joinpath(item)
            if name.is_file():
                sfd = SchemaFileData(dirname.joinpath(item).as_posix(), name.read_text())
                flows_sfd.append(sfd)
    return ExtensionInformation(
        schema_files=sfds,
        index=index,
        config=config,
        flow_files=flows_sfd,
        endpoint_imports={},
    )


async def download_url(url: str) -> bytes:
    """put this in a shared place later"""
    parts = urlparse(url)
    if not (parts.scheme == "http" or parts.scheme == "https"):
        raise CLIError(f"{parts.scheme} for {url} is not implemented")
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(url, follow_redirects=True)
    return r.content


async def is_zip_package(thedir: str, package: Optional[str]) -> Optional[io.BytesIO]:
    """a bit inefficient but keeps code down"""
    if not package:
        return None
    if package.startswith("http:") or package.startswith("https:"):
        # urllib
        logger.debug(f"Download package from {package}")
        return io.BytesIO(await download_url(package))
    if os.path.isfile(thedir):
        with open(thedir, "rb") as f:
            logger.debug(f"Read local package from {thedir}")
            return io.BytesIO(f.read())
    return None


def get_adjusted_zip(zipf: zipfile.ZipFile, zipfilename: str) -> Optional[ExtensionInformation]:
    sfds = []
    bestp = None

    config = None

    zipinfo = []
    digest = hashlib.sha256()
    # walk zipfile and recover interesting data files
    for entry in zipf.infolist():
        logger.debug(entry.filename)
        if entry.is_dir():
            continue
        filename = PosixPath(entry.filename)
        # find a shortest parents path
        if not bestp or len(filename.parents) < len(bestp.parents):
            bestp = filename
        if filename.suffix not in [".graphql", ".fdl", ".yaml", ".md", ".txt", ".json"]:
            # skip any not in prescribed list for simplicity
            continue
        zts = int(time.mktime(entry.date_time + (0, 0, -1)))
        digest.update(entry.filename.encode("utf-8"))
        zipinfo.append(
            {
                "name": entry.filename,
                "modified": zts,
                "file_size": entry.file_size,
                "compress_size": entry.compress_size,
            }
        )
        with zipf.open(entry.filename, "r") as f:
            data = f.read().decode("utf-8")
            digest.update(data.encode("utf-8"))
        sfd = SchemaFileData(entry.filename, data)
        sfds.append(sfd)

    if not bestp:
        # can only happen if no files
        return None
    # discover config_yaml and index.graphql/atom.graphql perferred
    namelist = zipf.namelist()
    # nominal config_yaml and atom_graphql
    config_yaml = str(bestp.parent.joinpath("config.yaml"))
    if config_yaml not in namelist:
        config_yaml = None
    atom_graphql = str(bestp.parent.joinpath("atom.graphql"))
    logger.debug(f"ATOM {atom_graphql}")
    if atom_graphql not in namelist:
        atom_graphql = str(bestp.parent.joinpath("index.graphql"))
        logger.debug(f"ATOM {atom_graphql}")
        if atom_graphql not in namelist:
            atom_graphql = None

    # pull out the stepzenconfig.json
    stepzen_config_json = str(bestp.parent.joinpath("stepzen.config.json"))
    stepzen_config = {}
    if stepzen_config_json in namelist:
        logger.debug(f"stepzen.config.json at {stepzen_config_json}")
        name = str(bestp.parent.joinpath("stepzen.config.json"))
        with zipf.open(name, "r") as f:
            stepzen_config = json.load(f)

    if len(sfds) == 0:
        return None

    prefix_name = ["extensions"]
    if len(bestp.parents) == 1:  # only root
        print("get_adjust_zip: using filename as directory name")
        # use the filename
        prefix_name.append(os.path.splitext(os.path.basename(zipfilename))[0])

    splitter = {}
    for sfd in sfds:
        name = PosixPath(*prefix_name, sfd.name)
        if config_yaml and config_yaml == sfd.name:
            config_yaml = str(name)
            config = yaml.safe_load(sfd.content)
        if atom_graphql and atom_graphql == sfd.name:
            atom_graphql = str(name)
        sfd.name = str(name)
        route_type = name.suffix
        if route_type == "md" or route_type == "txt":
            route_type = "graphql"
        if route_type not in splitter:
            splitter[route_type] = []
        splitter[route_type].append(sfd)
    for ext in splitter:
        for sfd in splitter[ext]:
            logger.debug(f"zip: ext {ext}: {zipfilename}: {sfd.name} {len(sfd.content)}")
    hdig = digest.hexdigest()
    endpoint_imports = {}
    if config and "endpoint_imports" in config:
        endpoint_imports = config["endpoint_imports"]
    return ExtensionInformation(
        schema_files=splitter.get(".graphql", []),
        index=atom_graphql,
        config=config,
        flow_files=splitter.get(".fdl"),
        stepzen_config=stepzen_config,
        data_hash=hdig,
        zip_info=zipinfo,
        endpoint_imports=endpoint_imports,
    )


async def user_extensions(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    extensions: ExtensionsArguments,
    imported_extensions: Optional[List[SchemaFileData]],
    configuration_file: Optional[str],
    foundation: FlowFoundation,
) -> List[str]:
    """
    handle user extension files or configuration
    user_extensions_directory: Optional[str],
      directory of user extension files [need root, assume index.graphql]
      also inserts config.yaml
    imported_extensions: Optional[List[SchemaFileData]],
      list of SchemaFileData already imported
    returns list of flows
    """
    if imported_extensions is None:
        imported_extensions = []

    root = toml_data.toml_location()

    if configuration_file:
        logger.debug(f"Extension: configuration_file: {configuration_file}")
        nc = StepzenConfigYaml(configuration_file, getspawnenv(cli, toml_data))
        if nc:
            console.print(
                f"Configuration data: additional configuration loaded from {configuration_file}"
            )
            logger.debug(f"configuration override: {configuration_file}")
            foundation.edit_configuration(nc.data)

    sfds = imported_extensions
    flows = []
    if extensions.pattern_source_directories:
        # currently limited to 1 since it's not clear how multiple should be integrated
        # we could try to combine but each would have a `schema` and not a `extend schema`
        # so we would need to editting to ensure it's proper
        # likely, we'll just jam them together and let zenserv deal with it (it accepts
        # two `schema` directives?).
        for thedir in extensions.pattern_source_directories:
            thedir = os.path.join(root, thedir)
            # pattern_source_directory  will overlay this directory *onto* the schema.
            logger.debug(f"Extension: pattern source directory: {thedir}")
            # all the new entries should not be reported/logged.
            report_new = False
            data = user_directory(thedir, overlay=True, remove_root=True)
            if data:
                foundation.edit_add_overlay(
                    data.schema_files, None, data.config, report_new=report_new
                )
                xsfdlen = len(data.schema_files) if data.schema_files else 0
                logger.debug(f"finished pattern source addition {thedir} file count {xsfdlen}")
    if extensions.user_extension_directories:
        for thedir in extensions.user_extension_directories:
            odir = thedir
            thedir = os.path.join(root, thedir)
            zip_data = await is_zip_package(thedir, odir)
            if not zip_data:
                logger.debug(f"Extension: file: {thedir} using zip data")
                if not os.path.exists(thedir):
                    raise CLIError("invalid extension {thedir}")
                logger.debug(f"Extension: user directory: {thedir}")
                # subfolder is used to push down files a level from the root
                subfolder = "extension" if thedir == "" or thedir == "." else ""
                zip_data, hash = user_directory_package_zip(thedir, subfolder=subfolder)
                logger.debug(f"import: directory: hash {hash}")
            try:
                with zipfile.ZipFile(zip_data) as zipf:
                    data = get_adjusted_zip(zipf, thedir)
            except zipfile.BadZipFile:
                raise CLIError(f"extension {thedir} is not valid")

            if data:
                # console.print(f" Include extension {thedir}")
                foundation.edit_add_user_folder(data.schema_files, data.index, data.config)
                flows.extend(data.get_flow())
                logger.debug(f"user edit: {thedir} flows encountered {data.get_flow()}")

    logger.debug(f"user edit: {len(sfds)}/{len(imported_extensions)}")
    if sfds:
        foundation.edit(extensions=sfds)
    if flows:
        logger.debug(f"Found {len(flows)} in user_extensions")
    return flows


def generate_tool_sdl(tools: Any):
    """
    NAME.tool.description="...."
    NAME.tool.name
    NAME.tool.fields
    """

    dlines = []
    for toolinfo in tools:
        import_name = toolinfo[0]
        prefix = toolinfo[1]
        tool = toolinfo[2]
        name = tool.get("name") or import_name
        description = tool.get("description", name)
        fields = tool.get("fields")
        # root types is a regular expression
        root_types = tool.get("root_types")

        if not description:
            raise CLIError("tool calling requires a description, description not found")
        if not prefix:
            if not import_name and not fields:
                raise CLIError("tool calling requires field names")
            if not fields:
                raise CLIError("tool calling requires a prefix if fields is not specified")
        if not fields:
            # don't depend on prior check
            if not import_name:
                raise CLIError("tool calling requires field names")
            if not prefix:
                raise CLIError("tool calling requires a prefix if fields is not specified")
            fields = prefix + ".*"
        if '"' in name or '"' in fields:
            raise CLIError(
                f"double quotes not allowed in import {import_name}.tool.name or fields"
            )

        doquotedesc = '"""' if '"' in description else '"'
        if '"""' in description:
            raise CLIError(
                f"triple double quotes not allowed in import {import_name}.tool.description"
            )

        tool_args = (
            f'        {{name: "name", const: "{name}"}}\n'
            + f'        {{name: "description", const: {doquotedesc}{description}{doquotedesc}}}\n'
            + f'        {{name: "fields", const: "{fields}"}}\n'
        )
        if root_types and root_types.lower() != "query":
            tool_args += f'        {{name: "types", const: "{root_types}"}}\n'

        auuid = uuid.uuid4()
        tc_tools_field_supplier_name = f"wxflows_{str(auuid).replace('-','_')}_{name}"
        logger.debug(
            f"tc_tools_field supplies name {tc_tools_field_supplier_name} for {tool_args}"
        )
        dlines.append(
            f"    {tc_tools_field_supplier_name}"
            + """: TC_GraphQL
    @supplies(query: "tc_tools")
    @materializer(
      query: "tc_graphql_tool"
      arguments: [
"""
            + f"{tool_args}"
            + """      ]
    )
"""
        )

    #
    dlines_exp = "\n".join(dlines)
    # alternate is to pass in description and set a default argument
    # but that may just create confusion.   Better to separate the two use cases for now
    # [wxflows definition time vs. client definition time]
    bffTool = (
        """extend type Query { 
"""
        + dlines_exp
        + """
}"""
    )
    return bffTool


async def graphql_import_endpoints(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    login: StepzenLogin,
    toml_endpoints: Union[Mapping[str, Mapping[str, Any]], List[Mapping[str, Any]]],
    only_tools: List[Mapping[str, Any]],
    env: Any,
    foundation: FlowFoundation,
) -> Tuple[List[SchemaFileData], List[str]]:
    """[wxflows.deployment.endpoint.imports]
    NAME.url="https:..."
    NAME.prefix=""
    NAME.apikey_envname=""  # None - key, "" "_api_key_" for env apikey, "_admin_key_" for admin else name of env
    # carry through these (as actual values only)
    NAME.header.key=value

    # Tool calling helper
    NAME.tool.description="...."
    NAME.tool.name
    NAME.tool.fields

    # if NAME.tools.description exists, then the schema is extended to
    # include the query wxflows_BFFTool that can be used to the tool
    # calling definitions using tc_graphql_tools based upon NAME.tool
    # specifications.
    # NAME.tool.description is required
    # NAME.tool.name defaults to NAME
    # NAME.tool.fields defaults to {NAME.prefix}.*
    #     All fields for a specific import (NAME) are expected to use
    #     use the prefix if it exists; it is prepended if not.
    #

    # also accept:
    [[wxflows.deployment.endpoint.tools]]
    name = "math"
    description = "DO math"
    fields="abc,def"
    """

    # for now, rewrite the array form as dict form with index as keys
    # later drop the dict form?
    if not isinstance(toml_endpoints, Mapping):
        nendpt = {}
        for idx, item in enumerate(toml_endpoints):
            nendpt[f"_{idx}_"] = item
        endpoints = nendpt
    else:
        endpoints: Mapping[str, Mapping[str, Any]] = toml_endpoints
    flows = []
    introspection = IntrospectionServices(login)
    schemas = []
    data = None
    if not endpoints:
        endpoints = {}
    bff_tools = []
    for idx, name in enumerate(endpoints):
        endpoint = endpoints[name]
        apikey_envname = endpoint.get("apikey_envname")
        if apikey_envname is not None:
            if not apikey_envname:
                apikey_envname = "STEPZEN_WXFLOWSUSER_APIKEY"
            elif apikey_envname == "_api_key_":
                apikey_envname = "STEPZEN_WXFLOWSUSER_APIKEY"
            elif apikey_envname == "_admin_key_":
                apikey_envname = "STEPZEN_WXFLOWSUSER_ADMINKEY"
        headers = introspection.apikey_header(
            env.get(apikey_envname, None), endpoint.get("header")
        )
        allowed = ["directory", "openapi", "extension", "package", "url", "stepzen"]
        atypes = [other for other in endpoint if other in allowed]
        if len(atypes) == 0:
            raise CLIError(f"one of {','.join(allowed)} must be specified")
        if len(atypes) > 1:
            if sorted(atypes) != ["directory", "package"] and sorted(atypes) != [
                "package",
                "stepzen",
            ]:
                raise CLIError(
                    f"only one allowed of {','.join(allowed)} must be specified {' '.join(atypes)}"
                )

        displayable = ""
        if endpoint.get("url"):
            url = endpoint.get("url")
            prefix = endpoint.get("prefix")
            if not isinstance(url, str) or not (isinstance(prefix, str) or prefix is None):
                raise CLIError("invalid toml")
            urlparts = urlparse(url)
            thepath = urlparts.path
            if not urlparts.scheme and not urlparts.netloc:
                pathpartsl = len(thepath.split("/"))
                if pathpartsl != 2 and pathpartsl != 3:
                    raise CLIError(
                        "Expected the url to either be a full URL or just the endpoint name"
                    )
                url = f"https://{cli.account}.{cli.domain}/{thepath}"
                logger.debug(f'rewrite {endpoint.get("url")} to {url}')
                if pathpartsl == 2:
                    url += "/graphql"
                # autoinsert
                if not headers:
                    headers = introspection.apikey_header(
                        env.get("STEPZEN_WXFLOWSUSER_APIKEY", None), endpoint.get("header")
                    )
                displayable = f"URL {url} from {thepath}"
            else:
                displayable = f"URL {url}"
            print(f"Processing import {idx+1} {displayable}")
            try:
                sdl = await introspection.import_graphql(url, headers, prefix)
            except RuntimeError as e:
                if "HTTP Error (Unauthorized)" in str(e):
                    raise CLIError(
                        f"Access to an imported GraphQL endpoint {url} was denied.  "
                        "Either the endpoint does not exist or the proper APIKey was not provided"
                    )
                # expect that detailed info already printed.
                raise CLIError(f"An error occured accessing the GraphQL endpoint {url}")

            logger.debug(f"imported {name} with sdl length {len(sdl)} from {url}")
            schema = SchemaFileData(f"imported-graphql-{idx}.graphql", sdl)
            schemas.append(schema)
        elif endpoint.get("openapi"):
            schema_file = endpoint.get("openapi")
            prefix = endpoint.get("prefix")
            displayable = f"OpenAPI schema {schema_file}"
            if not isinstance(schema_file, str) or not (isinstance(prefix, str) or prefix is None):
                raise CLIError("invalid toml")
            print(f"Processing import {idx+1} {displayable}")
            with open(schema_file, "r") as f:
                spec = f.read()
            sdl, config = await introspection.import_openapi_schema(schema_file, spec, prefix)
            # ignore the config for now...
            if not sdl:
                raise CLIError("Import OpenAPI failed to generate a GraphQL schema.")
            logger.debug(
                f"imported {name} with sdl length {len(sdl)} from {schema_file} length {len(spec)} as  imported-openapi-{idx}.graphql"
            )
            schema = SchemaFileData(f"imported-openapi-{idx}.graphql", sdl)
            schemas.append(schema)

        elif endpoint.get("package") or endpoint.get("directory") or endpoint.get("stepzen"):
            # code is copied for now, later rethink how user-extension-directory is processed
            # path to consider: reform the argument as an import and prepend to the list
            thedir = endpoint.get("directory") or endpoint.get("package")
            if not thedir:
                if not endpoint.get("stepzen"):
                    raise CLIError("invalid toml - directory or package not set")
            else:
                root = toml_data.toml_location()
                thedir = os.path.join(root, thedir)

            zip_data = None
            runcmd = False
            hash = None

            if endpoint.get("directory") and thedir:
                subfolder = "extension" if thedir == "" or thedir == "." else ""
                displayable = f"Extension {thedir} "
                print(f"Processing import {idx+1} {displayable}")
                zip_data, hash = user_directory_package_zip(thedir, subfolder=subfolder)
                logger.debug(f"import: directory: hash {hash}")
            if not zip_data and endpoint.get("package") and thedir:
                if endpoint.get("stepzen"):
                    print(
                        f"Will not invoke stepzen since previously generated package {endpoint.get('packager')} exists"
                    )
                if not zip_data:
                    displayable = f"Package {endpoint.get('package')}"
                    print(f"Processing import {idx+1} {displayable}")
                zip_data = await is_zip_package(thedir, endpoint.get("package"))

            # if the package does not exist, then run stepzen command if it exists
            stepzen_cmd = endpoint.get("stepzen")
            if not zip_data and stepzen_cmd:
                displayable += f"stepzen_cmd {stepzen_cmd}"
                if not zip_data:
                    print(f"Processing import {idx+1} {displayable}")
                runcmd = True
                tdir = tempfile.TemporaryDirectory(prefix="wxflows_stepzen_")
                if tdir:
                    with open(os.path.join(tdir.name, "stepzen.config.json"), "w") as f:
                        f.write(json.dumps({"endpoint": "api/api"}))
                    prefix = "stepzen "
                    if stepzen_cmd.startswith("stepzen "):
                        prefix = ""
                    suffix = " --non-interactive"
                    if "--non-interactive" in stepzen_cmd:
                        suffix = ""
                    # unix and macos don't use shell
                    cmd = prefix + stepzen_cmd + suffix
                    if os.name.lower() in ["posix", "darwin"]:
                        args = shlex.split(cmd)
                        w = StepzenCli.exec(
                            args,
                            cwd=tdir.name,
                            shell=False,
                            env=getspawnenv(cli, toml_data),
                        )
                    else:
                        # windows attempt
                        w = StepzenCli.exec(
                            cmd,
                            cwd=tdir.name,
                            shell=True,
                            env=getspawnenv(cli, toml_data),
                        )
                    if w.returncode:
                        raise CLIError(f"{w.args} failed")
                    subfolder = ""
                    zip_data, hash = user_directory_package_zip(tdir.name, subfolder=subfolder)
                    logger.debug(f"import: stepzen: hash {hash}")
            if zip_data and thedir:
                logger.debug(f"Extension: file: {thedir} using zip data")
                try:
                    with zipfile.ZipFile(zip_data) as zipf:
                        data = get_adjusted_zip(zipf, thedir)
                except zipfile.BadZipFile:
                    raise CLIError(f"extension {thedir} is not valid")
            if data:
                # console.print(f" Include extension {thedir}")
                foundation.edit_add_user_folder(data.schema_files, data.index, data.config)
                flows.extend(data.get_flow())
                logger.debug(f"user edit: {thedir} flows encountered {data.get_flow()}")

            pkg = endpoint.get("packager")
            if zip_data and pkg:
                if endpoint.get("directory") or runcmd:
                    if os.path.exists(pkg):
                        print(f"Overwrite the package file {pkg}")
                    with open(pkg, "wb") as f:
                        f.write(zip_data.getbuffer())
                    print(f"Wrote the package file {pkg}")
        else:
            raise CLIError("internal error: no allowed import types found")
        tools = endpoint.get("tools", [])
        if data:
            ptools = data.endpoint_imports.get("tools", [])
            prefix = data.endpoint_imports.get("prefix", endpoint.get("prefix"))

            # list of names in TOML
            names = {tool.get("name"): tool for tool in tools if tool.get("name")}
            for ptool in ptools:
                name = ptool.get("name")
                if names.get(name):
                    # merge
                    logger.debug(f"Updating package {name} from toml")
                    ptool.update(names.get(name))  # toml has priorty
            # new tools are those that were not merged into ptools
            ptools_names = [tool.get("name") for tool in ptools if tool.get("name")]
            # stools are only in TOML
            stools = [
                tool
                for tool in tools
                if not tool.get("name") or tool.get("name") not in ptools_names
            ]
            if ptools:
                logger.debug(f"Added {' '.join(ptools_names)}")
        else:
            ptools = []
            stools = tools
            prefix = endpoint.get("prefix")

        # ptools should only be defined in the ext (directory), package, and stepzen_cmd cases.
        got = []
        for tool in ptools:
            if tool and tool.get("description") and tool.get("name"):
                name = tool.get("name")
                logger.debug(f"import: {name} {endpoint} tools available defined in configuration")
                got.append(name)
                bff_tools.append([name, prefix, tool])
        if got:
            print(
                f"configuration in import {idx+1} {displayable} defined {len(got)} tools: {' '.join(got)}"
            )
        for tool in stools:
            if tool and tool.get("description"):
                logger.debug(f"import: {name} {endpoint} tools available defined in wxflows.toml")
                bff_tools.append([name, prefix, tool])

    standalone_tools = [("", "", tool) for tool in only_tools]
    if standalone_tools:
        bff_tools.extend(standalone_tools)
    if bff_tools:
        tool_sdl = generate_tool_sdl(bff_tools)
        logger.debug(f"import: tool_sdl {tool_sdl}")
        if tool_sdl:
            schema = SchemaFileData("imported-graphql-tools-bff.graphql", tool_sdl)
            schemas.append(schema)
    return schemas, flows


def process_flowfiles(root: str, flow_files: List[str]) -> Tuple[List[str], List[str]]:
    """
    process_flowfiles will process a list of flow files names or references
    """

    logger.debug(f"Process_flowfiles {root} {flow_files}")
    names: List[str] = []
    flows_data: List[str] = []
    for flow_file in flow_files:
        parts = urlparse(flow_file)
        if parts.scheme == "" or parts.scheme == "file":
            logger.debug(f"Processing flow file {os.path.join(root, parts.path)}")
            if os.path.exists(os.path.join(root, parts.path)):
                with open(os.path.join(root, parts.path)) as f:
                    data = f.read()
                flows_data.append(data)
                names.append(flow_file)
            else:
                raise CLIError(f"file {flow_file} does not exist")
        elif parts.scheme == "http" or parts.scheme == "https":
            logger.debug(f"Processing flow file {flow_file}")

            async def get_data(url):
                async with httpx.AsyncClient(timeout=20) as client:
                    r = await client.get(url, follow_redirects=True)
                    return r.text

            try:
                data = asyncio.run(get_data(flow_file))
            except httpx.ConnectError as e:
                raise CLIError(f"Retrieving flow from {flow_file}: Could not connect: {e}")
            except Exception as e:
                raise CLIError(f"Error retrieving {flow_file}: {e}")
            names.append(flow_file)
            flows_data.append(data)
        else:
            raise CLIError(f"file {flow_file} not supported")
    return names, flows_data


def get_deploy_flows(
    console: Any,
    toml_data: TOMLConfiguration,
    arg_flows: Optional[List[str]],
    flow_files: Optional[List[str]],
) -> List[str]:
    """list of deployed flows"""

    # the configured flows in the TOML file should be one long string.
    configured_flows_data = toml_data.deployment_flows()
    configured_flows = []
    configured_flow_files = toml_data.deployment_flow_files()

    class Blanker:
        def __init__(self):
            self.blanked = False

        def do_blank(self):
            if not self.blanked:
                console.print("")
                self.blanked = True

        def do_blank_if_blank_issues(self):
            if self.blanked:
                console.print("")

    blanker = Blanker()
    if configured_flows_data and len(configured_flows_data) > 0:
        blanker.do_blank()
        console.print("Found flow definition in the configuration")
        configured_flows.append(configured_flows_data)

    if arg_flows and len(arg_flows) > 0:
        blanker.do_blank()
        console.print(
            f"Found {len(arg_flows)} command line flow{'s' if len(arg_flows) > 1 else ''}"
        )
        for flow in arg_flows:
            # console.print(f"  {flow}")
            logger.debug(f"flow: {flow}")
        configured_flows.extend(arg_flows)  # add MORE

    flow_file_data = []
    if configured_flow_files and len(configured_flow_files) > 0:
        blanker.do_blank()
        console.print(
            f"Found {len(configured_flow_files)} flow file{'s' if len(configured_flow_files) > 1 else ''} in the configuration"
        )
        names, data_arr = process_flowfiles(toml_data.toml_location(), configured_flow_files)
        flow_file_data.extend(data_arr)
        logger.debug(f"flows read from {names}")
        pass

    if flow_files and len(flow_files) > 0:
        blanker.do_blank()
        console.print(
            f"Found {len(flow_files)} flow file{'s' if len(flow_files) > 1 else ''} as an argument"
        )
        names, data_arr = process_flowfiles(toml_data.toml_location(), flow_files)
        flow_file_data.extend(data_arr)
        logger.debug(f"flows read from {names}")
        pass
    blanker.do_blank_if_blank_issues()
    configured_flows = flow_file_data + configured_flows
    return configured_flows


def report_messages(messages: List[IntrospectionMessage]) -> bool:
    error = False
    for message in messages:
        if message.level == "Error":
            console.print(f"[red]{message.level}[/red]: {message.message}")
            error = True
        elif message.level == "Warning":
            console.print(f"[yellow]{message.level}[/yellow]: {message.message}")
        else:
            console.print(f"{message.level}: {message.message}")
        if message.location:
            console.print(message.location)
    return error


def cmd_graph_deploy_zenctl(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    extensions: ExtensionsArguments,
    stepzen_configuration_file,
    arg_flows: Optional[List[str]],
    flow_files: Optional[List[str]],
    working_directory: str = "",
    dump_config: Optional[bool] = False,
    expert: bool = False,
):
    # DROPPED from gcp: preexisting_endpoint, endpoint import (redone)
    pattern = toml_data.pattern()
    endpoint_name = toml_data.endpoint_name()

    public_queries = toml_data.deployment_public_queries()

    endpoint = toml_data.deployment_endpoints()
    if not stepzen_configuration_file:  # cmd line wins
        stepzen_configuration_file = toml_data.deployment_configuration_file()

    logger.debug(f"deploying... {pattern} {endpoint_name}")
    deploy_flows = get_deploy_flows(console, toml_data, arg_flows, flow_files)
    login = StepzenLogin(
        cli.account,
        cli.domain,
        cli.adminkey,
        service_instances=cli.service_instance,
        skip_tls_verify=cli.is_feature("skip-tls-verify"),
    )
    if cli.is_feature("introspection-steprz"):
        print("introspection-steprz")
        login.edit(StepzenLogin.INTROSPECTION_STAGING)

    env = getspawnenv(cli, toml_data)

    console.print("[bold]Provisioning the watsonx Flows Engine environment[/bold]")

    async def dorun():
        have_pattern_source = (
            extensions.pattern_source_directories
            and len(extensions.pattern_source_directories) > 0
        )

        foundation = await FlowFoundation.create(
            pattern, login, env, use_pattern=not have_pattern_source
        )
        if public_queries and foundation.configuration_data:  # clean peek
            foundation.configuration_data.set_value(
                "access", public_query_access_policy(public_queries)
            )

        imported_extensions, import_flows = await graphql_import_endpoints(
            cli,
            toml_data,
            login,
            endpoint.imports_and_extensions(),
            endpoint.tools_list(),
            env,
            foundation,
        )

        # these edit the configuration and may add user specific values
        # which will get added to the base.  That has to be okay
        # but that means we can never trust the base to have a "safe" configuration
        extension_flows = await user_extensions(
            cli,
            toml_data,
            extensions,
            imported_extensions,
            stepzen_configuration_file,
            foundation,
        )
        process_toml_configuration(endpoint.configuration, foundation)
        dump_for_deploy(
            endpoint_name, working_directory, dump_config, foundation
        )  # extra dump in case of an error
        await process_deployment(endpoint.deployment, foundation)
        pub = FlowsPublisher(foundation, login)
        try:
            result = await pub.deploy(endpoint_name, deploy_flows + import_flows + extension_flows)
            logger.debug(
                f"deploy count {result.flows_count()} {result.flows_names()}  {result.uri}"
            )

        except RuntimeError as e:
            raise CLIError("An error occurred while deploying the endpoint: " + str(e))

        # foundation is modified by FlowsPublisher to include flows
        # For now, that's good because we want to dump them.
        dump_for_deploy(endpoint_name, working_directory, dump_config, foundation)
        return result

    start = time.time()
    with console.status(f"Deploying the [yellow]{endpoint_name}[/yellow] endpoint..."):
        try:
            result = asyncio.run(dorun())
        except TimeoutError:
            raise CLIError(
                "API Connect for GraphQL services could not be reached due to a network timeout"
            )
        iter = ""
        report_messages(result.messages())
        # clean this up later
        if not result.deploy_result.stepzen_deploy:
            raise CLIError("error occurred while deploying flows")
            pass

        flow_cnt = result.flows_count()
        if flow_cnt < 0:
            raise CLIError("internal error: flow count is negative")

        # report results
        if flow_cnt == 0:
            console.print(f"Published {result.endpoint_url} in {round(time.time()-start,3)}s")
            logger.debug(f"Published {result.endpoint_url} in {round(time.time()-start,3)}s")
            return

        iter = "s" if flow_cnt > 1 else ""
        names = ", ".join(result.flows_names())
        console.print(
            f"Published flow{iter} {names} to {result.endpoint_url} in {round(time.time()-start,3)}s"
        )
        console.print("Use wxflows request to try out your flow:")
        help = "[--var-file <FILE>|--var argument_name=VALUE|--json JSON]"
        if flow_cnt == 1:
            console.print(f" wxflows request --flow-name {result.flows_names()[0]} {help}")
        else:
            console.print(f" wxflows request --flow-name FLOW_NAME {help}")
        logger.debug(
            f"Published flow{iter} {names} to {result.endpoint_url} in {round(time.time()-start,3)}s"
        )


def _get_toml(location: str) -> Tuple[str, tomlkit.TOMLDocument]:
    """get toml loads toml from specified location (directory or file )"""
    tf = None
    if os.path.isfile(location):
        tf = location
    else:
        if os.path.isfile(os.path.join(location, _WATZENTOML)):
            tf = os.path.join(location, _WATZENTOML)
    if not tf:
        raise CLIError(f"{_WATZENTOML} file not found in '{location}'")

    with open(tf, "rb") as f:
        tomldata = tomlkit.parse(f.read())
    output_directory = os.path.dirname(tf)
    return output_directory, tomldata


def _resolve_path(relative_or_absolute_path, base_directory):

    # limit to these cases  or else will cause issues on windows
    if "://" in relative_or_absolute_path and (
        relative_or_absolute_path[0] != "."
    ):  # is it a URI?
        parsed_url = urlparse(relative_or_absolute_path)
        if parsed_url.scheme:
            return relative_or_absolute_path

    if os.path.isabs(relative_or_absolute_path):
        # Return the path as-is if it's absolute
        return relative_or_absolute_path
    else:
        # Resolve the path relative to the base_directory
        return os.path.normpath(os.path.join(base_directory, relative_or_absolute_path))


def cmd_deploy(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    extensions: ExtensionsArguments,
    stepzen_configuration_file: Optional[str],
    collection_name: Optional[str],
    flows: Optional[List[str]],
    flow_files: Optional[List[str]],
    working_directory: str,
    dump_config: Optional[bool],
    collection_mode: str,
):
    if toml_data.deployment_ai_engine() == "BAM":
        if not cli.is_feature("allow-bam-access"):
            print("The BAM service sunsets September 1, 2024")
            raise CLIError("BAM is no longer accessible via wxflows")

    do_deploy = not cli.is_feature("skip-flow-deploy")
    if do_deploy:
        cmd_graph(
            cli,
            "deploy",
            toml_data,
            extensions,
            stepzen_configuration_file,
            flows,
            flow_files,
            working_directory,
            dump_config,
        )
    """run collection and graph deploy"""
    # keep deploy simple and use defaults.
    if collection_mode == "skip":
        return
    console.print("")
    cmd_collection(cli, "deploy", toml_data, collection_name, collection_mode, False)

    pass


def cmd_graph(
    cli: CLIData,
    subcommand: str,
    toml_data: TOMLConfiguration,
    extensions: ExtensionsArguments,
    stepzen_configuration_file: Optional[str],
    flows: Optional[List[str]],
    flow_files: Optional[List[str]],
    working_directory: str = "",
    dump_config: Optional[bool] = False,
):
    """
    build or deploy based on location/wxflows.toml or location (as a toml)
    """

    logger.debug("[wxflowscli]")
    if working_directory:
        os.makedirs(working_directory, exist_ok=True)
    cmd_graph_deploy_zenctl(
        cli,
        toml_data,
        extensions,
        stepzen_configuration_file,
        flows,
        flow_files,
        working_directory=working_directory,
        dump_config=dump_config,
    )


def cmd_collection(
    cli: CLIData,
    subcommand: str,
    toml_data: TOMLConfiguration,
    collection_name: Optional[str],
    collection_mode: Optional[str],
    direct: bool = True,
):
    """
    run collection processes (remotely)
    direct = True if called directly, else as a cmd_deploy which we'll use to effect
    slight behavior differences.

    TODO: add in cli object, use that instead of calling get_stepzen_admin
    """
    output_directory = toml_data.toml_location()
    pattern = toml_data.pattern()
    if pattern == "graphql":
        return  # nothing to do

    if toml_data.pattern_data() is None:
        if direct:  # more info
            print(f"missing deployment section for {pattern} wxflows.deployment.{pattern}")
            print("Stopping...")
        return

    if not collection_mode:
        collection_mode = "replace"

    # if we got this far, we must have collection and embedding_model
    collection = toml_data.pattern_collection()
    if not collection:
        raise CLIError("Missing collection name!  wxflows.deployment.collection")
    # let this override
    if collection_name:
        collection = collection_name
    drop = collection_mode == "drop"

    tsv_files = toml_data.pattern_tsv_files()
    if not tsv_files:
        if drop:
            # make it usable
            tsv_files = []
        else:
            if direct:  # more info
                print("No input data was initialized so the collection deploy is being skipped")
                print("Stopping...")
            return

    embedding_model = toml_data.pattern_embedding_model()
    if not drop and not embedding_model:
        raise CLIError(f"embedding model is required!  wxflows.deployment.{pattern}")

    account = cli.account_domain

    console.print(f"Creating or updating the [bold]{collection}[/bold] collection")

    docstore = toml_data.pattern_docstore()
    if not docstore:
        raise CLIError(
            f"This pattern {toml_data.pattern()} either does not support uploads or is missing documentstore information"
        )
    else:
        # later: pickup the first listed even if type is not listed
        docstore_type = docstore.type()
        docstore_data_file = docstore.data_file()
        docstore_subtype = docstore.subtype()

    if not docstore.type():
        raise CLIError("--document-store must be set in order to upload data")

    # since the fallback for search_engine is docstore type this
    # is a pointless check except for pyright...
    search_engine = toml_data.pattern_search_engine()
    if not search_engine:
        raise CLIError("search_engine is not known")
    zup = _get_vup(cli, toml_data, account, "documentstore")

    consolemsg = ""
    if docstore_data_file:
        consolemsg += " datafile {docstore_data_file}"
    if docstore_subtype:
        console.print(
            f"Using {zup.endpoint} for{consolemsg} search engine type: {docstore_type}.{docstore_subtype}"
        )
    else:
        console.print(f"Using {zup.endpoint} for{consolemsg} search engine type: {docstore_type}")

    upload_and_process_local(
        console,
        cli,
        None,  # TODO
        zup,
        account,
        [_resolve_path(name, output_directory) for name in tsv_files],
        collection,
        embedding_model,
        docstore_data_file,
        docstore_type,
        docstore_subtype,
        search_engine,
        True,
        True,
        collection_mode,
    )
