# Copyright IBM Corp. 2023, 2025
import ast
import json
import logging
import os
import platform
from typing import Any, Dict, List, Optional, cast

import pandas as pd
from datasets import Dataset, load_dataset
from packaging import version
from zenai_sdk.stepzen_services import StepzenCli

from ._cli_clidata import CLIData
from .cli_error import CLIError
from .configuration import TOMLConfiguration

logger = logging.getLogger("wxflows")


def request(field: str):
    return f"""
query rag(
  $question: String!
  $collection: String!
  $searchEngine: SearchEngine!
  $nRetrieved: Int!
  $aiEngine: AIEngine!
  $model: String!
  $parameters: GenParametersInput
  $promptTemplate: String
  $contextTemplate: String
) {{
  {field}(
    question: $question
    collection: $collection
    searchEngine: $searchEngine
    n: $nRetrieved
    aiEngine: $aiEngine
    model: $model
    parameters: $parameters
    promptTemplate: $promptTemplate
    contextTemplate: $contextTemplate
  ) {{
    out
  }}
}}
"""


def get_answer_and_retrieved_contexts(
    endpoint: str,
    question: str,
    field: str,
    collection: str,
    # Python uses the declared default parameter value if the parameter is not
    # provided at all, but not when it's provided with the value None. Since we
    # want to treat both cases in the same way, the defaults are defined in the
    # code block below.
    searchEngine: Optional[str] = None,
    nRetrieved: Optional[int] = None,
    aiEngine: Optional[str] = None,
    model: Optional[str] = None,
    parameters: Optional[Dict[str, Any]] = None,
    promptTemplate: Optional[str] = None,
    contextTemplate: Optional[str] = None,
):
    vars = {
        "question": question,
        "collection": collection,
        "searchEngine": f'"{searchEngine or "GETTINGSTARTED"}"',
        "nRetrieved": nRetrieved or 3,
        "aiEngine": f'"{aiEngine or "WATSONX"}"',
        "model": model or "ibm/granite-3-8b-instruct",
        "parameters": json.dumps(parameters or {"max_new_tokens": 350}),
        "promptTemplate": promptTemplate,
        "contextTemplate": contextTemplate,
    }

    retries = 0
    if os.name == "nt":
        stepzen_cmd = "stepzen.cmd"
    else:
        stepzen_cmd = "stepzen"
    while retries < 5:
        retries += 1
        try:
            cmd = [
                stepzen_cmd,
                "request",
                request(field),
                f"--endpoint={endpoint}",
                *[f"--var={name}={vars[name]}" for name in vars if vars[name]],
            ]
            logger.debug(f"calling {cmd}")
            response = StepzenCli.exec(cmd)
            response_json = json.loads(response.stdout.decode("utf-8"))
            data = response_json.get("data")

            if data and data.get(field):
                ragOp = data[field]["out"]
                return {
                    "answer": (
                        ragOp["modelResponse"]["results"][0]["generated_text"]
                        if len(ragOp["modelResponse"]["results"]) > 0
                        else ""
                    ),
                    "prompt": ragOp["prompt"],
                    "contexts": (
                        [x["text"] if x["text"] else "" for x in ragOp["contexts"]]
                        if len(ragOp["contexts"]) > 0
                        else [""]
                    ),
                }

        except Exception as e:
            print(e)
            print("Retrying...")
    return {"answer": "RAG pipeline FAILED", "contexts": [""]}


def override_if_not_none(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    return {
        **a,
        **{k: v for k, v in b.items() if v},
    }


def get_permutations(
    defaults: Dict[str, Any], variations: Optional[str] = None
) -> List[Dict[str, Any]]:
    permutations = []
    if variations:
        vdf = cast(
            pd.DataFrame,
            cast(Dataset, load_dataset("csv", data_files=variations, split="train")).to_pandas(),
        )

        series = dict(
            [
                (
                    name,
                    pd.concat(
                        [
                            # always have one None (i.e. the default value)
                            pd.Series([None]),
                            # and ignore all other empty cells in the column
                            vdf[name].loc[lambda s: s.notna()],
                        ],
                        ignore_index=True,
                    ),
                )
                for name in [
                    "nRetrieved",
                    "collection",
                    "model",
                    "parameters",
                    "promptTemplate",
                ]
            ]
        )

        for nRetrieved in series["nRetrieved"]:
            for collection_str in series["collection"]:
                searchEngine, collection = (
                    collection_str.split("::") if collection_str else (None, None)
                )
                for model_str in series["model"]:
                    aiEngine, model = model_str.split("::") if model_str else (None, None)
                    for parametersStr in series["parameters"]:
                        parameters = json.loads(parametersStr) if parametersStr else None
                        for template in series["promptTemplate"]:
                            permutations.append(
                                override_if_not_none(
                                    defaults,
                                    {
                                        "nRetrieved": nRetrieved,
                                        "collection": collection,
                                        "searchEngine": searchEngine,
                                        "aiEngine": aiEngine,
                                        "model": model,
                                        "parameters": parameters,
                                        "promptTemplate": template,
                                    },
                                )
                            )
    else:
        permutations.append(defaults)

    return permutations


def cmd_eval_collect(
    cli: CLIData,
    subcommand: str,
    toml_data: TOMLConfiguration,
    flow: str,
    question_set: str,
    output: Optional[str] = None,
    variations: Optional[str] = None,
    num_proc: int = 10,
    limit: int = 0,
):
    """
    Collect a dataset to evaluate quality of a RAG pipeline.

    Needs a dataset with question / expected answer rows.
    The output file can be later used to compute RAG quality metrics
    (see support/rag-evaluation in this repo).

    wxflows eval collect \
        --wxflows-configuration wxflows.toml \
        --question-set path/to/questions.csv \
        --variations path/to/variations.csv \
        --output path/to/output
    """

    endpoint = toml_data.endpoint_name()

    collection = toml_data.pattern_collection()
    if not collection:
        raise CLIError("Evaluation is currently implemented only for RAG pipelines")
    watzen_rag = toml_data.pattern_data()  # AVOID
    toml_defaults = {
        "nRetrieved": watzen_rag.get("n_retrieved"),
        "searchEngine": toml_data.pattern_search_engine(),
        "collection": toml_data.pattern_collection(),
        "aiEngine": toml_data.pattern_ai_engine(),
        "model": watzen_rag.get("model"),
        "parameters": watzen_rag.get("parameters"),
        "promptTemplate": watzen_rag.get("prompt_template"),
    }

    try:
        toml_defaults["parameters"] = (
            json.loads(toml_defaults["parameters"]) if toml_defaults["parameters"] else None
        )
    except json.JSONDecodeError:
        raise CLIError(
            "Invalid JSON in `parameters`. See wxflows.toml / [wxflows.deployment.aicore]"
        )

    if not toml_defaults["collection"]:
        raise CLIError(
            "`collection` is required for RAG pipeline evaluation."
            + " Please define it in wxflows.toml under [wxflows.deployment.aicore]"
        )

    if variations and not os.path.exists(variations):
        raise CLIError(f"The specified variations file does not exist: {variations}")

    if not os.path.exists(question_set):
        raise CLIError(f"The specified question set file does not exist: {question_set}")

    if not output:
        output = os.path.join(os.path.dirname(question_set), "eval-collect-results.csv")

    permutations = get_permutations(toml_defaults, variations)
    if len(permutations) > 1:
        # remove the .csv extension if present
        if output.endswith(".csv"):
            output = output[: -len(".csv")]

        if not os.path.exists(output):
            os.makedirs(output)
    else:
        if not output.endswith(".csv"):
            output = f"{output}.csv"

    ds = cast(Dataset, load_dataset("csv", data_files=question_set, split="train"))
    if limit:
        ds = ds.select(range(limit))

    for i, permutation in enumerate(permutations):
        if len(permutations) > 1:
            print(f"Processing variation {i+1} of {len(permutations)}:")
            print(f"{json.dumps(permutation, indent=2)}")

        result = ds.map(
            lambda x: {
                **x,
                **(permutation if len(permutations) > 1 else {}),
                **get_answer_and_retrieved_contexts(
                    endpoint=endpoint,
                    question=x["question"],
                    field=flow,
                    **permutation,
                ),
            },
            num_proc=min(limit, num_proc) if limit else num_proc,
            load_from_cache_file=False,
        )

        if len(permutations) > 1:
            result.to_csv(os.path.join(output, f"p{i}.csv"), index=False)
        else:
            result.to_csv(output, index=False)


# Function to convert string representation of a list to an actual list
def str_to_list(value):
    try:
        # Safely evaluate the string as a Python literal (list)
        return ast.literal_eval(value)
    except ValueError:
        # In case of error, return an empty list or some default value
        return []


def cmd_eval_ragas(
    cli: CLIData,
    subcommand: str,
    response_set: str,
    output: str,
    llm: str,
    limit: int = 0,
):
    """
    wxflows eval ragas \
        --response-set path/to/answers.csv \
        --output path/to/output.csv
    """

    try:
        from .eval import ragas  # pyright: ignore[reportMissingImports]

        ragas(response_set, output, llm, limit)
    except ImportError as e:
        logger.debug(e)
        message = (
            f"This command requires Python version >= 3.10 and is not installed. Current python version: {platform.python_version()}."
            if version.parse(platform.python_version()) < version.parse("3.10.0")
            else e.msg
        )
        raise CLIError(message)
