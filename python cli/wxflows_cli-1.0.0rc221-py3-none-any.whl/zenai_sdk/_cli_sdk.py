# Copyright IBM Corp. 2023, 2025

import asyncio
import copy
import datetime
import json
import logging
import os
import sys
import time
import uuid
from typing import Any, Dict, List, Optional

import chevron
import httpx
import rich
import yaml
from opentelemetry import trace
from opentelemetry.util.types import AttributeValue

from rich.json import JSON
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree

from .__about__ import __version__
from ._cli_clidata import CLIData
from .cli_error import CLIError
from .configuration import TOMLConfiguration
from .console import console
from .flows import execute_flow, execute_flow_databuild_utility, tools_info_async
from .stepzen_services import StepzenLogin

logger = logging.getLogger("wxflows")

tracer = trace.get_tracer("wxflows.cli")


def otel_basics() -> Dict[str, AttributeValue]:
    flows_wx: Dict[str, AttributeValue] = {
        "gen_ai.system": "ibm.watsonx.ai",
        "gen_ai.middleware": "wxflows.EXPERIMENTAL",
        "wxflows.version": __version__,
    }
    return flows_wx


def emulate_call(name: str, rest: bool, st: float, et: float):
    """
    internal test that records calls
    """
    if not any([t.startswith("trace") for t in os.environ.get("DEMO", "").split(",")]):
        return
    cs = trace.get_current_span()
    stus = int(st * 1000 * 1000 * 1000)
    etus = int(et * 1000 * 1000 * 1000)
    with open("dump_calls.txt", "a") as f:
        f.write(
            f"bash emulate_it.sh services_layer {name} {cs.get_span_context().trace_id} {cs.get_span_context().span_id} {stus} {etus}\n"
        )
    return


def cmd_sdk_execute(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    flow_names: str,
    max_depth: Optional[int],
    json_data: Optional[str],
    var_data: Optional[str],
    var_file: Optional[str],
    graphql_query: Optional[str],
):
    logger.debug(f"sdk_execute with {flow_names} {max_depth} {json_data}")
    if len(flow_names) == 0 or flow_names[0] == "":
        raise CLIError("You must specify a flow")
    login = StepzenLogin(
        cli.account,
        cli.domain,
        cli.apikey,
        service_instances=cli.service_instance,
        skip_tls_verify=cli.is_feature("skip-tls-verify"),
    )
    endpoint_name = toml_data.endpoint_name()
    url = login.endpoint_uri(endpoint_name)
    data = execute_flow_databuild_utility(json_data, var_data, var_file)
    result = execute_flow(
        flow_names[0],
        data,
        max_depth=max_depth,
        endpoint_url=url,
        endpoint_apikey=cli.apikey,
        query=graphql_query,
    )
    logger.debug(f"sdk_execute returns {result}")
    # this should be the only thing written to stdout...
    print(json.dumps(result, indent=4))

    if "errors" in result and "data" not in result:
        print(
            "You may use --var and --json to pass data into wxflows request",
            file=sys.stderr,
        )


def get_endpoint_url(cli: CLIData, toml_data: TOMLConfiguration) -> str:
    login = StepzenLogin(
        cli.account,
        cli.domain,
        cli.apikey,
        service_instances=cli.service_instance,
        skip_tls_verify=cli.is_feature("skip-tls-verify"),
    )
    endpoint_name = toml_data.endpoint_name()
    url = login.endpoint_uri(endpoint_name)
    return url


# issue https://github.com/open-telemetry/opentelemetry-python/issues/3836
# on start_as_current_span on async
@tracer.start_as_current_span(name="wxflows.ibm.watsonx.ai.chat")  # type: ignore
async def tools_call_chat_async(
    endpoint_url: str,
    endpoint_apikey: str,
    llm_vars: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    q = """query tool_trial($tools: [TC_ToolInput] 
  $tool_choice: InputToolChoice 
  $messages: InputMessages
  $temperature: Float
  $time_limit: Int
  $max_tokens: Int
  $model: String
) {
  chatContent(tools: $tools 
    tool_choice: $tool_choice 
    messages: $messages
    temperature: $temperature
    time_limit: $time_limit
    max_tokens: $max_tokens
    model: $model
  ) {
    finish_reason
    index
    message {
      content
      tool_calls {
        type
        id
        function {
          name
          arguments
        }
      }
    }
  }
}
"""

    headers = {"Authorization": f"apikey {endpoint_apikey}"} if endpoint_apikey else {}
    current_span = trace.get_current_span()
    current_span.set_attribute("watzen.service.name", "query.execute.llm")
    current_span.set_attribute("watzen.service.type", "llm")

    # smarter way?
    if not llm_vars:
        raise RuntimeError("bad request, no llm_vars")

    flows_wx = otel_basics()

    if "max_tokens" in llm_vars:
        current_span.set_attribute("gen_ai.request.max_tokens", llm_vars["max_tokens"])
    if "time_limit" in llm_vars:
        current_span.set_attribute("gen_ai.request.time_limit", llm_vars["time_limit"])
    if "temperature" in llm_vars:
        current_span.set_attribute("gen_ai.request.temperature", llm_vars["temperature"])
    if "model" in llm_vars:
        current_span.set_attribute("gen_ai.request.model", llm_vars["model"])
    # top_p and other?
    start_time = time.time()

    # messages guard
    if (
        os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT")
        and os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") != "false"
    ):
        current_span.add_event(json.dumps(llm_vars["messages"]), attributes=flows_wx)
        current_span.add_event(q, attributes={**flows_wx, "wxflows.sdk.graphql.query": "yes"})
        current_span.add_event(
            json.dumps(llm_vars),
            attributes={**flows_wx, "wxflows.sdk.graphql.variables": "yes"},
        )
    async with httpx.AsyncClient(timeout=60) as client:
        # only works if `--trace` is set (else running with apikey not adminkey)
        headers["stepzen-debug-level"] = "1"
        response = await client.post(
            endpoint_url, json={"query": q, "variables": llm_vars}, headers=headers
        )
        response.raise_for_status()
        result = response.json()

        if "errors" in result:
            raise RuntimeError(f'Error encountered: {result["errors"]}')
        if "extensions" in result:
            logger.debug(f'DEBUG TRACE: {json.dumps(result["extensions"])}')
            del result["extensions"]
        # in _chat not chatContent but we want to emit something, so use -1 for now.
        flows_wx["gen_ai.usage.output_tokens"] = -1
        flows_wx["gen_ai.usage.input_tokens"] = -1
        # similar here, but bad idea to emit a wrong value here.
        # flows_wx["gen_ai.response.model"] = ...

        return_messages = result.get("data", {}).get("chatContent")
        for rmessage in return_messages:
            finish_reason = rmessage["finish_reason"]
            flows_wx["gen_ai.response.finish_reasons"] = finish_reason

            if rmessage["message"].get("tool_calls"):
                if rmessage["message"]["tool_calls"][0].get("id"):
                    flows_wx["gen_ai.response.id"] = rmessage["message"]["tool_calls"][0].get("id")

            # should check if CONTENT and mask/reduce as needed, but need to walk through this in detail.
            if (
                os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT")
                and os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") != "false"
            ):
                if finish_reason == "tool_calls":
                    current_span.add_event(json.dumps([rmessage]), attributes=flows_wx)
                else:
                    current_span.add_event(
                        json.dumps(rmessage.get("message")), attributes=flows_wx
                    )
            current_span.set_attributes(flows_wx)
            emulate_call("chat", False, start_time, time.time())
        return result


""" Tool typename for GraphQL """
TC_GRAPHQL = "TC_GraphQL"


@tracer.start_as_current_span(name="wxflows.tools_call")  # type: ignore
async def tools_call_async(
    name: str,
    tool_typename: str,
    arguments: str,
    dataid: Optional[bool],
    call_id: str,
    endpoint_url: str = "",
    endpoint_apikey: str = "",
    lenient_variables: bool = False,
) -> Dict[str, Any]:
    q = """query function($name: String!, $arguments: JSON) {
  tc_function(name: $name, values: $arguments) {
    data
    errors {
      message
      path
    }
  }
}
"""
    args = json.loads(arguments)
    if tool_typename == TC_GRAPHQL:
        # graphql known to have query and variables
        q = args["query"]
        data = {"query": q}
        if "variables" in args:
            if isinstance(args["variables"], str):
                # it should never be a string, but in case it is, we
                # will try to fix it up for now.
                emsg = {
                    "error": [
                        {"message": "invalid variables.  Should be a JSON object, not a string."}
                    ]
                }
                # certain models do the wrong thing, but we shouldn't indulge them?
                # disable the reloading feature except if "lenient-variables"
                if not lenient_variables:
                    return emsg
                # There's a chance we'll need this code for certain models, so for now, leave it
                # but we'll eventually want a feature flag or some such to enable
                try:
                    # see if it is loadable
                    v = json.loads(args["variables"])
                    data["variables"] = v
                except Exception:
                    return emsg
            else:
                data["variables"] = args["variables"]
        # this is not currently defined... small risk in including it.
        if "operationName" in args:
            data["operationName"] = args["operationName"]
        logger.debug(f"function call: graphql: {json.dumps(data)}")
    else:
        variables = {"name": name, "arguments": args}
        data = {"query": q, "variables": variables}
        logger.debug(f"function call: tc_function: {data}")
    headers = {"Authorization": f"apikey {endpoint_apikey}"} if endpoint_apikey else {}
    headers["stepzen-debug-level"] = "1"

    start_time = time.time()

    current_span = trace.get_current_span()

    flows_wx = otel_basics()
    current_span.set_attributes(flows_wx)
    current_span.set_attribute("watzen.service.name", "query.execute.tool")
    current_span.set_attribute("watzen.tool.name", name)
    current_span.set_attribute("watzen.endpoint_url", endpoint_url)

    if (
        os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT")
        and os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") != "false"
    ):

        current_span.add_event(q, attributes={"wxflows.sdk.graphql.query": "yes"})
        if data.get("variables"):
            current_span.add_event(
                json.dumps(data.get("variables")),
                attributes={"wxflows.sdk.graphql.variables": "yes"},
            )

    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(endpoint_url, json=data, headers=headers)
        response.raise_for_status()
        data = response.json()
        # this should be under a flag
        data_id = ""
        data_id_vars = {}
        if dataid:
            data_id = str(uuid.uuid4())
            data_id_vars = {"dataid": data_id}
            data["dataid"] = data_id
            current_span.set_attribute("data_id", data["dataid"])
            console.print(f'Adding dataid {data["dataid"]}')

        if (
            os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT")
            and os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") != "false"
        ):
            current_span.add_event(
                json.dumps({"role": "tool", "content": data, "id": call_id}),
                attributes={"wxflows.tool.url": endpoint_url, **data_id_vars},
            )
        # should also dump some of the return data attributes?
        emulate_call(name, False, start_time, time.time())

        return data


@tracer.start_as_current_span(name="tools_list")  # type: ignore
async def get_tools(
    cli: CLIData,
    url: str,
) -> Dict[str, Any]:
    current_span = trace.get_current_span()
    current_span.set_attribute("watzen.service.name", "query.list.tools")
    current_span.set_attribute("watzen.endpoint_url", url)

    tool_data = await tools_info_async(
        url,
        cli.apikey,
    )
    if tool_data.get("errors"):
        raise CLIError(f'Error getting tools: {tool_data.get("errors")}')

    # add tools list response
    if (
        os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT")
        and os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") != "false"
    ):
        current_span.add_event(json.dumps(tool_data), attributes={"wxflows.tools.url": url})
    # should also dump some of the return data attributes?   maybe names of tools
    return tool_data


def cmd_sdk_tools_list(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    output: str = "",
    as_json: bool = False,
):
    logger.debug("tools list")

    url = get_endpoint_url(cli, toml_data)
    tools_data = asyncio.run(get_tools(cli, url))
    tools = tools_data.get("data", {}).get("tc_tools", [])
    if output:
        with open(output, "w") as f:
            f.write(json.dumps(tools))
    if as_json:
        rich.print(JSON(json.dumps(tools)))
        return

    if not tools:
        rich.print("[yellow]No tools[/yellow]")

    for tool in tools:
        tree = Tree(
            "tool",
            guide_style="bold bright_blue",
        )
        tool_def = tool[tool["type"]]
        tree.add(f'[blue]name:[/blue] {tool_def["name"]}')
        tree.add(f'[blue]description:[/blue] {tool_def["description"]}')
        parameters = tool_def["parameters"]

        #  as a table to highlight it.
        ntable = Table(show_header=True, header_style="bold magenta")
        ntable.add_column("name")
        ntable.add_column("description")
        ntable.add_column("type")

        for property_name in parameters["properties"]:
            property = parameters["properties"][property_name]
            property_type = property["type"]
            property_description = property["description"]
            ntable.add_row(property_name, property_description, property_type)
            limit = 20 * 1024
            if property_name == "query" and len(property_description) > limit:
                ntable.add_row(
                    "query",
                    f"[yellow][i]warning: this query description is very long ({len(property_description)}) and "
                    "likely includes unneeded fields or too many fields for the tool to perform well.  "
                    'Use the "fields" regular express in the tools definition to restrict[/i][/yellow]',
                    "note",
                )

        tree.add("parameters").add(ntable)
        rich.print(tree)


WXFLOWS_PROMPT_ENV = "WXFLOWS_TOOLS_TEST_SYSTEM_PROMPT"


""" 

To enable Opentelemetry:
hatch run extras:opentelemetry-bootstrap [-a]?
hatch run extras:pip install "opentelemetry-distro[otlp]"
# start a collector such as Graphana or Jaeger
hatch run extras:opentelemetry-instrument \
    --traces_exporter console,otlp \
    --metrics_exporter console \
    --service_name mine  \
    --exporter_otlp_endpoint "http://localhost:4317" python -m zenai_sdk.cli \
   tools try    --model meta-llama/llama-3-1-70b-instruct  "...." --output output.json

"""


@tracer.start_as_current_span(name="tools_try")  # type: ignore
def cmd_sdk_tools_trial(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    user_messages: List[str],
    model_id: str = "meta-llama/llama-3-3-70b-instruct",
    system_prompt: str = "",
    temperature: Optional[float] = 1.0,
    time_limit: Optional[int] = 3000,
    max_tokens: Optional[int] = 1000,
    details: int = 0,
    input_tools: Optional[str] = "",
    input_prompt: Optional[str] = "",
    dump_json: Optional[bool] = False,
    output_json: Optional[str] = "",
    tool_choice: Optional[str] = "",
    execute: int = 0,
    dataid: Optional[bool] = False,
    stepzen_debug: Optional[bool] = False,
    chat_history_file: Optional[str] = "",
):

    loop = asyncio.get_event_loop()
    prompts = None

    if chat_history_file:
        print("loading... {chat_history_file}")
        with open(chat_history_file, "r") as f:
            prompts = json.load(f)
    try:
        for message in user_messages:
            my_task = asyncio.ensure_future(
                cmd_sdk_tools_trial_inner(
                    cli,
                    toml_data,
                    message,
                    model_id,
                    system_prompt,
                    temperature,
                    time_limit,
                    max_tokens,
                    details,
                    input_tools,
                    input_prompt,
                    dump_json,
                    output_json,
                    tool_choice,
                    execute,
                    dataid,
                    stepzen_debug,
                    prompts,
                )
            )
            prompts = loop.run_until_complete(my_task)
    except KeyboardInterrupt:
        pass
    finally:
        loop.close()


def get_template(model_id: str, dataid: Optional[bool]) -> str:
    """model_id in case we need to specialize"""

    if dataid:
        return """You are a helpful assistant for ACME corporation that is going to assist business users with their questions.
- The output that you generate will be post processed using the Handlebars framework before being sent to the user.
- You will use a series of tools to achieve your goals. These tools output data and include a 'dataid' that should be used to reference this data for subsequent transformation, join or display.
- It is very important that you DO NOT include in your responses data that was the result of a tool call or data that the user has uploaded.  Instead ALWAYS use the 'renderData' helper to display the information.
- DO NOT provide any additional commentary, summary or insights into the data, i.e. do not repeat the information that will be rendered by the helper function.  You can assume that all the data is placed an appropriate format by the handlebars helper, as such leave all the display of data to the renderData helper function.
- It is important to see if you can use a tools output from the chat history before running again.
- It is also important to view a single user ask as a series of simpler transformations.
- Some tool responses, including the GraphQL tools, will be JSON data. Use the JSON to generate your plain text responses

These are the tools you have at your disposal:
{{ TOOLS_LIST }}
renderData

DO NOT USE A SUBSELECTION WHEN THE RETURN TYPE OF A TOOL IS JSON.

Many tools take jsonata as input.  A few tips and tricks to remember when using jsonata.

## Formatting

Make sure the JSON encoding is correctly when using the tools, don't use too many backslashes.

## jsonata tips

- KEEP THE JSONATA AS SIMPLE AS POSSIBLE AND ONLY USE FUNCTIONS IF YOU ABSOLUTELY HAVE TO
- Do not start your jsonata with '[].' as the subsequent operation is operating over an empty set. '$[].' may often be a better choice.
- When projecting data from deeper in the json to a higher level this is done using the $.{} operation.  An example
    $.{
      "Name": Name,
      "Description": Description,
      "SKU": SKU,
      "Price": __data__.data.price
      "Child SKU Count": $count(__data__.data.childskus)
    }
- Make use of the '%.' parent operator which can reference values of parent structures
  e.g. '%.orderName' can refer to the orderName of the order that an order line item is a part of
- If you are asked to calculate something, do not put the unit in the value, instead put the unit in the column title, i.e. if you are calculating a number then the result should be a number in the json and NOT a string.  This is due to it potentially being used for further calculations.
- If you do need a function remember that a functions body is made up of one or more expressions
- When an items field name has special characters in it then surround it with double quotes
    for example if a field name is "Price ($s)" then the field can be referenced as '$."Price ($s)"' (don't forget the appropriate prefix based on context e.g. '$.', '$item.', without this the value will just be the field name)
- If you need multiple expressions (in a function) they must be grouped in parentheis ()
    an example function defintion is below
      $exampleFunction := function($x, $y) {
        (
            $sum := $x + $y;
            $product := $x * $y;
            $sum + $product
        )
      };
- When using the $sort function remember that it's signature is $sort(array, function)
    simple example - $sort($, "displayName")
    more complicated example - $sort($, function($a, $b) { $a.displayName > $b.displayName })
- The $millis() function returns the number of milliseconds since the Unix Epoch (1 January, 1970 UTC) as a number
    Example
    $millis() => 1502700297574
- When using the $map() function remember that it's signature is $map(array, function)
    Examples
      $map([1..5], $string) => ["1", "2", "3", "4", "5"]

      $map(Email.address, function($v, $i, $a) {
        'Item ' & ($i+1) & ' of ' & $count($a) & ': ' & $v
      })

## Handlebars Helper: renderData

Description: renderData is a custom Handlebars helper that generates a nicely formatted view of the data that was retrieved by the tool or uploaded by the user.

Usage:

	•	Helper Name: renderData
	•	Parameters: Takes a single parameter, dataid, which corresponds to the dataid identifying the data that the helper should render
	•	Return Value: Returns a nicely formatted output for the user.

Example Usage:

I have looked up the information and it is available below

{{=<% %>=}}
{{renderData 67853}}
<%={{ }}=%>

"""

    return """You are a helpful assistant that is going to assist business users with their questions.
- The output that you generate will be post processed using the Handlebars framework before being sent to the user.
- You will use a series of tools to achieve your goals.
- The tools are using GraphQL. When creating a GraphQL operation always use double quotes for input parameters
- Some tool responses, including the GraphQL tools, will be JSON data. Use the JSON to generate your plain text responses
- You can respond using markdown syntax, but only do so when appropriate.

These are the tools you have at your disposal:
{{ TOOLS_LIST }}

DO NOT USE A SUBSELECTION WHEN THE RETURN TYPE OF A TOOL IS JSON.

Many tools take jsonata as input.  A few tips and tricks to remember when using jsonata.

## Formatting

Make sure the JSON encoding is correctly when using the tools, don't use too many backslashes.

## jsonata tips

- KEEP THE JSONATA AS SIMPLE AS POSSIBLE AND ONLY USE FUNCTIONS IF YOU ABSOLUTELY HAVE TO
- Do not start your jsonata with '[].' as the subsequent operation is operating over an empty set. '$[].' may often be a better choice.
- When projecting data from deeper in the json to a higher level this is done using the $.{} operation.  An example
    $.{
      "Name": Name,
      "Description": Description,
      "SKU": SKU,
      "Price": __data__.data.price
      "Child SKU Count": $count(__data__.data.childskus)
    }
- Make use of the '%.' parent operator which can reference values of parent structures
  e.g. '%.orderName' can refer to the orderName of the order that an order line item is a part of
- If you are asked to calculate something, do not put the unit in the value, instead put the unit in the column title, i.e. if you are calculating a number then the result should be a number in the json and NOT a string.  This is due to it potentially being used for further calculations.
- If you do need a function remember that a functions body is made up of one or more expressions
- When an items field name has special characters in it then surround it with double quotes
    for example if a field name is "Price ($s)" then the field can be referenced as '$."Price ($s)"' (don't forget the appropriate prefix based on context e.g. '$.', '$item.', without this the value will just be the field name)
- If you need multiple expressions (in a function) they must be grouped in parentheis ()
    an example function defintion is below
      $exampleFunction := function($x, $y) {
        (
            $sum := $x + $y;
            $product := $x * $y;
            $sum + $product
        )
      };
- When using the $sort function remember that it's signature is $sort(array, function)
    simple example - $sort($, "displayName")
    more complicated example - $sort($, function($a, $b) { $a.displayName > $b.displayName })
- The $millis() function returns the number of milliseconds since the Unix Epoch (1 January, 1970 UTC) as a number
    Example
    $millis() => 1502700297574
- When using the $map() function remember that it's signature is $map(array, function)
    Examples
      $map([1..5], $string) => ["1", "2", "3", "4", "5"]

      $map(Email.address, function($v, $i, $a) {
        'Item ' & ($i+1) & ' of ' & $count($a) & ': ' & $v
      })
"""


def render_prompt_with_tools(
    prompt_template: str, tools_names: List[str], myvars: Dict[str, Any] = {}
) -> str:
    tools_list = "\n".join(tools_names)
    tools_line = ", ".join(tools_names)
    return chevron.render(
        prompt_template,
        {
            **myvars,
            "TOOLS_NAMES": tools_names,
            "TOOLS": tools_line,
            "TOOLS_LIST": tools_list,
            "TODAY": f"{datetime.date.today()}",
            "NOW": f"{datetime.datetime.now()}",
        },
    )


async def cmd_sdk_tools_trial_inner(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    message: str,
    model_id: str,
    system_prompt_template: str,
    temperature: Optional[float],
    time_limit: Optional[int],
    max_tokens: Optional[int],
    details: int,
    input_tools: Optional[str],
    input_prompt: Optional[str],
    dump_json: Optional[bool],
    output_json: Optional[str],
    tool_choice: Optional[str],
    execute: int,
    dataid: Optional[bool],
    stepzen_debug: Optional[bool],
    prompt_messages: Optional[List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:

    # thoughts:
    # issues w/rt passing through arguments? esp. messages
    # force specific tool call
    # embedding

    logger.debug("tools trial")
    apikey = cli.adminkey if stepzen_debug else cli.apikey
    url = get_endpoint_url(cli, toml_data)
    if dump_json:
        details = 0
    if output_json:
        # for now, do both
        with open(output_json, "w") as f:
            pass

    # junk stuff
    if any([t.startswith("trace") for t in os.environ.get("DEMO", "").split(",")]):
        with open("charlie.sh", "w") as f:
            f.write("#!/bin/bash\n")

    # doctor up the trial command to inject the OpenTelemetry trace
    # that uses https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-events/
    # as its model for the genai calls.
    # Purpose is to prototype what is needful for the SDKs to trace genai events.
    # Note: we can also have a model where the server returns/posts OTel data
    # that is more detailed (flows, debug, etc.) later.
    flows_wx = otel_basics()
    current_span = trace.get_current_span()
    # add tools list response
    current_span.add_event(
        f"wxflows opentelemetry data is included as an experiment and should not be used for production as of {__version__}.",
        attributes=flows_wx,
    )

    aiengine = toml_data.deployment_ai_engine()
    if aiengine != "WATSONX":
        if aiengine == "OPENAI":
            flows_wx["gen_ai.system"] = "openai"
        else:
            flows_wx["gen_ai.system"] = "_OTHER"

    # eventually add top_p to cmd line?ignore for now.
    llm_vars = {
        **({"temperature": temperature} if temperature is not None else {}),
        **({"time_limit": time_limit} if time_limit is not None else {}),
        **({"max_tokens": max_tokens} if max_tokens is not None else {}),
        "model": model_id,
    }

    fn = input_tools or os.environ.get("WXFLOWS_TOOLS_DATA")
    if fn:
        # a little hackto allow us to play with tools data
        if not dump_json:
            console.print(f"[dim]Overriding tool defintions from {fn}[/dim]")
        with open(fn, "r") as f:
            if fn.endswith(".json"):
                tools = json.loads(f.read())
            else:
                tools = yaml.safe_load(f.read())
        logger.debug(f"tools: try: load tools from {fn}")
    else:
        tools_data = await get_tools(cli, url)
        tools = tools_data.get("data", {}).get("tc_tools", [])
        logger.debug(f"tools: try: load tools from {url} {json.dumps(tools)}")

    # have tools
    tools_names: List[str] = [tool.get("function", {}).get("name") for tool in tools]
    tools_name_to_type: Dict[str, str] = {
        tool.get("function", {}).get("name"): tool["__typename"] for tool in tools
    }
    logger.debug(f"tool types: {tools_name_to_type}")

    # aicore won't accept __typename, minimize so it works.
    aicore_tools = [{k: v for k, v in tool.items() if k in ["type", "function"]} for tool in tools]

    tools_data = {}
    if tools:
        tools_data["tools"] = aicore_tools
    if tool_choice:
        tools_data["tool_choice"] = {
            "type": "function",
            "function": {
                "name": tool_choice,
            },
        }

    # establish prompt now.
    # system_prompt overriden by file.
    if input_prompt:
        # should make inputs exclusive
        if system_prompt_template:
            if not dump_json:
                console.print(f"[dim]Overriding --system-prompt from {input_prompt}[/dim]")
        else:
            if not dump_json:
                console.print(f"[dim]System prompt template from {input_prompt}[/dim]")
        with open(input_prompt, "r") as f:
            system_prompt_template = f.read()
        logger.debug(f"System prompt template read from {input_prompt}: {system_prompt_template}")
    if not system_prompt_template:
        if os.environ.get(WXFLOWS_PROMPT_ENV):
            system_prompt_template = os.environ[WXFLOWS_PROMPT_ENV]
            logger.debug(
                f"System prompt template read from {WXFLOWS_PROMPT_ENV}: {system_prompt_template}"
            )
        else:
            system_prompt_template = get_template(model_id, dataid)
            logger.debug("System prompt read from internal template: prompt.tmpl")

    logger.debug(
        f"system prompt generation: {tools_names} template len {len(system_prompt_template)} '{system_prompt_template[0:min(len(system_prompt_template),100)]}'..."
    )
    system_prompt = render_prompt_with_tools(system_prompt_template, tools_names)

    # get this from a template as well?
    if prompt_messages:
        messages = prompt_messages
    else:
        messages = [
            {"role": "system", "content": system_prompt},
        ]
    messages.append({"role": "user", "content": message})

    def details_table(llm_vars):
        ntable = Table()  # show_header=True, header_style="bold blue")
        ntable.add_column("Chat LLM Parameter Name", width=15)
        ntable.add_column("Value")
        view_llm_vars = {**llm_vars, **tools_data}
        for name in view_llm_vars:
            if isinstance(view_llm_vars[name], str):
                ntable.add_row(name, f"{view_llm_vars[name]}")
            elif isinstance(view_llm_vars[name], int) or isinstance(view_llm_vars[name], float):
                ntable.add_row(name, f"{view_llm_vars[name]}")
            else:
                if name == "tools" or name == "tool_choice":
                    # limit details to keep display tight
                    if details > 1:
                        ntable.add_row(name, yaml.safe_dump(view_llm_vars[name]))
                    else:
                        reduced = ""
                        if name == "tools":
                            reduced = ",".join(tools_names)
                        elif name == "tool_choice":
                            reduced = tool_choice if tool_choice else "tool_choice is empty"
                        ntable.add_row(name, f"[dim]{reduced}[/dim] ")
                elif name == "messages":

                    def myreduce(m):
                        """reduce content to 100 characters or elide"""
                        if details > 1:
                            return m
                        if "content" not in m or not m["content"]:
                            return m
                        mm = copy.copy(m)
                        mm["content"] = (
                            "[dim]" + m["content"][0 : min(len(m["content"]), 100)] + "[/dim]..."
                        )
                        return mm

                    rmsg = [myreduce(message) for message in messages]
                    ntable.add_row(name, yaml.safe_dump(rmsg))
                else:
                    ntable.add_row(name, yaml.safe_dump(llm_vars[name]))
        return ntable

    @tracer.start_as_current_span(name="tools_try.chat")  # type: ignore
    async def do_chat(i, messages):
        # only if set
        # my_flows_wx["gen_ai.request.max_tokens"]  = 200
        # my_flows_wx["gen_ai.request.top_p"] = 	1.0

        messages = copy.copy(messages)
        llm_vars["messages"] = messages
        deets = ""
        if not dump_json:
            rich.print(Panel(deets, title=f"LLM call number {i+1}"))

        if details:
            deets = details_table(llm_vars)
            rich.print(deets)

        async def get_chat_result():
            # there are situations in which the tool call will repeat
            # allow things to stop by calling end without tools
            # this was a trick carlos used, but is likely model specific
            # langchain does not normally do this
            # it's quite possible that evaluation of the result needs
            # to happen and a decision on whether to use the tools is
            # needed.   For now, leave it so that by default,
            # we pass through the tools and let the LLM decide
            # but allow a flag to stop passing through tools
            # if the prior call was a tool.... Really smart way
            # would be to conditionalize on basis of what tool
            # was last used?
            my_llm_data = {**llm_vars, **tools_data}
            if os.environ.get("CONDITIONAL_TOOLS") and llm_vars["messages"][-1]["role"] == "tool":
                data = json.loads(llm_vars["messages"][-1]["content"])
                if not data.get("errors"):
                    rich.print("Drop tools for next LLM call")
                    # remove tools data
                    my_llm_data = llm_vars
            return await tools_call_chat_async(
                url,
                apikey,
                my_llm_data,
            )

        if dump_json:
            print(json.dumps(llm_vars))
        if output_json and False:  # disable for now
            # for now, do both
            with open(output_json, "a") as f:
                f.write(json.dumps(llm_vars))
                f.write("\n")

        logger.debug(f"tools: try: call LLM chat {json.dumps(llm_vars)}")
        start_time = time.time()
        if dump_json or not details:
            result = await get_chat_result()
        else:
            if messages[-1].get("role") == "user":
                note = f"Asking [yellow]{message}[/yellow]..."
            else:
                note = f"Asked [yellow]{message}[/yellow]... and now running try... {len(messages)} messages"
            with console.status(note):
                result = await get_chat_result()
        logger.debug(f"tools: try: call LLM chat result {result}")
        if details:
            thetime = round(time.time() - start_time, 1)
            if thetime:
                rich.print(f"After {thetime}s the LLM tells us:")

        if "errors" in result:
            if (
                result["errors"][0].get("message")
                == "ECMAScript issue: TypeError: Cannot read property '0' of undefined at transformREST (_local_:22:30(42))"
            ):
                raise CLIError("Timeout while executing request, please retry")
            raise CLIError(f'Error getting tools: {result.get("errors")}')
        return_messages = result.get("data", {}).get("chatContent")

        if dump_json:
            print(json.dumps(result))

        if output_json:
            # for now, do both
            with open(output_json, "a") as f:
                f.write(json.dumps(result))
                f.write("\n")

        ntable = Table(
            show_header=True,
            header_style="bold blue",
            padding=0,
            show_lines=True,
        )
        ntable.add_column("Chat LLM function calls", justify="center")
        ntable.add_column("Message", justify="center")
        ntable.add_column("Finish Reason", justify="center")
        if not return_messages:
            if not dump_json:
                console.print(
                    "Nothing returned.  Make sure your credentials allow for watsonx.ai access.  [yellow]STEPZEN_WATSONX_HOST=shared is not supported.[/yellow]"
                )
            return_messages = []

        for rmessage in return_messages:
            finish_reason = rmessage["finish_reason"]
            content = rmessage["message"].get("content", "")

            row_styles = ["cyan", ""]
            if execute:
                row_styles = ["cyan", "", ""]
            tcall_table = Table(
                show_header=False,
                show_edge=False,
                show_lines=True,
                header_style="bold blue",
                row_styles=row_styles,
            )
            assistant_message = {"role": "assistant", "content": content}
            if rmessage["message"].get("tool_calls"):
                assistant_message["tool_calls"] = rmessage["message"].get("tool_calls")
            messages.append(assistant_message)
            if rmessage["message"].get("tool_calls"):
                for tool_call in rmessage["message"]["tool_calls"]:
                    tool_call_id = tool_call["id"]
                    function_call = tool_call["function"]
                    if not function_call:
                        tcall_table.add_row(tool_call_id)
                    else:
                        tcall_table.add_row(
                            f'{function_call["name"]}',
                            function_call["arguments"],
                        )
                        tcall_table.add_row("id", tool_call_id)
                        if execute:
                            name = function_call["name"]
                            if dataid and name == "renderData":
                                console.print(
                                    "function renderData encountered, will skip execution"
                                )
                            else:
                                arguments = function_call["arguments"]
                                logger.debug(f"tools: try: execute tool {url} {name} {arguments}")
                                if name not in tools_name_to_type:
                                    raise CLIError("Tool call returned a bad tool {name}")
                                eresult = await tools_call_async(
                                    name,
                                    tools_name_to_type[name],
                                    arguments,
                                    dataid,
                                    tool_call_id,
                                    url,
                                    apikey,
                                    lenient_variables=cli.is_feature("lenient-variables"),
                                )
                                tcall_table.add_row("execution result", JSON(json.dumps(eresult)))
                                logger.debug(f"tools: try: execute tool {eresult}")
                                if dump_json:
                                    print(json.dumps(eresult))
                                if output_json:
                                    # for now, do both
                                    with open(output_json, "a") as f:
                                        f.write(json.dumps(eresult))
                                        f.write("\n")

                                messages.append(
                                    {
                                        "role": "tool",
                                        "tool_call_id": tool_call_id,
                                        "content": json.dumps(eresult),
                                    }
                                )
            if tcall_table.columns:
                ntable.add_row(
                    tcall_table,
                    f"[red]{content}[/red]",
                    finish_reason,
                )
            else:
                ntable.add_row(
                    "[red]None[/red]",
                    f"[red]{content}[/red]",
                    finish_reason,
                )
            if not dump_json:
                rich.print(ntable)
        return messages

    if not execute:
        execute = 0
    execute += 1

    def count_msgs(msgs):
        return len([m for m in msgs if m.get("role") not in ["assistant", "system"]])

    # truncate
    if output_json:
        with open(output_json, "w") as f:
            pass
    for i in range(execute):
        start_time = time.time()
        n = count_msgs(messages)
        messages = await do_chat(i, messages)
        with open(".chat_history.json", "w") as f:
            f.write(json.dumps(messages) + "\n")
        delta = time.time() - start_time
        logger.debug(f"LLM execution {i+1} took {delta}")
        if messages[-1].get("role") != "tool":
            console.print(
                f"Done: LLM called interpret the response to the user message.  Iteration {i}"
            )
            break
        else:
            # nothing changed...
            if n == count_msgs(messages):
                console.print(
                    f"Done: LLM to interpret the response to the user message. Iteration {i} "
                )
                break
    return messages
