class ForumSession:
    def __init__(self, panelists, community_members):
        self.panelists = panelists  # List of PanelistAgent
        self.community_members = community_members  # List of CommunityMemberAgent

    def run_round(self, question):
        responses = []
        for panelist in self.panelists:
            responses.append(panelist.respond(question))
        return responses