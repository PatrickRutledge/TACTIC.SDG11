class CommunityMemberAgent:
    def __init__(self, user_id, voice_id=None):
        self.user_id = user_id
        self.voice_id = voice_id

    def ask_question(self, question):
        # For simulation: returns the question as-is
        return question