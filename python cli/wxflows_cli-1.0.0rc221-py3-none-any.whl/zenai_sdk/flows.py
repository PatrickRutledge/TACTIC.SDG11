# Copyright IBM Corp. 2023, 2025
import argparse
import asyncio
import gzip
import json
import logging
import os
from hashlib import sha256
from typing import Any, Dict, List, Mapping, Optional

import httpx
from dotenv import load_dotenv
from gql import gql
from importlib_resources import files
from wxflows_client import rag

from .stepzen_services import (
    Deployment,
    DeploymentResult,
    EndpointSchema,
    IntrospectionMessage,
    SchemaFileData,
    StepzenConfig,
)
from .stepzen_services import StepzenLogin as StepzenCredentials

logger = logging.getLogger("wxflows")


"""This portion of flows represents our inner model.

Names likely to change:
- pattern
- CatalogData
- schema?


CatalogData - provides the underlying pattern data including the
"schema" and "configuration" that is provided by a "pattern".

FlowFoundation - has the steps on which a Flow will be based.
- internally, we provide several ways to extend an Foundation
  beyond its pattern but we should careful examine how we want
  those elements exposed.

FlowsPublisher - uses a FlowFoundation as the base to publish flows.

"""


class UserEndpoint:
    """
    user endpoint and associated APIKey
    """

    def __init__(self, endpoint_name: str, apikey: str):
        self.endpoint_name = endpoint_name
        self.apikey = apikey


class Flow:
    """
    allows a developer to invoke a flow
    """

    def __init__(
        self, endpoint_url: str, apikey: str, flow_name: Optional[str], debug: bool = False
    ):
        """
        execute will execute a flow named by flow_name located at endpoint_url using the apikey `apikey`

        Parameters
        ----------
        endpoint_url: str
           url to use for the flow
        apikey: str
           apikey for the flow
        flow_name: str | None
           name of the flow to invoke by default
        """
        self.endpoint_url = endpoint_url
        self.apikey = apikey
        self.flow_name = flow_name
        self.headers = {"Authorization": f"apikey {self.apikey}"} if self.apikey else {}
        if debug:
            self.headers["Stepzen-debug-level"] = "1"
        pass

    async def execute(
        self, input: str, flow_name: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        execute will execute a flow named by flow_name located at endpoint_url using the apikey `apikey`

        Parameters
        ----------
        input: str
           input or question to submit to the flow
        flow_name: str | None
           name of the flow to invoke by default

        Returns
        -------
        any
          response from the flow rendered from JSON

        Raises
        ------
        RuntimeError
          execution exceptions

        """
        if not flow_name:
            flow_name = self.flow_name
        qstr = f"query {flow_name}($input: String!) {{{flow_name}(input: $input)}}"

        # make sure it compiles?
        _ = gql(qstr)

        data = {
            "query": qstr,
            "variables": {"input": input},
        }

        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(self.endpoint_url, json=data, headers=self.headers)
            response.raise_for_status()
            return response.json()

        return None


class FlowEndpoint(Flow):
    """
    FlowEndpoint is returned by the FlowPublisher and can be used to retrieve Flow objects
    that can invoke flows.  It is itself a Flow and can directly be used to invoke flows
    but the Flow object will default to a specific flow
    """

    def __init__(
        self,
        uri: str,
        credentials_data: StepzenCredentials,
        deploy_result: DeploymentResult,
    ):
        self.credentials_data = credentials_data
        self.uri = uri
        self.deploy_result = deploy_result

        super(FlowEndpoint, self).__init__(self.uri, self.credentials_data.admin_key, None)
        pass

    def messages(self) -> List[IntrospectionMessage]:
        if self.deploy_result is None or self.deploy_result.introspection_flows is None:
            return []
        return self.deploy_result.introspection_flows.messages

    def flows_count(self) -> int:
        """
        will return the number of flows that were deployed into this endpoint
        will only be valid if the endpoint was just deployed
        Returns
        -------
        int
           number of flows that were deployed
        """
        if self.deploy_result:
            return self.deploy_result.flows_count()
        return 0

    def flows_names(self) -> List[str]:
        """
        will return the names of flows that were deployed into this endpoint
        will only be valid if the endpoint was just deployed
        Returns
        -------
        List[str]
            List of names
        """

        if self.deploy_result:
            return self.deploy_result.flows_names()
        return []

    def flow(self, flow_name: str) -> Flow:
        """
        flow will return a Flow that will execute the named flow.

        Parameters
        ----------
        flow_name: str
           name of the flow to invoke by default

        Returns
        -------
        Flow
          an object that can execute a flow

        Raises
        ------
        RuntimeError
          execution exceptions

        """
        return Flow(self.uri, self.credentials_data.admin_key, flow_name)


async def catalog_data_from_url(url: str) -> Dict[str, Any]:
    try:
        # probably slightly better ways to do this.
        async with httpx.AsyncClient(timeout=33) as client:
            r = await client.get(url, follow_redirects=True)
            data = json.loads(gzip.decompress(r.content))
            if not isinstance(data, dict):
                raise RuntimeError(f"Retrieving core from {url}: invalid core")
            return data
    except httpx.ConnectError as e:
        raise RuntimeError(f"Retrieving core from {url}: Could not connect: {e}")
    except Exception as e:
        raise RuntimeError(f"Retrieving core from {url}: {e}")


class CatalogData:
    """internal class to manage the pattern catalog
    currently we read from an internal call but plan to make an API call.

    data has the format:
    pattern:
      name: NAME
      schemaFiles: in SchemaFiles format [see zenctl2 ]
      configuration: in Configuration format [ see zenctl2 ]
    and is kept as a object as reconstituted from JSON.

    should be expanded to include items like/including:
    - list of patterns
    - list of exported steps in the underlying pattern
      - this includes any exported flows
    - graph of steps
    - step's category (conceptual like search, etc.)
    - tags and associated steps

    """

    def __init__(self):
        self.data: Dict[str, Any] = {}
        pass

    @classmethod
    async def create(
        cls,
        catalog_data: Optional[str] = "",
        url: Optional[str] = "",
    ):
        """
        create is a coroutine to create a CatalogData.  Use as
        CatalogData.create() instead of CatalogData()

        catalog_data can be used to override the reading of the internal bundle
        (for testing purposes)

        url will override the default url/bundle

        """

        self = cls()
        if not catalog_data:
            if url:
                data = await catalog_data_from_url(url)
            else:
                loc = files("zenai_sdk").joinpath("bundles", "catalog.json.gz")
                # later make fully async even though we may call this via API later
                # but only if we plan to have a copy of the data builtin
                with gzip.open(str(loc), "r") as f:
                    data = json.load(f)
                    # save it? (is less than a ms typical on ssd, so ignore for now)
        else:
            # this is a file that the user specified.  mostly for testing.
            data = json.loads(catalog_data)
        self.data = data
        return self

    def get_pattern(
        self, pattern: str, emptyPattern: Optional[bool] = False
    ) -> Optional[Dict[str, Any]]:
        if pattern == "null" or pattern == "empty" or emptyPattern:  # used to override the catalog
            # empty one
            return {
                "name": "aicore",  # lie
                "schemaFiles": {
                    "files": [
                        {
                            "name": "index.graphql",
                            # for the case when null is used as the pattern.
                            "content": "schema { query: Query mutation: Mutation subscription: Subscription}\n",
                        }
                    ],
                    "entryPoint": "index.graphql",
                },
                "configuration": {"configurationset": []},
            }
        return self.data.get(pattern)

    def get_pattern_configuration(self, pattern: str) -> Optional[StepzenConfig]:
        pat_data = self.get_pattern(pattern)
        if not pat_data:
            return None
        configuration_data = pat_data.get("configuration")
        if not configuration_data:
            return None
        sc = StepzenConfig(configuration_data, {})  # FIX
        return sc


class FlowFoundation:
    """
    contains flow foundation which can be used to feed a flow.


    add_configuration - *EXPERIMENTAL* allows a single configuration to be added.
    edit - *EXPERIMENTAL*
      - extensions - add new "schema" files.
      - configuration - replace configuration

    """

    def __init__(self, _catalog_data: Optional[Dict[str, Any]] = None):
        # core data
        self.configuration_data: Optional[StepzenConfig] = StepzenConfig({})
        self.endpoint_schema: Optional[EndpointSchema] = None

        # copy of the low level data
        self.pattern_data: Dict[str, Any] = {}  # catalog data for the pattern
        self.catalog_data: CatalogData = CatalogData()
        self.schema_files = None
        pass

    @classmethod
    async def create(
        cls,
        pattern: str,
        credentials: StepzenCredentials,
        env: Optional[Mapping[str, Optional[str]]] = None,
        _catalog_data: Optional[str] = None,
        # use the pattern file, default is true
        use_pattern: bool = True,
    ):
        """
        create is a coroutine to create a FlowFoundation.  Use as
        FlowFoundation.create() instead of FlowFoundation()

        used to create a FlowFoundation that contains the underlying
        elements required for building flows.

        Parameters
        ----------
        pattern: str
           pattern or kind underlying the flows
           - aicore

        """
        self = cls()
        self.catalog_data = await CatalogData.create(catalog_data=_catalog_data)

        # extract pattern catalog data
        pattern_data = self.catalog_data.get_pattern(pattern, emptyPattern=not use_pattern)
        if not pattern_data:
            raise RuntimeError(f"Unknown pattern {pattern}")
        self.pattern_data = pattern_data

        # extract schema files
        self.schema_files = self.pattern_data.get("schemaFiles")  # SchemaFiles
        if not self.schema_files or not self.schema_files.get("files"):
            raise RuntimeError(f"Internal error: No schema data for {pattern}")

        # convert to an StepZen Endpoint Schema
        # note we ignore the entryPoint
        self.endpoint_schema = EndpointSchema(
            [
                SchemaFileData(schemaFile.get("name", ""), schemaFile.get("content", ""))
                for schemaFile in self.schema_files.get("files", {})
            ]
        )

        # extract configuration data *template*
        # deferred using StepzenConfig since we'd have to get env here
        # but that might be okay.
        configuration_data = self.pattern_data.get("configuration", {})
        if env is None:
            env = {}

        sc = StepzenConfig(configuration_data, env)
        self.configuration_data = sc
        return self

    def add_configuration(self, name: str, configuration: Dict[str, str], report_new: bool = True):
        """
        add_configuration provides a named configuration.  The configuration consists
        of a series of key, value pairs.   If the configuration already exists,
        then it will be merged with this configuration.  Any existing keys may
        be overwritten.

        Parameters
        ----------
        name:
          name of the configuration
        configuration: Dict[str,str]
          key value pairs, key cannot be name
        """
        if not self.configuration_data:
            self.configuration_data = StepzenConfig({}, {})
            # if not self.configuration_data
        self.configuration_data.add(name, configuration, report_new)

    def add_endpoint_attributes(self, config_yaml: Optional[Dict[str, Any]]):
        if not config_yaml:
            return
        for kname in config_yaml:
            if kname == "configurationset":
                continue
            if not self.configuration_data:
                self.configuration_data = StepzenConfig({}, {})
            logger.debug(f"config.yaml contains {kname} - replacing configuration for {kname}")
            self.configuration_data.set_value(kname, config_yaml[kname])

    @staticmethod
    def merge(
        extensions1: Optional[List[SchemaFileData]],
        extensions2: Optional[List[SchemaFileData]],
        report_new: bool = True,
    ) -> Optional[List[SchemaFileData]]:
        # overwrite extensions1
        # does not merge the root file as that would require
        # parsing the schema sdl directive to do properly
        # plan to use for --package-bundle internal development
        if not extensions1:
            return extensions2
        if not extensions2:
            return extensions1
        mapping = {item.name: idx for idx, item in enumerate(extensions1)}

        unchanged = 0
        original_total = len(extensions1)
        new_total = len(extensions2)
        added = 0
        changed = 0
        for idx, ext in enumerate(extensions2):
            new_digest = sha256(ext.content.encode("utf-8")).hexdigest()
            if mapping.get(ext.name) is not None:
                old_idx = mapping.get(ext.name)
                if old_idx is None:  # skip, should never happen though
                    continue
                old = extensions1[old_idx]
                old_digest = sha256(old.content.encode("utf-8")).hexdigest()
                if old_digest != new_digest:
                    logger.debug(
                        f"overriding {ext.name} {len(ext.content)} {new_digest} (old {len(old.content)} {old_digest})"
                    )
                    changed += 1
                else:
                    unchanged += 1
                old.content = ext.content  # override
            else:
                if report_new:
                    logger.debug(f"Adding {ext.name} - not in underlying schema ")
                added += 1
                extensions1.append(ext)

        logger.debug(
            f"started with {original_total} files and merged {new_total} files yielding  {len(extensions1)}"
        )
        logger.debug(f"- {added} entries added")
        logger.debug(f"- {unchanged} entries whose contents were not changed")
        logger.debug(f"- {changed} entries whose contents were  changed")

        return extensions1

    def edit_add_overlay(
        self,
        extensions: Optional[List[SchemaFileData]],
        index: Optional[str],
        config: Optional[Dict[str, Any]],
        report_new: bool = True,
    ):

        if not extensions:
            return

        if self.endpoint_schema:
            extensions1 = self.endpoint_schema.sdl
            extensions1 = self.merge(extensions1, extensions, report_new)
            if extensions1:
                self.endpoint_schema.sdl = extensions1
        self.edit_configuration(config)

    def edit_configuration(self, config: Optional[Dict[str, Any]]):
        if not config:
            return
        if config.get("configurationset"):
            logger.debug("merging configurationset")
            for aconfiguration in config.get("configurationset", []):
                configuration = aconfiguration["configuration"]
                self.add_configuration(configuration["name"], configuration)
            logger.debug("finished merging configurationset")
        # endpoint attributes of deployment, access
        self.add_endpoint_attributes(config)

    def edit_add_user_folder(
        self,
        extensions: Optional[List[SchemaFileData]],
        index: Optional[str],
        config: Optional[Dict[str, Any]],
    ):
        """
        eventually merge this into edit, but this allows
        a user directory to be merged.  It will be merged
        as a "user" folder so it cannot overwrite existing
        schema files
        """

        if not extensions:
            return

        extensions1 = self.endpoint_schema

        mapping = (
            (
                {item.name: idx for idx, item in enumerate(extensions1.sdl)}
                if extensions1.sdl
                else {}
            )
            if extensions1
            else {}
        )
        if extensions1:
            # use print below so user visible?
            # uf = Path("userfiles")
            for idx, ext in enumerate(extensions):
                oname = ext.name
                if mapping.get(oname) is not None:
                    raise RuntimeError(f"{oname} already exists in the schema")
                # ext.name = str(uf.joinpath(ext.name))  # push down a level
                if oname == str(index):
                    extensions1.add(ext)
                    print(f"extension: add to index: {ext.name}")
                else:
                    extensions1.add_noindex(ext)
                    print(f"extension: {ext.name}")
        self.edit_configuration(config)

    def edit(
        self,
        extensions: Optional[List[SchemaFileData]] = None,
        configuration: Optional[StepzenConfig] = None,
    ):
        """
        used to add user_endpoints, extensions, or configuration - NYI

        Parameters
        ----------
        extensions: [SchemaFileData]
           provides extensions to underlying pattern.  Intended for use for low
           level work on the underlying GraphQL.
        configuration: [StepzenConfig]
           provides a complete StepzenConfig including access policies and deployment identity that
           overrides any existing value.  Intended for use for low level work.

        Returns
        -------
        Flows
          a new flows object

        Raises
        ------
        RuntimeError
          execution exceptions
        """
        if extensions:
            if not self.endpoint_schema:
                EndpointSchema(extensions)
            else:
                for extension in extensions:
                    if self.endpoint_schema.find(extension):
                        # we could also replace the content, but this is safer.
                        raise RuntimeError(f"{extension.name} already exists in the schema")

                    self.endpoint_schema.add(extension)
        if configuration:
            self.configuration_data = configuration
        pass


class FlowsPublisher:
    """allows developers deploy flows.

    flows provide tooling to couple APIs using a API Connect for GraphQL/Stepzen
    as a coordinating service.   The tooling includes a domain specific
    language that allow a flow like:
    `RetrievalAutomatedGeneration =  searchDocuments | generatePrompt | genaiCompletion | outputAsString`
    to model a straight-foward RetrievalAutomatedGeneration endpoint
    consisting of a number of steps that use existing services such as
    watsonx.ai and watsonx.data.

    To build such flows, typically, you start with a prebuilt set of `steps`
    that are incorporated into a `pattern` package inside a FlowFoundation.

    In order to enable steps within the flow, they must be configured and
    are autofilled using environment variables from the FlowFoundation
    configuration element.  Future: a direct way to configure steps

    Configurations - a pattern will have a list of named configurations such as
    `watsonxai_config` that will have a list of values specific to usage of watsonx.ai
    such as the `api_key`, `project_id`, etc.   For convenience, these have been
    prefilled with `STEPZEN_` strings such as STEPZEN_WATSONX_AI_TOKEN that can
    be automatically replaced with environment variables.

    """

    def __init__(self, pattern: FlowFoundation, credentials: Optional[StepzenCredentials] = None):
        self.credentials_data = credentials
        self.pattern_data = pattern

    def credentials(
        self,
        environment: str,
        environment_domain: str = "",
        admin_apikey: str = "",
        apikey: str = "",
    ) -> StepzenCredentials:
        """
        used to provide or establish credentials associated with a watsonx Flows Engine environment.

        Parameters
        ----------
        environment: str
           environment name
        environment_domain: str
           domain such as `stepzen.us-east-a.ibm.stepzen.net`
        admin_apikey: str
           apikey associated with the environment that manage endpoints
        apikey: str
           apikey associated with the environment that use endpoints

        Returns
        -------
        StepzenCredentials
          credentials object

        Raises
        ------
        RuntimeError
          if parameters are missing values

        """
        if not environment or not environment_domain or not admin_apikey:
            raise RuntimeError("missing required credential")
        self.credentials_data = StepzenCredentials(environment, environment_domain, admin_apikey)
        return self.credentials_data

    def add(
        self,
        user_endpoints: Optional[List[UserEndpoint]],
    ):
        """
        used to add user_endpoints- NYI

        Parameters
        ----------
        user_endpoints: [UserEndpoint] - NYI
           provides a list of user endpoints that should be imported for use by flows.

        Raises
        ------
        RuntimeError
          execution exceptions
        """
        if user_endpoints:
            # later, do a import and add the SDL
            pass
        pass

    async def deploy(
        self,
        endpoint_name: str,
        flows: List[str],
        flags: Optional[List[str]] = None,
    ) -> FlowEndpoint:
        """
        used to deploy flows to an endpoint hosted by API Connect for GraphQL

        Parameters
        ----------
        endpoint_name: str
           name for the endpoint under your environment in the form `folder/name`
        flows: [str]
           a list of one or more flows to deploy to endpoint_name which

        Returns
        -------
        str
          endpoint created - need for the SDK

        Raises
        ------
        RuntimeError
          execution exceptions

        """
        if not self.credentials_data:
            raise RuntimeError("flows deploy: credentials information required")

        if not self.pattern_data.endpoint_schema:
            raise RuntimeError("internal error pattern data not loaded")
        result = await Deployment(
            self.credentials_data,
            self.pattern_data.endpoint_schema,
            self.pattern_data.configuration_data,
        ).deploy(endpoint_name, flows)
        return FlowEndpoint(
            result.stepzen_deploy.endpoint_uri() if result.stepzen_deploy else "",
            self.credentials_data,
            result,
        )


################################################################################
# The rest is exported elements and is our public API surface.
################################################################################


async def publish_flows_async(
    pattern_name: str,
    environment: str,
    environment_domain: str,
    admin_apikey: str,
    endpoint_name: str,
    flows: List[str],
    env: Optional[Mapping[str, Optional[str]]] = os.environ,
) -> str:
    """
    used to publish flows to an endpoint hosted by API Connect for GraphQL
    async function - use asyncio.run to run synchronously

    Parameters
    ----------
    pattern_name: str
       Pattern
    environment: str
       API Connect for GraphQL environment name
    environment_domain: str
       API Connect for GraphQL domain name (e.g. us-east-a.ibm.stepzen.net)
    admin_apikey: str
       API Connect for GraphQL admin apikey
    endpoint_name: str
       name for the endpoint under your environment in the form `folder/name`
    flows: [str]
       a list of one or more flows to deploy to endpoint_name which
    env: dict[str,str|None]
       environment to use to autoconfigure

    Returns
    -------
    str
      endpoint created - need for the SDK

    Raises
    ------
    RuntimeError
      execution exceptions

    """
    credentials = StepzenCredentials(environment, environment_domain, admin_apikey)
    if (
        len(pattern_name) > 50 and pattern_name[0] == "{"
    ):  # allow the pattern name to be the data...
        pattern = await FlowFoundation.create(
            "_test_", credentials, env, _catalog_data=pattern_name
        )
    else:
        pattern = await FlowFoundation.create(pattern_name, credentials, env)
    flows_controller = FlowsPublisher(pattern, credentials)
    result = await flows_controller.deploy(endpoint_name, flows)
    return result.uri


def publish_flows(
    pattern_name: str,
    environment: str,
    environment_domain: str,
    admin_apikey: str,
    endpoint_name: str,
    flows: List[str],
    env: Optional[Mapping[str, Optional[str]]] = os.environ,
) -> str:
    """
    used to publish flows to an endpoint hosted by API Connect for GraphQL
    async function - use asyncio.run to run synchronously

    Parameters
    ----------
    pattern_name: str
       Pattern
    environment: str
       API Connect for GraphQL environment name
    environment_domain: str
       API Connect for GraphQL domain name (e.g. us-east-a.ibm.stepzen.net)
    admin_apikey: str
       API Connect for GraphQL admin apikey
    endpoint_name: str
       name for the endpoint under your environment in the form `folder/name`
    flows: [str]
       a list of one or more flows to deploy to endpoint_name which
    env: dict[str,str|None]
       environment to use to autoconfigure

    Returns
    -------
    str
      endpoint created - need for the SDK

    Raises
    ------
    RuntimeError
      execution exceptions

    """
    return asyncio.run(
        publish_flows_async(
            pattern_name, environment, environment_domain, admin_apikey, endpoint_name, flows, env
        )
    )


async def publish_aicore_flow_async(
    environment: str,
    environment_domain: str,
    admin_apikey: str,
    endpoint_name: str,
    flows: List[str],
    env: Optional[Mapping[str, Optional[str]]] = os.environ,
) -> str:
    """
    used to publish flows to an endpoint hosted by API Connect for GraphQL
    async function - use asyncio.run to run synchronously

    Parameters
    ----------
    pattern_name: str
       Pattern
    environment: str
       API Connect for GraphQL environment name
    environment_domain: str
       API Connect for GraphQL domain name (e.g. us-east-a.ibm.stepzen.net)
    admin_apikey: str
       API Connect for GraphQL admin apikey
    endpoint_name: str
       name for the endpoint under your environment in the form `folder/name`
    flows: [str]
       a list of one or more flows to deploy to endpoint_name which
    env: dict[str,str|None]
       environment to use to autoconfigure

    Returns
    -------
    str
      endpoint created - need for the SDK

    Raises
    ------
    RuntimeError
      execution exceptions

    """
    PATTERN_NAME = "aicore"
    return await publish_flows_async(
        PATTERN_NAME, environment, environment_domain, admin_apikey, endpoint_name, flows, env
    )


def execute_flow(
    flow_name: str,
    data: Dict[str, Any],
    max_depth: Optional[int] = None,
    endpoint_apikey: str = "",
    endpoint_url: str = "",
    query: Optional[str] = None,
) -> Dict[str, Any]:
    """
    execute_flow invokes a flow from the wxflows SDK
    with the endpoint and apikeys filled in from .env values

    Parameters
    ----------
    flow_name: str
        flow name to execute
    data: Dict[str,Any]
        input variables for the flow
    max_depth: Optional[int],
        levels of nesting to include
    endpoint_url: str
        specify endpoint_url, default: os.environ["WXFLOWS_ENDPOINT"]
    endpoint_apikey: str
        specify endpoint_apikey, default: os.environ["WXFLOWS_APIKEY"]

    Returns
    -------
    Response: Dict[str,Any]
       response from the flow which will contain the keys "data", "errors", and/or
       "extensions" paralleling a GraphQL response
       the flow result in data is not dereferenced because it is entirely legal
       to get data, errors, and extensions

    Raises
    ------
    RuntimeError
        if the results do not contain the expected dictionary
    KeyError
        pass through of the rag.execute error
    Exception
        pass through of rag.execute errors

    Notes
    ----
    WXFLOWS_ENDPOINT and WXFLOWS_APIKEY are expected to be set
    `wxflows whoami --sdk-env` can be used to set/append these values for .env

    """
    result = rag.execute(
        endpoint=endpoint_url or os.environ["WXFLOWS_ENDPOINT"],
        apikey=endpoint_apikey or os.environ["WXFLOWS_APIKEY"],
        name=flow_name,
        vars=data,
        max_depth=max_depth or 4,
        query=query,
    )
    if isinstance(result, KeyError):
        raise result
    if isinstance(result, dict) and all(isinstance(k, str) for k in result.keys()):
        return result
    raise RuntimeError("rag.execute returned an unexpected result")


def setup_execute_flow_args(parser: argparse.ArgumentParser, flowname_required: bool = False):
    parser.add_argument("--max-depth", type=int, help="level of graph nesting to include")
    parser.add_argument("--flow-name", nargs=1, help="flow name", required=flowname_required)

    # keep this hidden as rag.execute does not deal well with argument types yet.
    parser.add_argument(
        "--var",
        action="append",
        help="Add a request variable, in the name=value format",
    )
    # keep this as it is useful
    parser.add_argument(
        "--var-file", help="Read request variables from a JSON file.  --var has priority"
    )
    parser.add_argument(
        "--json", "--data", dest="data", help="JSON will override var and var-files"
    )
    parser.add_argument("query", nargs="?", help="GraphQL query - expert mode")


def execute_flow_databuild_utility(
    json_data: Optional[str],
    var_data: Optional[str],
    var_file: Optional[str],
) -> Dict[str, Any]:
    data = {}
    if json_data:
        data = json.loads(json_data)
    else:
        if var_file:
            with open(var_file, "r") as f:
                data = json.load(f)
        if var_data:
            # ignore typing, let rag.execute deal with it.
            for arg in var_data:
                vals = arg.split("=", 1)
                if len(vals) != 2:
                    raise RuntimeError(
                        f"invalid --var argument, expecting --var NAME=value, got '{arg}'"
                    )
                data[vals[0]] = vals[1]
    return data


def execute_flow_main(flow_name: str, dotenv: bool = True) -> Dict[str, Any]:
    """
    sdk_example_code is a small "main" program that will run the specified flow
    making the use of expected environment variables.

    Parameters
    ----------
    flow_name: str
        flow name to execute
    max_depth: Optional[int],
        levels of nesting to include
    dotenv: bool = True
        load dotenv

    Returns
    -------
    Response: Dict[str,Any]
       response from the flow which will contain the keys "data", "errors", and/or
       "extensions" paralleling a GraphQL response
       the flow result in data is not dereferenced because it is entirely legal
       to get data, errors, and extensions

    Raises
    ------
    Exception
        pass through of rag.execute errors
    """
    if dotenv:
        load_dotenv()
    parser = argparse.ArgumentParser(description="flow example", epilog="")
    setup_execute_flow_args(parser)
    args = parser.parse_args()

    data = execute_flow_databuild_utility(args.json, args.var, args.var_file)
    return execute_flow(
        (args.flow_name and args.flow_name[0]) or flow_name,
        data,
        max_depth=args.max_depth,
        query=args.query,
    )


def tc_tools_query() -> str:
    """
    BFFTool will return tc_tools
    the returned data matches the tools
    definition in https://cloud.ibm.com/apidocs/watsonx-ai#text-chat
    """
    return """query BFFTool {
  tc_tools {
    __typename
    ...TD
  }
}

fragment TD on TC_Tool {
  type
  ... on TC_FunctionTool {
    function {
      name
      description
      parameters {
        type
        properties
        required
      }
    }
  }
}
"""


async def tools_info_async(
    endpoint_url: str,
    endpoint_apikey: str,
) -> Dict[str, Any]:
    """
    tools_info_async retrieves the tools data from the wxflows endpoint

    Parameters
    ----------
    endpoint_apikey: str
        specify endpoint_apikey, default: os.environ["WXFLOWS_APIKEY"]
    endpoint_url: str
        specify endpoint_url, default: os.environ["WXFLOWS_ENDPOINT"]

    Returns
    -------
    Response: Dict[str,Any]
       GraphQL response containing the nested tools definition matching
       watsonx tools definition
       https://cloud.ibm.com/apidocs/watsonx-ai#text-chat

    Raises
    ------
    RuntimeError
        if the results do not contain the expected dictionary
    Exception
        passthrough of httpx post
    """

    q = tc_tools_query()

    headers = {"Authorization": f"apikey {endpoint_apikey}"} if endpoint_apikey else {}

    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(endpoint_url, json={"query": q}, headers=headers)
        response.raise_for_status()
        return response.json()
