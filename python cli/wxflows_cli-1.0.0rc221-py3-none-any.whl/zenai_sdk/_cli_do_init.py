# Copyright IBM Corp. 2023, 2025
import argparse
import asyncio
import copy
import json
import logging
import os
import re
import sys
from typing import Dict, List, Optional, Tuple, Union, cast, Any
from urllib.parse import urlparse

import httpx
import inquirer
import tomlkit
import tomlkit.items
from inquirer.errors import ValidationError as InquirerValidationError
from jinja2 import DebugUndefined, Environment, PackageLoader, select_autoescape
from rich import print as rprint

from ._cli_do import _WATZENTOML, CLIData
from ._cli_do_data import cmd_data
from .cli_error import CLIError
from .configuration import (
    _DEFAULT_COLLECTION,
    _DEFAULT_DOCSTORE,
    _DEFAULT_GENAI,
    _FLOW_EXT,
    TOMLConfiguration,
)
from .console import console
from .flows import CatalogData

logger = logging.getLogger("wxflows")


FIXED_FLOW_TEXT = """\"\"\"
    // myPrompt = ragAnswerInput | topNDocs | promptFromTopN | ragInfo
    // myRag = ragAnswerInput | topNDocs | promptFromTopN | completion(parameters:myRag.parameters) | ragInfo
    // myRagWithGuardrails = ragAnswerInput | topNDocs | promptFromTopN | completion(parameters:myRagWithGuardrails.parameters) | ragScoreInfo | hallucinationScore | ragScoreMessage | ragInfo
\"\"\""""

DEFAULT_AI_ENGINE = _DEFAULT_GENAI
DEFAULT_DOCUMENTSTORE = _DEFAULT_DOCSTORE
DEFAULT_COLLECTION = _DEFAULT_COLLECTION
DEFAULT_EMBEDDING = "ibm/slate-30m-english-rtrvr-v2"


def _validate_collection_name(_, current: str) -> bool:
    if len(current.strip()):
        return True

    raise InquirerValidationError("", reason="A collection name is requried")


def _validate_endpoint_name(_, current: str) -> bool:
    if not current or "/" not in current:
        raise InquirerValidationError(
            "",
            reason="An endpoint name should look like [folder]/[name], and each part should be non-empty",
        )

    parts = current.split("/")
    if any(part.strip() == "" for part in parts):
        raise InquirerValidationError(
            "",
            reason="An endpoint name should look like [folder]/[name], and each part should be non-empty",
        )

    if any(re.match(r"^[\d_-]", part) for part in parts):
        raise InquirerValidationError(
            "", reason="Each part of an endpoint name should start with a letter"
        )

    if any(not re.match(r"^[\w-]+$", part) for part in parts):
        raise InquirerValidationError(
            "",
            reason="An endpoint name should contain only letters, digits, dashes and underscores",
        )

    return True


def is_tsv_file(path: str) -> bool:
    return os.path.isfile(path) and os.path.splitext(path)[1].lower() == ".tsv"


class DocumentStoreArguments:
    """
    just capture these cleanly
    """

    def __init__(
        self,
        documentstore_type: Optional[str],
        documentstore_data_file: Optional[str],
    ):
        if documentstore_type:
            parts = documentstore_type.split(".")
            self.documentstore_type = parts[0]
            self.documentstore_subtype = parts[1] if len(parts) > 1 else None
        else:
            self.documentstore_type = None
            self.documentstore_subtype = None
        self.documentstore_data_file = documentstore_data_file

    def get_toml_data(self) -> List[str]:
        if not self.documentstore_type:
            return []
        have = []
        have.append(f'documentstore.type="{self.documentstore_type}"')
        if self.documentstore_subtype:
            have.append(
                f'documentstore.{self.documentstore_type}.subtype="{self.documentstore_subtype}"'
            )

        if self.documentstore_data_file:
            have.append(
                f'document.{self.documentstore_type}.data_file="{self.documentstore_data_file}"'
            )
        return have


async def download_url(url: str) -> str:
    parts = urlparse(url)
    if not (parts.scheme == "http" or parts.scheme == "https"):
        raise CLIError(f"{parts.scheme} for {url} is not implemented")
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(url, follow_redirects=True)
    return r.text


FLOW_EXT = _FLOW_EXT


def process_flowfiles(flow_files: List[str]) -> List[str]:
    """
    process_flowfiles will process a list of flow files names or references
    """

    names: List[str] = []
    for flow_file in flow_files:
        parts = urlparse(flow_file)
        if parts.scheme == "" or parts.scheme == "file":
            if os.path.exists(parts.path):
                names.append(parts.path)
            else:
                raise CLIError(f"file {flow_file} does not exist")
        elif parts.scheme == "http" or parts.scheme == "https":
            filename = parts.path
            if not filename:
                filename = "user"
            # remove directories.
            filename = os.path.basename(filename)
            fparts = os.path.splitext(filename)
            if not fparts[1]:
                filename = filename + FLOW_EXT
            if os.path.exists(filename):
                raise CLIError(
                    f"file {flow_file} would be downloaded to {filename} which already exists"
                )
            try:
                data = asyncio.run(download_url(flow_file))
            except httpx.ConnectError as e:
                raise CLIError(f"Retrieving flow from {flow_file}: Could not connect: {e}")
            except Exception as e:
                raise CLIError(f"Retrieving flow from {flow_file}: {e}")
            rprint(f"Downloaded  {filename} from {flow_file} size {len(data)}")
            with open(filename, "w") as f:
                f.write(data)
            names.append(filename)
        else:
            raise CLIError(f"file {flow_file} not supported")
    return names


def url_validate(answers, current):
    if current.startswith("http") or current == "":
        return True
    raise InquirerValidationError(
        "", reason="Expect a valid https/http endpoint that contains GraphQL based BFF"
    )


_IMPORT_TYPES = set(["url", "directory", "package", "openapi-schema"])


class BFFImportAction(argparse.Action):
    # each import is named ({import_name}.*)
    # each import may have multiple {import_name}.type.* statements
    def __call__(self, parser, namespace, values, option_string=None):
        if "bff_args" not in namespace:
            setattr(namespace, "bff_args", [])
        if self.dest.startswith("import_"):
            dname = self.dest[len("import_") :]
        else:
            dname = self.dest
        opts = namespace.bff_args
        if not isinstance(values, str):
            parser.error("expected a string value for {self.dest}")
        if dname == "name":
            if not re.match(r"^[a-zA-Z0-9]\w*$", values, re.I):
                parser.error(
                    "import-name must be an alphanumeric string starting with a letter or number"
                )
        if dname in ("name", "url", "directory", "package", "openapi-schema"):
            # advance if name is specified again
            if dname == "name" and (len(opts) == 0 or dname in opts[-1]):
                opts.append({})
            else:
                # advance if another import type  (url, etc.) is specified
                # dname in ("url", "directory", "package", "openapi-schema") and one already exists
                if len(opts) == 0 or _IMPORT_TYPES.intersection(set(opts[-1].keys())):
                    opts.append({})

        if len(opts) == 0:
            parser.error(
                f"--import-name,{','.join(_IMPORT_TYPES)} start a new import definiton and must appear before --import-{dname.replace('_', '-')}"
            )
        if dname.startswith("tool_"):
            dname = self.dest[len("import-tool-") :]
            tools = opts[-1].get("tools")
            if not tools:
                opts[-1]["tools"] = [{}]
                tools = opts[-1]["tools"]
            if dname in tools[len(tools) - 1]:
                opts[-1]["tools"].append({})
            opts[-1]["tools"][-1][dname] = values
        else:
            if len(_IMPORT_TYPES.intersection(set(opts[-1].keys()))) > 1:
                raise CLIError(
                    "only one of --import-url, --import-directory, --import-package, --import-openapi-schema may be used for an import"
                )
            if dname in opts[-1]:
                parser.error(f"{self.dest} is already specified")
            opts[-1][dname] = values
        setattr(namespace, "bff_args", opts)


def template_bff_as_dict(
    bff_args: List[Dict[str, Any]],
    tag: str = "imports",
) -> Tuple[str, List[str]]:
    bffargs = {}
    prefixed = {"wxflows": {"deployment": {"endpoint": {tag: bffargs}}}}
    envnames = []
    for idx, item in enumerate(bff_args):
        name = item.get("name")
        if not name:
            # use key type as name
            possible = _IMPORT_TYPES.intersection(set(item.keys()))
            if len(possible) > 1:
                raise CLIError("only one of {list(import_types)} is allowed")
            name = list(possible)[0]
            if idx > 0:
                name += f"_{idx}"
        bffargs[f"{name}"] = {k: v for k, v in item.items() if k != "name"}
    return tomlkit.dumps(prefixed), envnames


def template_bff(
    bff_args: List[Dict[str, Any]],
    doc: Optional[tomlkit.TOMLDocument] = None,
    tag: str = "imports",
) -> Tuple[str, List[str]]:
    # smarter version of template_bff that will convert description into a multiline,
    # add a few comments
    envnames = []
    if not doc:
        toml_base_format = """
# Endpoint imports provide customized extensions for your flows
[wxflows.deployment.endpoint]
"""
        doc = tomlkit.loads(toml_base_format)

    _wx_flows = doc["wxflows"]
    if not isinstance(_wx_flows, tomlkit.items.Table):
        raise CLIError("The wxflows.toml is not properly setup.   wxflows is not a table")

    deployment = _wx_flows["deployment"]
    if not isinstance(deployment, tomlkit.items.Table):
        raise CLIError("The wxflows.toml is not properly setup.   deployment is not a table")

    # rewrite endpoint
    endpoint = deployment.get("endpoint")
    if not endpoint:
        endpoint = tomlkit.table()
        deployment["endpoint"] = endpoint

    imports = deployment.get(tag)
    if not imports:
        imports = tomlkit.aot()
        endpoint[tag] = imports

    for idx, item in enumerate(bff_args):
        if "apikey_envname" in item:  # keep track
            envnames.append(item["apikey_envname"])
            logger.debug(f"imports: encountered apikey_envname  {item['apikey_envname']}")
        # item (import, extension) table
        it = tomlkit.table()
        it.add(tomlkit.comment(f"import {idx+1}"))

        if "url" in item and not item["url"].startswith("http"):
            it.add(
                tomlkit.comment(
                    f"url {item['url']} is a relative path for this wxflows environment"
                )
            )
        for k, v in item.items():
            if k != "tools":
                it.add(k, v)
        imports.append(it)
        if "tools" in item or "tools_definition" in item:
            if "tools" in it:
                ntools = it["tools"]
                if not isinstance(ntools, tomlkit.items.AoT):
                    raise CLIError("invalid")
            else:
                ntools = tomlkit.aot()
                it.add("tools", ntools)
            logger.debug(f"{tag}: encountered {len(item['tools'])} tool definitions")

            for idx2, tool in enumerate(item["tools"]):
                it = tomlkit.table()
                it.comment(f"{tag} {idx+1}: tool description {idx2+1}")
                ntools.append(it)
                for k, v in tool.items():
                    if k == "description":
                        it.add("description", tomlkit.string(tool["description"], multiline=True))
                    else:
                        it.add(k, tomlkit.string(v))
            item["tools"] = ntools

    tool_names = [
        tool.get("name")
        for item in endpoint.get("imports", [])
        if item.get("tools")
        for tool in item.get("tools")
        if tool.get("name")
    ] + [
        tool.get("name")
        for item in endpoint.get("extensions", [])
        if item.get("tools")
        for tool in item.get("tools")
        if tool.get("name")
    ]
    tool_names.append("waft")
    if len(tool_names) != len(set(tool_names)):
        seen = set()
        dup = set()
        for name in tool_names:
            if name not in seen:
                seen.add(name)
            else:
                dup.add(name)
        raise CLIError(f"tool name(s) must be unique inside an endpoint: {','.join(dup)} repeated")
    return tomlkit.dumps(doc), envnames


def template_bff_trivial(
    bff_args: List[Dict[str, Any]],
    tag: str = "imports",
) -> Tuple[str, List[str]]:

    # very simple form that should always work.
    bffargs = []
    prefixed = {"wxflows": {"deployment": {"endpoint": {tag: bffargs}}}}
    for idx, item in enumerate(bff_args):
        bffargs.append(item)
    return tomlkit.dumps(prefixed), []


def process_a_import(iter: int, clienv: CLIData) -> Dict[str, Any]:
    results = {}
    if iter == 0:
        print("You can import a GraphQL endpoint and also use it as a tool. ")
        print("You can also import a package or directory and also use it as a tool. ")
        print("https://ibm.biz/wxflows-dashboard provides documentation")
    questions = [
        inquirer.List(
            "import_type",
            message="Import type",
            choices=["done", "GraphQL", "OpenAPI", "Directory", "Package"],
        ),
    ]
    answers = inquirer.prompt(questions)
    if not answers:
        # the prompt is interrupted by the user with Ctrl+C
        sys.exit(0)
    if not answers.get("import_type") or answers.get("import_type") == "done":
        return {}
    import_type = answers.get("import_type")

    bff_name = None
    if import_type == "GraphQL":
        msg = "Backend GraphQL URL for import"
        questions = [
            inquirer.Text(
                "url",
                message=msg,
                # validate=url_validate,
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        url = answers.get("url")
        urlparts = urlparse(url)
        thepath = urlparts.path
        if not urlparts.scheme and not urlparts.netloc and thepath:
            pathpartsl = len(str(thepath).split("/"))
            if pathpartsl != 2 and pathpartsl != 3:
                raise CLIError(
                    "Expected the url to either be a full URL or just the endpoint name"
                )
            newurl = f"https://{clienv.account}.{clienv.domain}/{thepath}"
            if pathpartsl == 2:
                newurl += "/graphql"
            urlparts = urlparse(newurl)
            print(f"{thepath} will expand to {newurl}")
        # netloc = parts.netloc  # later check if account matches and possibly help more with apikey
        parts = str(thepath).split("/")
        bff_name = ""
        if len(parts) > 2:
            bff_name = parts[2].replace("-", "_").replace(".", "_")
        results["url"] = url
        if not url:
            return {}
    elif import_type == "OpenAPI":
        msg = "OpenAPI specification file"
        questions = [
            inquirer.Text(
                "openapi",
                message=msg,
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        openapi = answers.get("openapi")
        if not openapi:
            return {}
        results["openapi"] = answers.get("openapi")
        bff_name = "openapi_" + os.path.splitext(os.path.basename(openapi))[0]
    elif import_type == "Package":
        msg = "Package file (.zip)"
        questions = [
            inquirer.Text(
                "package",
                message=msg,
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        apackage = answers.get("package")
        if not apackage:
            return {}
        results["package"] = answers.get("package")
        bff_name = "package_" + os.path.splitext(os.path.basename(apackage))[0]
    elif import_type == "Directory":
        msg = "User Extension directory"
        questions = [
            inquirer.Text(
                "directory",
                message=msg,
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        adirectory = answers.get("directory")
        if not adirectory:
            return {}
        results["directory"] = adirectory
        bff_name = "directory_" + os.path.splitext(os.path.basename(adirectory))[0]

    questions = [
        inquirer.Text(
            "name",
            default=bff_name,
            message="ID",
        ),
    ]
    name = None
    for i in range(5):
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        name = answers.get("name")
        if name:
            break

    if not name:
        print("Stopping after 10 attempts")
        return {}
    results["name"] = answers.get("name")

    prompt_for_prefix = True
    prefix_default = name.upper() + "_"
    if import_type == "Package" or import_type == "Directory":
        prompt_for_prefix = False
    if import_type == "GraphQL":
        envq = [
            inquirer.List(
                "apikey_envname_class",
                message="APIKey environment name",
                choices=[name.upper() + "_APIKEY", "None", "Custom"],
                default=name.upper() + "_APIKEY",
            ),
        ]
    else:
        envq = []
    if prompt_for_prefix:
        questions = [
            inquirer.Text(
                "prefix",
                message="Prefix for fields",
                default=prefix_default,
            )
        ] + envq
    else:
        questions = envq

    if questions:
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        if answers.get("prefix"):
            results["prefix"] = answers.get("prefix")
        envname_class = answers.get("apikey_envname_class")
    else:
        envname_class = None

    if envname_class:
        if envname_class == "Custom":
            questions = [inquirer.Text("apikey_envname", message="APIKey environment name")]
            answers = inquirer.prompt(questions)
            if not answers:
                # the prompt is interrupted by the user with Ctrl+C
                sys.exit(0)
            results["apikey_envname"] = answers.get("apikey_envname")
        elif envname_class == "None":
            pass
        elif envname_class:
            # this is the default answer
            results["apikey_envname"] = envname_class

    tool_field_required = False
    if import_type != "GraphQL" and import_type != "OpenAPI":
        if not results.get("prefix"):
            tool_field_required = True

    tools = []
    for idx in range(10):
        tool = {}
        if idx > 0:
            print("")
        questions = [
            inquirer.Text(
                "tool.description",
                message="Backend API Description for tool usage [skip]",
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)

        if not answers.get("tool.description"):
            break
        if answers.get("tool.description"):
            tool["description"] = answers.get("tool.description")
        tool_fields_msg = "Backend tool fields to expose [all]"
        if tool_field_required:
            tool_fields_msg = "Tool fields to expose (required)"

        if os.environ.get("WXFLOWS_EXP") == "tools":
            root_type = ["Query", "Mutation", "Query|Mutation"]
            logger.debug(f"WXFLOWS_EXP feature {os.environ.get('WXFLOWS_EXP')}.")
        else:
            root_type = []
        if answers.get("tool.description"):
            if root_type:
                questions = [
                    inquirer.List("tool.root_type", message="Root Type", choices=root_type)
                ]
                answers = inquirer.prompt(questions)
                if not answers:
                    # the prompt is interrupted by the user with Ctrl+C
                    sys.exit(0)
                root_types = answers.get("tool.root_type", "Query")
                if root_types:
                    tool["root_types"] = root_types
            else:
                root_types = "Query"
            myname = name
            if root_type != "Query":
                myname = name + "_" + root_types.lower()
                # remove any special character from name.
                myname = re.sub("[^a-zA-Z0-9_-]", "_", myname)
            if idx > 0:
                myname += f"_{idx}"

            questions = [
                inquirer.Text(
                    "tool.name",
                    message="Tool name",
                    default=myname,
                ),
                inquirer.Text(
                    "tool.fields",
                    message=tool_fields_msg,
                ),
            ]
            answers = inquirer.prompt(questions)
            if not answers:
                # the prompt is interrupted by the user with Ctrl+C
                sys.exit(0)
            if answers.get("tool.fields"):
                tool["fields"] = answers.get("tool.fields")
            elif tool_field_required:
                # eventually loop back and ask again
                raise CLIError("You must provide fields for extensions or package")
            if answers.get("tool.name"):
                tool["name"] = answers.get("tool.name")
            tools.append(tool)
    if tools:
        results["tools"] = tools
    return results


def process_imports(clienv: CLIData) -> List[Dict[str, Dict[str, Any]]]:
    results = []
    for iter in range(0, 100):
        result = process_a_import(iter, clienv)
        if not result:
            return results
        results.append(result)
    return results


def cmd_init(
    clienv: CLIData,
    pattern: str,
    collection: str,
    files: List[str],
    name: Optional[str],
    email: Optional[str],
    interactive: bool,
    configuration_file: Optional[str],
    initial_configuration_file: Optional[bool],
    embedding: Optional[str],
    data_args: Dict[str, Union[str, int]],
    flow_files: Optional[List[str]],
    endpoint_name: Optional[str],
    preexisting_endpoint: Optional[str],  # base endpoint in lieu of pattern (DEPRECATED)
    ai_engine: Optional[str],
    bff_args: Optional[List[Dict[str, Dict[str, Any]]]],
    ds_arguments: Optional[DocumentStoreArguments],
    directory: Optional[str] = "",
):
    """
    create the wxflows.toml
    """

    if not directory:
        directory = ""

    if endpoint_name:
        try:
            _validate_endpoint_name({}, endpoint_name)
        except InquirerValidationError as e:  # type: ignore
            raise CLIError(f"Invalid endpoint name {endpoint_name}. {e.reason}")

    if not clienv.is_zenctl2():
        raise CLIError(
            "watsonx Flows Engine does not work with your current StepZen environment.  Please upgrade your enviroment at https://ibm.biz/wxflows-dashboard"
        )

    # *FIXED_FLOW_TEXT* needs to be cleanup and gotten from where?
    # should not be appending document store info

    # adjust default chunk size, but not the offset for now.
    default_chunk_size = "500"
    if (
        embedding == "mini"
        or embedding == "sentence-transformers/all-minilm-l12-v2"
        or embedding == "sentence-transformers/all-minilm-l6-v2"
    ):
        default_chunk_size = "250"
    if not embedding:
        # default to the WATSONX default embedding
        embedding = DEFAULT_EMBEDDING

    # aicore is the only thing we accept as pattern
    # pattern was originally the term for the schemas we'd used
    # for a particular "use" case.   It has since evolved, but it
    # remains in the code.  While there may be multiple schema
    # types in the future, we'll likely want to rename it from pattern...
    # 2024-10-02 enable pattern for now, still expect a rename.
    pattern = pattern or "aicore"

    # skip manifest elements if preexisting_endpoint is true since
    # manifest elements will not apply
    bundle = None
    catalog_data = asyncio.run(CatalogData.create())
    if not catalog_data.get_pattern(pattern):
        raise CLIError(
            f"internal error: {pattern} definition could not be found or is inaccessible"
        )

    # interactive prompt if collection is not provided (RAG-specific)
    dorag = "no"
    # interactive prompt if asked
    if interactive:
        questions = [
            inquirer.List(
                "dorag",
                message="Do you wish to use retrieval-augmented generation (RAG)?",
                choices=["yes", "no"],
                default="yes",
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        dorag = cast(str, answers.get("dorag"))

    dorag_interview = not collection and dorag == "yes"
    if dorag_interview:
        questions = [
            inquirer.List(
                "collection_or_type",
                message="Choose the document collection for context retrieval",
                choices=[
                    ("create from local data", "data"),
                    ("use custom", "custom"),
                ],
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)

        collection_or_type = cast(str, answers.get("collection_or_type"))
        if collection_or_type == "data":
            questions = [
                inquirer.Path(
                    "data_directory",
                    message="Path to the data",
                    exists=True,
                    default=data_args.get("data_directory"),
                )
            ]
            answers = inquirer.prompt(questions)
            if not answers:
                # the prompt is interrupted by the user with Ctrl+C
                sys.exit(0)

            for k in ["data_directory"]:
                data_args[k] = cast(str, answers[k])
            questions = []
            need_data_build = (
                data_args["data_directory"]
                and isinstance(data_args["data_directory"], str)
                and not is_tsv_file(data_args["data_directory"])
            )
            if need_data_build:
                questions.extend(
                    [
                        inquirer.List(
                            "data_type",
                            message="File types to include",
                            choices=[
                                ("Markdown or HTML(ignore other files)", "md"),
                                ("all supported file types", "auto"),
                            ],
                            default=data_args.get("data_type") or "md",
                        ),
                        inquirer.Text(
                            "chunk_size",
                            message="Chunk size (in tokens)",
                            validate=lambda _, value: value.strip().isdigit(),
                            default=data_args.get("chunk_size") or default_chunk_size,
                        ),
                        inquirer.Text(
                            "chunk_overlap",
                            message="Chunk overlap (in tokens)",
                            validate=lambda _, value: value.strip().isdigit(),
                            default=data_args.get("chunk_overlap") or "50",
                        ),
                    ]
                )
            collection = "wxflows-default"
            if need_data_build:
                data_directory = data_args["data_directory"]
                if data_directory and isinstance(data_directory, str):
                    collection = re.sub(r"\W+", "", os.path.basename(data_directory))
            questions.extend(
                [
                    inquirer.Text(
                        "collection",
                        message="Collection name",
                        default=collection,
                        validate=_validate_collection_name,
                    ),
                ]
            )
            if not endpoint_name:
                questions.append(
                    inquirer.Text(
                        "endpoint",
                        message="Endpoint name",
                        default=lambda answers: TOMLConfiguration._default_endpoint_name(
                            pattern, answers["collection"]
                        ),
                        validate=_validate_endpoint_name,
                    ),
                )
            answers = inquirer.prompt(questions)
            if not answers:
                # the prompt is interrupted by the user with Ctrl+C
                sys.exit(0)
            collection = cast(str, answers.get("collection"))
            endpoint_name = cast(str, answers.get("endpoint"))
            for k in ["data_type"]:
                if k in answers:
                    data_args[k] = cast(str, answers[k])
            # convert token count to character count
            for k in "chunk_size", "chunk_overlap":
                if k in answers:
                    data_args[k] = int(cast(str, answers[k]))
        elif collection_or_type == "custom":
            questions = [
                inquirer.Text(
                    "collection",
                    message="Collection name",
                    default=DEFAULT_COLLECTION,
                    validate=_validate_collection_name,
                ),
            ]
            if not endpoint_name:
                questions.append(
                    inquirer.Text(
                        "endpoint",
                        message="Endpoint name",
                        default=lambda answers: TOMLConfiguration._default_endpoint_name(
                            pattern, answers["collection"]
                        ),
                        validate=_validate_endpoint_name,
                    ),
                )
            answers = inquirer.prompt(questions)
            if not answers:
                # the prompt is interrupted by the user with Ctrl+C
                sys.exit(0)
            collection = cast(str, answers.get("collection"))
            endpoint_name = cast(str, answers.get("endpoint"))
        else:
            # default is collection name
            collection = collection_or_type

    bff_interview_result = {}
    if interactive:
        bff_interview_result = process_imports(clienv)

    if interactive and not dorag_interview:
        print("Please refer to https://ibm.biz/wxflows-dashboard for more information on usages")

    if not endpoint_name:
        # skipped interactive prompts, and no endpoint was provided on the command line
        endpoint_name = TOMLConfiguration._default_endpoint_name(pattern, collection)

    if not ai_engine:
        logger.debug(f"ai_engine defaulting to {DEFAULT_AI_ENGINE}")
        ai_engine = DEFAULT_AI_ENGINE
    logger.debug(f"ai_engine: {ai_engine}")

    vars = {
        "email": email,
        "name": name,
        "collection": collection,
        "endpoint_name": endpoint_name,
        "deployment_pattern": pattern,
        "files": json.dumps(files),
        "ai_engine": ai_engine,
        "configuration_file": configuration_file,
    }
    if pattern != "aicore":
        vars["pattern"] = pattern

    if preexisting_endpoint:
        # naming...
        vars["preexisting_endpoint"] = preexisting_endpoint

    vars["embedding_model"] = embedding

    # grab flows (sequences) from the current pattern
    if bundle:
        flowinfo = bundle.get_stepzen_sequence(pattern)
        if flowinfo:
            # toml is forgiving about extra commas, so add them in so
            # list is legal if there are multiple items
            vars["flows"] = ",\n\n".join(flowinfo)
    else:
        if not flow_files:
            vars["flows"] = (
                json.dumps("  // You should add your flows here ")
                # hard code for now.  Drop inspection code which belongs in flow introspection
            )
        pass

    for name in ["data_type", "chunk_size", "chunk_overlap", "data_directory"]:
        if name in data_args:
            if not collection:
                logger.debug(
                    f"setting empty collection to {DEFAULT_COLLECTION} due to existence of {name}"
                )
                collection = DEFAULT_COLLECTION
            v = data_args[name]
            if name == "data_directory" and isinstance(v, str) and is_tsv_file(v):
                continue
            logger.debug(f"argument {name} set to {data_args[name]}")
            vars[name] = v

    # if collection then assume we need flows
    if collection:
        # figure out something better than FIXED_FLOW_TEXT though.
        if not flow_files:
            vars["flows"] = FIXED_FLOW_TEXT
    if flow_files:
        vars["flow_files"] = json.dumps(process_flowfiles(flow_files))

    need_data_build = data_args.get("data_directory") and not is_tsv_file(
        cast(str, data_args.get("data_directory"))
    )
    if data_args.get("data_directory"):
        if not files:  # don't overide files if set
            files = [
                (
                    f"{collection}.tsv"
                    if need_data_build
                    else f'{data_args.get("data_directory", "")}'
                )
            ]
            vars["files"] = json.dumps(files)
        elif any([("://" in f) for f in files]):
            raise CLIError("data_directory and URIs not allowed at this time.")

    if ds_arguments:
        # we should figure out the AI engine upstream and set it here...
        dstoml = ds_arguments.get_toml_data()
        if dstoml:
            vars["documentstore"] = dstoml
        else:
            # getting started uses the GETTINGSTARTED search engine
            # except in the localhost case
            if not clienv.is_localhost():
                vars["documentstore"] = [f'documentstore.type="{DEFAULT_DOCUMENTSTORE}"']

    extra_envs = []
    if bff_args or bff_interview_result:
        if bff_args:
            use_bff = copy.copy(bff_args)
        else:
            use_bff = []
        use_bff.extend(bff_interview_result)
        bffs, envs = template_bff(use_bff)
        vars["bffs"] = bffs
        extra_envs.extend(envs)

    # continue to use the jinja templating for the toml
    # consider moving to mustache templates as they are far more limited and work well on nodejs
    # and okay on golang.
    env = Environment(
        loader=PackageLoader("zenai_sdk"), autoescape=select_autoescape(), undefined=DebugUndefined
    )
    env.trim_blocks = True
    # setup all the fiddly bits
    template_name = "initial/wxflows.toml.tmpl"
    template = env.get_template(template_name)

    if directory and not os.path.exists(directory):
        os.makedirs(directory)

    watzen_toml = os.path.join(directory, _WATZENTOML)
    with open(watzen_toml, "w+", encoding="utf-8") as f:
        f.write(template.render(vars))

    # only write this on this path for now.
    dot_env = os.path.join(directory, ".env.sample")
    with open(dot_env, "w+", encoding="utf-8") as f:
        if preexisting_endpoint:
            # fix up this comment
            f.write("# API Key for the preexisting endpoint - not required if public\n")
            f.write("WXFLOWS_PREEXISTING_ENDPOINT_APIKEY=\n")
        elif catalog_data:
            # placeholder for .env.sample
            # clean up or move out and make more robust.
            stepzen_configuration = catalog_data.get_pattern_configuration(pattern)
            if not stepzen_configuration:
                print("warning: could not generate {dot_env}")
            else:
                restricted = []
                # if we're interactively doing rag, then limit choices for .env.sample
                if interactive and dorag == "yes":
                    restricted = ["STEPZEN_WATSONX_"]
                lines = (
                    [
                        "# -- Auto-generated once by wxflows init. Edit as required and save as .env --"
                    ]
                    + [
                        f"{'# ' if item not in os.environ else ''}{item}="
                        for item in sorted(stepzen_configuration.get_configuration_env())
                        if item not in clienv._injected.keys()
                        and (item not in ["STEPZEN_WATSONX_AI_TOKEN"])  # deprecated
                        and (
                            not restricted
                            or any(
                                [
                                    item
                                    for restriction in restricted
                                    if item.startswith(restriction)
                                ]
                            )
                        )
                    ]
                    + extra_envs
                )
                f.write("\n".join(lines) + "\n")

    if catalog_data and initial_configuration_file:  # TODO: add a flag
        writefile = configuration_file if configuration_file else "config.yaml"
        if os.path.exists(writefile):
            raise CLIError(f"Will not overwrite existing stepzen configuration file {writefile}")
        stepzen_configuration = catalog_data.get_pattern_configuration(pattern)
        if stepzen_configuration:
            with open(writefile, "w") as f:
                f.write(stepzen_configuration.get_configuration_file())
        configfile_msg = f" and [bold]{writefile}[/bold]"
    else:
        configfile_msg = ""
    data_file_msg = ""
    if need_data_build and interactive:
        rprint("Processing data...")

        cmd_data(
            console,
            clienv,
            TOMLConfiguration(watzen_toml),
            command="data",
            args=data_args,
            force=False,
            emit_command=True,
        )
        data_file_msg = f", [bold]{files[0]}[/bold]"

    rprint(
        f"[green]success[/green]: created [bold]{watzen_toml}[/bold]{data_file_msg} and [bold]{dot_env}[/bold]{configfile_msg}"
        + "\nPlease review and edit these files and then run [bold]wxflows deploy[/bold] to deploy your pattern."
    )


def reduce_imports(imports: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    # collapse dups
    seen = {"url": {}, "directory": {}, "package": {}, "openapi": {}, "name": {}}

    # reduce items to single for each url, etc.
    nimports = []
    for item in imports:
        # name overrides
        if "name" in item and item["name"] not in seen["name"]:
            seen["name"][item["name"]] = item
            nimports.append(item)
            continue
        # package last in case it's an overload (remove overloads?)
        for itype in ["name", "url", "directory", "openapi", "package"]:
            if itype in item and item[itype] not in seen[itype]:
                # overload causes issues
                if itype == "package" and "directory" in item:
                    continue
                seen[itype][item[itype]] = item
                nimports.append(item)
                break

    # dedup
    for item in imports:
        htype = None  # hit type
        oitem = None  # "first seen" of this hit type

        for itype in ["name", "url", "directory", "openapi", "package"]:
            if itype in item:
                if itype == "package" and "directory" in item:
                    continue
                oitem = seen[itype][item[itype]]
                htype = itype
                break
        if htype and item == oitem:
            # this means that item is "new"

            # if there's no match, it means a) specified new entry by name
            # and b) there's no previously existing value to match to get url, etc.
            if not oitem or not any(
                domatch in oitem for domatch in ["url", "directory", "openapi", "package"]
            ):
                raise CLIError(
                    "name does not match a previously existing entry but this entry is incomplete: missing url, directory, openapi,"
                    + f" package: name: {item.get('name', '<unknown name>')}"
                )
            continue

        # if oitem is null then something bad has happened?
        if not oitem:
            raise CLIError("Unexpected internal error: oitem not found")

        # cross check matches?
        if "tools" in item:
            for domatch in ["url", "directory", "openapi", "package"]:
                if item.get(domatch):
                    if item.get(domatch) != oitem.get(domatch):
                        raise CLIError(
                            f"New item with name {oitem['name']} has a mismatch "
                            + f"for {domatch}: {item[domatch]} vs. {oitem[domatch]}"
                            + " either align or remove"
                        )
            if not any(domatch in oitem for domatch in ["url", "directory", "openapi", "package"]):
                raise CLIError(
                    "improperly formatted import entry: missing url, directory, openapi,"
                    + f" package: name: {item.get('name', '<unknown name>')}"
                )
            if "tools" in oitem:
                # make this a merge rather than just a sum of the two at some point.
                oitem["tools"] = oitem["tools"] + item["tools"]
            else:
                oitem["tools"] = item["tools"]
    return nimports


def _get_doc(
    toml_data: TOMLConfiguration, subcommand: str = "import"
) -> Tuple[tomlkit.TOMLDocument, str, Any]:
    doc = toml_data.configuration_data
    if toml_data.toml_prefix():
        raise CLIError("editing of pyproject.toml is not currently supported")

    endpoint = doc.get("wxflows", {}).get("deployment", {}).get("endpoint", {})
    tag = "imports"
    if subcommand == "extension":
        tag = "extensions"
    # imports or extensions
    imports = (endpoint if endpoint else {}).get(tag)
    if imports:
        imports_j = imports.unwrap()
        if imports_j is None:
            raise CLIError("imports are not properly formatted")
    else:
        imports_j = []
    return doc, tag, imports_j


def cmd_define_import_or_extension(
    clienv: CLIData,
    subcommand: str,
    toml_name: str,
    toml_data: TOMLConfiguration,
    bff_args: Optional[List[Dict[str, Dict[str, Any]]]],
):
    if not bff_args:
        # nothing to do
        return
    doc, tag, imports_j = _get_doc(toml_data, subcommand)
    myimports = reduce_imports(imports_j + bff_args)
    for item in myimports:
        if "url" in item:  # import graphql
            if "prefix" not in item and "tools" in item:
                for tool in item["tools"]:
                    if "fields" not in tool:
                        raise CLIError(
                            "A (GraphQL) import without a prefix has a tool without a field definition."
                        )

    # ignore envs for now.
    bffs, envs = template_bff(myimports, doc=doc, tag=tag)
    # what to do with envs?

    if envs:
        data = ""
        if os.path.exists(".env.sample"):
            with open(".env.sample", "w") as f:
                data = f.read()
        with open(".env.sample", "w") as f:
            f.write(
                data
                + "\n"
                + "\n".join([f"{'# ' if item not in os.environ else ''}{item}=" for item in envs])
            )

    with open(toml_data.toml_path(), "w") as f:
        f.write(tomlkit.dumps(doc))


def cmd_define_tool(
    clienv: CLIData,
    toml_data: TOMLConfiguration,
    import_url: str,
    import_prefix: str,
    import_tool_name: str,
    import_tool_description: str,
):
    """simple form that assumes import url"""

    if not import_tool_name:
        raise CLIError("empty tool name not allowed")
    if not import_tool_description:
        raise CLIError("empty tool description is not allowed")
    if not import_prefix:
        import_prefix = import_tool_name.upper() + "_"
    data = [
        {
            "url": import_url,
            "prefix": import_prefix,
            "tools": [{"name": import_tool_name, "description": import_tool_description}],
        }
    ]
    cmd_define_import_or_extension(clienv, "import", "", toml_data, data)
