import json

class PanelistAgent:
    def __init__(self, name, voice_id, kb_path="storage/viewpoints.json"):
        self.name = name
        self.voice_id = voice_id
        with open(kb_path) as f:
            kb = json.load(f)
        self.voice = next((v for v in kb["voices"] if v["id"] == voice_id), None)

    def respond(self, question):
        if not self.voice:
            return f"{self.name} has no assigned viewpoint."
        # Demo: Just echo summary and supporting arguments
        response = f"As a panelist representing '{self.voice['summary']}', I believe: "
        response += "; ".join(self.voice["supporting_arguments"])
        return response