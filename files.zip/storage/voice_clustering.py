"""
Auto-scales the number of distinct voices using clustering.
For demonstration, uses KMeans. In production, consider DBSCAN for auto-scaling clusters.
"""

import numpy as np
from sklearn.cluster import DBSCAN
import json

def cluster_user_viewpoints(user_viewpoints):
    """
    user_viewpoints: List of dicts (e.g., answers to agent questions, or embedded representations)
    Returns: List of clusters, each is a list of user indices
    """
    # This expects user_viewpoints to be vectorizable
    data = np.array([v['vector'] for v in user_viewpoints])
    clustering = DBSCAN(eps=0.5, min_samples=2).fit(data)
    clusters = {}
    for idx, label in enumerate(clustering.labels_):
        if label == -1:
            continue  # noise, ignore for now
        clusters.setdefault(label, []).append(idx)
    return clusters

def distill_voices(user_viewpoints, clusters):
    """
    Returns list of voice dicts suitable for storage/viewpoints.json
    """
    voices = []
    for label, indices in clusters.items():
        users = [user_viewpoints[i]['user_id'] for i in indices]
        # For demo: summarize by majority answer or average embedding
        summary = f"Voice {label}: {len(users)} users"
        voices.append({
            "id": f"voice_{label}",
            "summary": summary,
            "supporting_arguments": [],
            "counterpoints": [],
            "references": [],
            "users": users
        })
    return voices

def save_voices_json(voices, path="storage/viewpoints.json"):
    with open(path, "w") as f:
        json.dump({"voices": voices}, f, indent=2)